const typeofCarBrands=[
    "nissan","hyundai","honda","renault","datsun", "toyota","subaru","volvo","ferrari","fiat","chrysler","suzuki","kia","proton","isuzu","mitsubishi","chevrolet"
]; 
const brandColors=[
    "violet","indigo","blue","green","yellow","orange","red"
]

new Vue({
    el:'#carbrands',
    data:{
        brands:typeofCarBrands,
        bColors:brandColors
    }
})