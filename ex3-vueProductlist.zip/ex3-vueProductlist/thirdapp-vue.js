const ebayProducts=[
    {
        "name": "ATH M50X Headphone",
        "image": "http://i.ebayimg.com/00/s/MTAwMFgxMDAw/z/YFYAAOSwPhdVOjdQ/$_12.JPG",
        "description": "ATH-M50xDG Limited Edition Professional Studio Monitor Headphones - Dark Green; Pure. Professional. Performance. As the most critically acclaimed model in the M-Series line, the ATH-M50 is praised by top audio engineers and pro audio reviewers year after year.",
        "category": "Electronics",
        "price": "8631",
        "quantity": "3",
        "shipping": "0",
        "location": "Mumbai",
        "color": "#6B5419",
        "show":true,
        "link": "http://www.ebay.in/sch/i.html?_nkw=m50x&_sop=16"
    },
    {
        "name": "Sony PS4 500GB",
        "image": "http://i.ebayimg.com/00/s/NDcyWDYxOA==/z/wM4AAOSwZjJVAEUf/$_12.JPG",
        "description": "The PlayStation4 system opens the door to an incredible journey through immersive new gaming worlds and a deeply connected gaming community. PS4 puts gamers first with an astounding launch lineup and over 180 games in development. Play amazing top-tier blockbusters and innovative indie hits on PS4.",
        "category": "Electronics",
        "price": "34463",
        "quantity": "7",
        "shipping": "0",
        "location": "Delhi",
        "show":false,
        "color": "#302E29",
        "link": "http://www.ebay.in/sch/i.html?_nkw=ps4&_sop=16"
    },
    {
        "name": "Handy Chopper (Slicer)",
        "image": "http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/bPAAAOSwBahU7V4G/$_12.JPG",
        "description": "Nicer Dicer With Plus you have a kitchen helper, who will shorten the cooking time from start of preparation to the serving of the meal tremendously.",
        "category": "Household",
        "price": "549",
        "quantity": "10",
        "shipping": "0",
        "location": "Chennai",
        "show":true,
        "color": "#B6E314",
        "link": "http://www.ebay.in/sch/i.html?_nkw=NICER+DICER+PLUS+CHOPPER&_sop=16"
    },
    {
        "name": "OnePlus Two 64GB",
        "image": "http://i.ebayimg.com/00/s/Mzc4WDcyMA==/z/aUoAAOSwyQtV4-Kg/$_12.JPG",
        "description": "With the OnePlus 2, we have something bold to say. We believe that great products come from great ideas, not multi-million dollar marketing campaigns. We believe \"that’s just the way things are\" is almost always the wrong answer. Most of all, we believe that great things should be shared.",
        "category": "Electronics",
        "price": "34999",
        "quantity": "1",
        "shipping": "100",
        "location": "Punjab",
        "show":true,
        "color": "#E35A4B",
        "link": "http://www.ebay.in/sch/i.html?_nkw=OnePlus+Two&_sop=16"
    },
    {
        "name": "SBH20 Bluetooth",
        "image": "http://i.ebayimg.com/00/s/MzM5WDUwMA==/z/BtcAAOSwjVVV1stp/$_12.JPG",
        "description": "Easier than connecting a cable. Touch once to pair your smartphone with your wireless headset*. If the devices have been disconnected, touch once to re-connect. NFC is pure magic.An ergonomic sliding power key and large tactile music control keys add extreme ease to subtle style. Go wireless.",
        "category": "Electronics",
        "price": "8631",
        "quantity": "3",
        "shipping": "0",
        "location": "Mumbai",
        "show":true,
        "color": "#EB83BC",
        "link": "http://www.ebay.in/sch/i.html?_nkw=sbh20+pink&_sop=16"
    },
    {
        "name": "MAC Mini MGEQ2HN/A",
        "image": "http://i.ebayimg.com/00/s/NDEyWDU1MA==/z/6t8AAOSwq7JUAxCk/$_12.JPG",
        "description": "It’s mini in a massive way. Mac mini is an affordable powerhouse that packs the entire Mac experience into a 19.7cm-square frame. Just connect your own display, keyboard and mouse, and you’re ready to make big things happen.",
        "category": "Electronics",
        "price": "69900",
        "quantity": "10",
        "shipping": "500",
        "location": "Delhi",
        "show":true,
        "color": "#B5AFAE",
        "link": "http://www.ebay.in/sch/i.html?_nkw=MGEQ2HN&_sop=16"
    },
    {
        "name": "Calvin Klein IN2U EDT",
        "image": "http://i.ebayimg.com/00/s/NDAwWDI0Nw==/z/XgAAAOSw-vlVkbJm/$_12.JPG",
        "description": "Man has worked to overpower every other being on this planet and in this time and day when technology leaves no barriers crossed by our kind, Calvin Klein ensures that the path a man leaves behind is remembered, with the signature IN2U EDT.",
        "category": "Fragrances",
        "price": "1499",
        "quantity": "5",
        "shipping": "2",
        "location": "Gandhinagar",
        "color": "#529AC7",
        "show":true,
        "link": "http://www.ebay.in/sch/i.html?_nkw=IN2U+calvin&_sop=16"
    },
    {
        "name": "Canon EOS 700D",
        "image": "http://i.ebayimg.com/00/$T2eC16ZHJGIE9nnWrPjuBRZ(JU5DPg~~_35.JPG",
        "description": "Designed for the creative photographer wanting more to play with, the Canon EOS/ Rebel 18 MP camera comes with IS STM 18-55 mm lens kit. The Canon EOS/ Rebel 18 MP camera with great features and hardened body delivers bright and beautiful pictures in many different conditions, taking you to the next level in photography.",
        "category": "Electronics",
        "price": "36027",
        "quantity": "8",
        "shipping": "50",
        "location": "Manipur",
        "color": "#565859",
        "show":true,
        "link": "http://www.ebay.in/sch/i.html?_nkw=700d&_sop=16"
    },
    {
        "name": "MacBook Air",
        "image": "http://i.ebayimg.com/00/s/Mzc5WDQ5OA==/z/RPIAAOSweW5U9q5g/$_12.JPG",
        "description": "The 11-inch MacBook Air lasts up to 9 hours between charges and the 13-inch model lasts up to an incredible 12 hours. So from your morning coffee till your evening commute, you can work unplugged.Thin. Light. Powerful. And ready for anything.",
        "category": "Electronics",
        "price": "60619",
        "quantity": "4",
        "shipping": "1500",
        "location": "Bangalore",
        "show":true,
        "color": "#9E9E9E",
        "link": "http://www.ebay.in/sch/i.html?_nkw=MD712HN&_sop=16"
    },
    {
        "name": "Apple Watch Sport 42mm",
        "image": "http://i.ebayimg.com/00/s/ODAwWDgwMA==/z/uUcAAOSwgQ9Vn8KZ/$_12.JPG",
        "description": "Apple Watch represents a new chapter in the relationship people have with technology. It’s our most personal product yet, because it’s the first one designed to be worn. Choose from three different leather bands, a high-performance fluoroelastomer band, a link bracelet, and a Milanese loop.Discover some of the things Apple Watch can do.",
        "category": "Watch",
        "price": "38000",
        "quantity": "4",
        "shipping": "1500",
        "location": "Bangalore",
        "show":true,
        "color": "#EB50E5",
        "link": "http://www.ebay.in/sch/i.html?_nkw=apple+watch&_sop=16"
    },
    {
        "name": "Pebble Steel",
        "image": "http://i.ebayimg.com/00/s/NTAwWDUwMA==/z/z50AAOSwNSxVgDDu/$_12.JPG",
        "description": "The Time of Your Life. Pebble Time Puts The Past, Present and Future At Your Fingertips. With an always-on color E-Paper display, up to 7 day battery life, durable glass lens, and thin, curved ergonomic design, you’ll love wearing Pebble Time anywhere and everywhere.",
        "category": "Watch",
        "price": "12300",
        "quantity": "25000",
        "shipping": "0",
        "location": "Chennai",
        "show":true,
        "color": "#B8903B",
        "link": "http://www.ebay.in/sch/i.html?_nkw=pebble+watch&_sop=16"
    },
    {
        "name": "Bracelets",
        "image": "http://i.ebayimg.com/00/s/NjUwWDY1MA==/z/keAAAOSw0e9Utqcg/$_12.JPG",
        "description": "High quality and unique design. Time turner braceletes,eye catching. Fashionable and pretty. Show your charm with this bracelets badge. Suitable for banquet, date, shopping, party and so on. Gorgeous ornament for you and your friends.",
        "category": "Collectibles",
        "price": "399",
        "quantity": "20",
        "shipping": "0",
        "location": "Kolkata",
        "show":true,
        "color": "#FFD375",
        "link": "http://www.ebay.in/sch/i.html?_nkw=Bracelets+Fashion+Vintage&_sop=16"
    }
]; 


const ebayApp=new Vue({
    el:"#ebaylist",
    data:{
        productList:ebayProducts,
        
    },
    methods:{
        toggleDetails:function(product){
            product.show=!product.show
            console.log(product);
        }
    }
    });