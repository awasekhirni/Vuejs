

const vm =new Vue({
  el:'#root-app',
  data:{
    userName:'',
    wishList:[],
    updatedOn:''
  },
  methods:{

  }
})