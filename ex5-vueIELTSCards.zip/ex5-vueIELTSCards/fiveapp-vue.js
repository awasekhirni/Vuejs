
const WordsList= [
      {
        "id": "wordi396cecabdcd04e5d8274c83cd3a4157b",
        "word": "abandon  ",
        "wordtype": " /ə'bændən/   n.  Syn. relinquish ",
        "explanation": " lacking restraint or control; feeling of extreme emotional intensity; unbounded enthusiasm ",
        "wordexample": "With her parents out of town, Kelly danced all night with abandon. ",
        "isflipped": false
      },
      {
        "id": "wordifd7418bcc7e94c6a9be24ab6837022a1",
        "word": "abstract  ",
        "wordtype": " /'æbstrækt/   a.  Syn. theoretical; abstruse ",
        "explanation": " theoretical; not concrete; not applied or practical; difficult to understand ",
        "wordexample": "To him, hunger was an abstract concept; he had never missed a meal. ",
        "isflipped": false
      },
      {
        "id": "wordi98dd5acb5cc74f70b486b21c6d579b93",
        "word": "academy  ",
        "wordtype": " /ə'kædəmɪ/   n.   ",
        "explanation": " school for special instruction; society of scholars, scientists, or artists ",
        "wordexample": "The mission of our academy is actually to ensure the health and the well-being of all children. ",
        "isflipped": false
      },
      {
        "id": "wordi3cbbea4e77294db4bb09b61f64efb584",
        "word": "access  ",
        "wordtype": " /'æksɛs/   n.  Syn. approach ",
        "explanation": " approach; entry; entrance ",
        "wordexample": "It remains to be seen whether the multinationals like Chevron, Exxon Mobil, and BP will give in to Mr Chavez's brinksmanship as they know he needs them as much as they need access to his oil. ",
        "isflipped": false
      },
      {
        "id": "wordib4de6d9cf48a496a8444fdccd0b16b3d",
        "word": "accommodate  ",
        "wordtype": " /ə'kɒmədeɪt/   v.  Syn. adapt; oblige ",
        "explanation": " do a favor or service for; provide for; supply with; make suitable; adapt; allow for ",
        "wordexample": "As for the stage in the public auditorium, it can easily be adjusted to accommodate from a full-scale musical production to one by a solo vocalist. ",
        "isflipped": false
      },
      {
        "id": "wordie2cd149db141454eb797e15c70c2f89e",
        "word": "accompany  ",
        "wordtype": " /ə'kʌmpənɪ/   v.   ",
        "explanation": " travel with; be associated with ",
        "wordexample": "But the night being wet and inclement, Mr. Rochester did not accompany them. ",
        "isflipped": false
      },
      {
        "id": "wordic0c26d862eb3452285880b4c8a79d64f",
        "word": "accumulate  ",
        "wordtype": " /ə'kju mjʊleɪt/   v.  Syn. collect ",
        "explanation": " pile up; collect;  mount up; increase ",
        "wordexample": "The tendency of Capital to accumulate is a big threat to the free market. ",
        "isflipped": false
      },
      {
        "id": "wordi983553e292e24d639938aa145d8b644a",
        "word": "accurate  ",
        "wordtype": " /'ækjʊrət/   a.  Syn. precise; correct ",
        "explanation": " capable of providing a correct reading or measurement; performing with care and precision ",
        "wordexample": "Very Interesting, can anyone tell me, how accurate is the English translation in the posted clip? ",
        "isflipped": false
      },
      {
        "id": "wordifcd8da818ac942858bf09dd2a6a19214",
        "word": "achieve  ",
        "wordtype": " /ə'tʃi v/   v.  Syn. accomplish; fulfill ",
        "explanation": " gain with effort; accomplish; fulfill ",
        "wordexample": "Water, energy, health, agriculture, and biodiversity, require the world's scientific community to come up with the means to achieve sustainable development. ",
        "isflipped": false
      },
      {
        "id": "wordif380257051484d5a9db82e0f86c01703",
        "word": "acknowledge  ",
        "wordtype": " /ək'nɒlɪdʒ/   v.  Syn. recognize; admit ",
        "explanation": " declare to be true or admit; express obligation, thanks ",
        "wordexample": "Although I acknowledge that the Beatles' tunes sound pretty dated today, I still prefer them to the songs my brothers play. ",
        "isflipped": false
      },
      {
        "id": "wordidc3ba67a6e22482681e7af48a80d589f",
        "word": "acquire  ",
        "wordtype": " /ə'kwaɪə(r)/   v.  Syn. obtain; gain ",
        "explanation": " gain through experience or effort; gain possession of; locate with tracking system ",
        "wordexample": "As Norman Mailer once said to me, \"One of the hardest things to acquire is a persona, and you've got one.\" ",
        "isflipped": false
      },
      {
        "id": "wordiba7ee63ef58c4444bdc6ee013ae5496c",
        "word": "adapt  ",
        "wordtype": " /ə'dæpt/   v.  Syn. alter; modify ",
        "explanation": " make fit for; change to suit a new purpose ",
        "wordexample": "One way to adapt is to become smaller, generation by generation. ",
        "isflipped": false
      },
      {
        "id": "wordi2cd01cf69ae54f93a823e92788d5133b",
        "word": "adequate  ",
        "wordtype": " /'ædɪkwət/   a.  Syn. sufficient; enough ",
        "explanation": " sufficient; enough to meet a purpose ",
        "wordexample": "England missed key players through injury, lacked adequate preparation and was unable to match Australia's skill. ",
        "isflipped": false
      },
      {
        "id": "wordi2c4b991f389a449681a17d5711874d26",
        "word": "adjacent  ",
        "wordtype": " /ə'dʒeɪsənt/   a.  Syn. adjoining; neighboring ",
        "explanation": " adjoining; neighboring; close to; lying near ",
        "wordexample": "Philip's best friend Jason lived only four houses down the block, close but not immediately adjacent. ",
        "isflipped": false
      },
      {
        "id": "wordi2437962ce6d64bd38f33fba277806a47",
        "word": "adjust  ",
        "wordtype": " /ə'dʒʌst/   v.  Syn. adapt; regulate ",
        "explanation": " adapt; regulate ",
        "wordexample": "The opera house was handed over by the builders nearly a year ago, but it's taken many months to install new stage machinery and to adjust the acoustics. ",
        "isflipped": false
      },
      {
        "id": "wordia9e9ec57c78141cd9dea97a4d06861fb",
        "word": "administrate  ",
        "wordtype": " /əd'mɪnɪstreɪt/   v.   ",
        "explanation": " administer; supply; supervise or be in charge of ",
        "wordexample": "Remember that Democrats want to increase spending and create more laws which in turn create more government to administrate and enforce. ",
        "isflipped": false
      },
      {
        "id": "wordif0bf710cf6b34309ab1f6156e9bfeafa",
        "word": "adult  ",
        "wordtype": " /'ædʌlt/   n.   ",
        "explanation": " one who has attained maturity or legal age; fully grown ",
        "wordexample": "Not clear from the video if the adult is a man or woman, but he or she is facing charges of endangering the welfare of a child. ",
        "isflipped": false
      },
      {
        "id": "wordi2f78c8e97c294170a73f5485d93e751e",
        "word": "advocate  ",
        "wordtype": " /'ædvəkət/   v.  Syn. urge; support ",
        "explanation": " speak, plead, or argue in favour of; plead for; push for something ",
        "wordexample": "The some doctors advocate a smoking ban in the entire house. ",
        "isflipped": false
      },
      {
        "id": "wordi951c4da49b7e41c5a73d76e5c907b16a",
        "word": "affect  ",
        "wordtype": " /ə'fɛkt/   v.   ",
        "explanation": " have an emotional or cognitive impact upon ",
        "wordexample": "The move is likely to affect women and girls all over the world as international brands such as Mango and Zara have signed up to the agreement. ",
        "isflipped": false
      },
      {
        "id": "wordi2e640e06231249a2b8a28e01fb235b74",
        "word": "aggregate  ",
        "wordtype": " /'ægrɪgət/   v.  Syn. gather; accumulate ",
        "explanation": " gather into a mass, sum, or whole; amount to ",
        "wordexample": "Before the Wall Street scandals, dealers managed to aggregate great wealth in short periods of time. ",
        "isflipped": false
      },
      {
        "id": "wordi063318616f04448a98ca467cfdafa41f",
        "word": "aid  ",
        "wordtype": " /eɪd/   n.   ",
        "explanation": " person or thing that promotes or helps in something done; helper; assistant ",
        "wordexample": "The company has also asked for an additional 3.50 billion dollars in aid from the government. ",
        "isflipped": false
      },
      {
        "id": "wordi82409a560414475a86b7481b66df446c",
        "word": "albeit  ",
        "wordtype": " /ɔ l'bi ɪt/   ad.   ",
        "explanation": " even though; although; notwithstanding ",
        "wordexample": "This question bothers me, albeit from a different perspective. ",
        "isflipped": false
      },
      {
        "id": "wordi7189af63037f46f7a1c8c80fd1539ae5",
        "word": "allocate  ",
        "wordtype": " /'æləkeɪt/   v.  Syn. assign ",
        "explanation": " assign; distribute according to plan ",
        "wordexample": "Even though the Red Cross did allocate a large sum for the relief of the sufferers of the disaster, many people perished. ",
        "isflipped": false
      },
      {
        "id": "wordi7f78271f88364249afd6f4da63664f4a",
        "word": "alter  ",
        "wordtype": " /'ɔ ltə(r)/   v.  Syn. modify; change; convert ",
        "explanation": " modify; cause to change; make different; convert ",
        "wordexample": "In public neither Mr. Blair's visit nor the regional summit in Nepal has done anything to alter India's position on dialogue with Pakistan. ",
        "isflipped": false
      },
      {
        "id": "wordi6b44f7a9027d4e2ea94f5a3ea66bf3f6",
        "word": "alternative  ",
        "wordtype": " /ɔ l'tɜrnətɪv/   a.   ",
        "explanation": " one of two or more things, ideas or courses of action that may be used; option; choice ",
        "wordexample": "Electron Instruments believed its desktop SEM was vastly superior to the next best alternative from a Japanese competitor. ",
        "isflipped": false
      },
      {
        "id": "wordi5c98844c9c1c443f8b48e0e63e95f62e",
        "word": "ambiguous  ",
        "wordtype": " /æm'bɪgjʊəs/   a.   ",
        "explanation": " unclear or doubtful in meaning ",
        "wordexample": "His ambiguous instructions misled us; we did not know which road to take. ",
        "isflipped": false
      },
      {
        "id": "wordi2a7b27620c4e4d809f4db2307bb33033",
        "word": "amend  ",
        "wordtype": " /ə'mɛnd/   v.  Syn. correct; improve ",
        "explanation": " change for the better; improve; remove faults or errors ",
        "wordexample": "Would McCain amend executive orders to ensure that communications between persons outside government and White House staff are disclosed to the public? ",
        "isflipped": false
      },
      {
        "id": "wordia37d654c03b64e68b10f1b6f0b1ab10c",
        "word": "analogy  ",
        "wordtype": " /ə'nælədʒɪ/   n.  Syn. similarity; parallelism ",
        "explanation": " similarity in some respects; comparison based on similarity ",
        "wordexample": "This analogy is almost always noted without further comment, although in fact it may be taken further. ",
        "isflipped": false
      },
      {
        "id": "wordi57b7b680158545b6a50dae43c4c4b5c8",
        "word": "analyse  ",
        "wordtype": " /'ænəlaɪz/   v.   ",
        "explanation": " resolve anything complex into its elements; separate into parts for purpose of examination of each separately ",
        "wordexample": "Don't spend all day calling agents about fees - pick three in your locality and analyse which is the best one. ",
        "isflipped": false
      },
      {
        "id": "wordte02c2122b7af4928bcd9e422da2ca5a0",
        "word": "analysis  ",
        "wordtype": " /ə'næləsɪs/   n.  Syn. study; investigation ",
        "explanation": " study; investigation;  process of breaking down a substance into its constituent parts ",
        "wordexample": "You can read more about those studies here, and my analysis is here. ",
        "isflipped": false
      },
      {
        "id": "wordi7385d9f46b5540349149e421ce1a3a20",
        "word": "annual  ",
        "wordtype": " /'ænjʊəl/   a.   ",
        "explanation": " occurring or payable every year ",
        "wordexample": "It says that the Queen's role in the annual state opening of parliament should be changed. ",
        "isflipped": false
      },
      {
        "id": "wordi9ad310f26c464c2eb7b0bb5a0416a002",
        "word": "anticipate  ",
        "wordtype": " /æn'tɪsɪpeɪt/   v.  Syn. expect; predict ",
        "explanation": "  act in advance of; deal with ahead of time; predict ",
        "wordexample": "Nature seemed to me benign and good; I thought she loved me, outcast as I was; and I, who from man could anticipate only mistrust, rejection, insult, clung to her with filial fondness. ",
        "isflipped": false
      },
      {
        "id": "wordi7fd174dd484c49cbb83e6bd996b5e90f",
        "word": "apparent  ",
        "wordtype": " /ə'pærənt/   a.  Syn. visible ",
        "explanation": " capable of being seen, or easily seen; open to view; visible to eye ",
        "wordexample": "It is apparent to all that he was guilty; do you think anyone still trusts him now? ",
        "isflipped": false
      },
      {
        "id": "wordic98db1bc94f6406d97def03518ffc734",
        "word": "append  ",
        "wordtype": " /ə'pɛnd/   v.  Syn. attach ",
        "explanation": " attach; add as supplement or appendix ",
        "wordexample": "When you append a bibliography to a text, you have just created an supplementary material. ",
        "isflipped": false
      },
      {
        "id": "wordi7976a07d6c7044b6925efd4b495dc37d",
        "word": "appreciate  ",
        "wordtype": " /ə'pri ʃɪeɪt/   v.  Syn. admire; value ",
        "explanation": " be thankful for; increase in worth; be thoroughly conscious of ",
        "wordexample": "I am truly thankful for the stocks, which would appreciate in value considerably in future years. ",
        "isflipped": false
      },
      {
        "id": "wordi33ec93b072a04d969afaea8a42a52f8b",
        "word": "approach  ",
        "wordtype": " /ə'proʊtʃ/   n.  Syn. access; method ",
        "explanation": " access; method ",
        "wordexample": "Faced with an increasingly competitive jobs market and frequent bad publicity over pay and conditions, the army is getting ever more sophisticated and corporate in its approach to recruitment. ",
        "isflipped": false
      },
      {
        "id": "wordi6f09c5b37f4844149179f6d2743282a3",
        "word": "appropriate  ",
        "wordtype": " /ə'proʊprɪət/   v.  Syn. acquire; allocate ",
        "explanation": " acquire; take possession of for one's own use; set apart for specific use ",
        "wordexample": "The ranch owners appropriate the lands that have originally been set aside for the Indians' use. ",
        "isflipped": false
      },
      {
        "id": "wordi649481603eaf420ca1c39f07cf05dcfa",
        "word": "approximate  ",
        "wordtype": " /ə'prɒksɪmət/   v.  Syn. approach ",
        "explanation": " approach; come near ",
        "wordexample": "The conclusions of yours both approximate to the truth. ",
        "isflipped": false
      },
      {
        "id": "wordi93a2a1b190464af2a3817e1c88104753",
        "word": "arbitrary  ",
        "wordtype": " /'ɑrbɪtrərɪ/;/'ɑrrbɪtrɛrɪ/   a.  Syn. capricious; impulse ",
        "explanation": " randomly chosen; determined by chance or impulse, and not by reason or principle ",
        "wordexample": "He threw an arbitrary assortment of clothes into his suitcase and headed off, not caring where he went. ",
        "isflipped": false
      },
      {
        "id": "wordi36429ac49089484cb8ae21fadff2f788",
        "word": "area  ",
        "wordtype": " /'ɛərɪə/   n.   ",
        "explanation": " plane surface, as of the floor of a room; open space in a building; the enclosed space; extent; scope; range ",
        "wordexample": "His special interest lies in the area of literature. ",
        "isflipped": false
      },
      {
        "id": "wordi6ae6dd283b484064a03381a32e8e2c72",
        "word": "aspect  ",
        "wordtype": " /'æspɛkt/   n.  Syn. respect; facet ",
        "explanation": " distinct feature or element in a problem; a way in which something can be viewed by the mind ",
        "wordexample": "And I guess as his coming back, the education aspect is more on display than the others. ",
        "isflipped": false
      },
      {
        "id": "wordi9385280ea13c4ec7bd560ae5602776d8",
        "word": "assemble  ",
        "wordtype": " /ə'sɛmb(ə)l/   v.  Syn. gather ",
        "explanation": " put together; bring or call together into a group or whole ",
        "wordexample": "Washington announced its decision to dissolve the core group of nations, the US, India, Japan and Australia, it would assemble to deliver aid. ",
        "isflipped": false
      },
      {
        "id": "wordif1bcb62fd5fc49d18b32a5c917278b4f",
        "word": "assess  ",
        "wordtype": " /ə'sɛs/   v.  Syn. estimate; judge ",
        "explanation": "  estimate  value; judge worth of something ",
        "wordexample": "They say that they lack both the money and the resources to deploy officials across the country to assess the safety of each and every ferry. ",
        "isflipped": false
      },
      {
        "id": "wordi1dc4953de0324fb6878e5884d76a6fe9",
        "word": "assign  ",
        "wordtype": " /ə'saɪn/   v.  Syn. appoint; allot ",
        "explanation": " appoint; allot; make over; point out authoritatively or exactly ",
        "wordexample": "Never underrate the difficulties which your pupils will have to encounter, or try to persuade them that what you assign is easy. ",
        "isflipped": false
      },
      {
        "id": "wordib57e0d7ceefc478f850a99b9f02bd0da",
        "word": "assist  ",
        "wordtype": " /ə'sɪst/   v.  Syn. help ",
        "explanation": " give help or support to, especially as a subordinate ",
        "wordexample": "A good way to assist is to bring entrepreneurial and business skills to them. ",
        "isflipped": false
      },
      {
        "id": "wordi144c8ab40cd84b86b55627d0d50e0e5f",
        "word": "assume  ",
        "wordtype": " /ə'sju m/;/ə'su m/   v.  Syn. suppose; presume ",
        "explanation": " suppose; presume; take on; bear ",
        "wordexample": "He looked at me long and hard  I turned my eyes from him, fixed them on the fire, and tried to assume and maintain a quiet. ",
        "isflipped": false
      },
      {
        "id": "wordi417d98c0b2be45298a248a4408f97d79",
        "word": "assure  ",
        "wordtype": " /ə'ʃʊə(r)/;/ə'ʃʊər/   v.  Syn. solidify; guarantee; convince ",
        "explanation": " solidify; guarantee; convince ",
        "wordexample": "I know it, and I don't wish to palliate them, I assure you. ",
        "isflipped": false
      },
      {
        "id": "wordi6d26aa4a4aae49c496aa716947a908ef",
        "word": "attach  ",
        "wordtype": " /ə'tætʃ/   v.  Syn. fasten; annex ",
        "explanation": " fasten; annex; be in contact with ",
        "wordexample": "The anti-nuclear campaigners used concrete blocks and chains to attach themselves to the rails. ",
        "isflipped": false
      },
      {
        "id": "wordi051bedb9f5fd4e7cafe6933e428fe280",
        "word": "attain  ",
        "wordtype": " /ə'teɪn/   v.  Syn. gain ",
        "explanation": " achieve or accomplish; gain ",
        "wordexample": "The scarecrow sought to attain one goal  he wished to obtain a brain. ",
        "isflipped": false
      },
      {
        "id": "wordif335c87ae9fb4e6e895c67ac2abe11fb",
        "word": "attitude  ",
        "wordtype": " /'ætɪtju d/;/'ætɪtud/   n.   ",
        "explanation": " posture, action, or disposition of a figure or a statue ",
        "wordexample": "One of the major reasons for this change in attitude is that there's more money around. ",
        "isflipped": false
      },
      {
        "id": "wordid61dca8c5f104fd8a68012c4c986bf52",
        "word": "attribute  ",
        "wordtype": " /ə'trɪbju t/   n.  Syn. trait ",
        "explanation": " essential quality; reputation; honor ",
        "wordexample": "His outstanding attribute was his kindness. ",
        "isflipped": false
      },
      {
        "id": "wordicdd54746390e4b4f8d643c141f1161ab",
        "word": "author  ",
        "wordtype": " /'ɔ θə(r)/   n.   ",
        "explanation": " beginner, former, or first mover of anything; creator; originator; one who composes or writes book or composer ",
        "wordexample": "The mayor of the village, in delivering the prize to the author of it, made a warm speech. ",
        "isflipped": false
      },
      {
        "id": "wordi212ecd7dce2c4272a5a97041a79b3a65",
        "word": "authority  ",
        "wordtype": " /ɔ 'θɒrɪtɪ/   n.  Syn. jurisdiction; power ",
        "explanation": " jurisdiction; power to enforce laws, exact obedience, command, determine, or judge; government ",
        "wordexample": "The laws will reinforce Australia's authority to turn boats away from Australia. ",
        "isflipped": false
      },
      {
        "id": "wordif53850c870f64dc2b2f5928a33b9a482",
        "word": "automate  ",
        "wordtype": " /'ɔ təmeɪt/   v.   ",
        "explanation": " replace or enhance human labor with machines ",
        "wordexample": "The other reason to automate is to get people out of the dangerous circumstance. ",
        "isflipped": false
      },
      {
        "id": "wordiaa874966f21d467480fb21340bc4780d",
        "word": "available  ",
        "wordtype": " /ə'veɪləb(ə)l/   a.  Syn. free ",
        "explanation": " convenient for use or disposal; not busy, free; obtainable; accessible ",
        "wordexample": "Vaccines are available but are costly and only offer relatively short-term protection so the animals need regular booster vaccinations. ",
        "isflipped": false
      },
      {
        "id": "wordi2c9258bfcaec4e4d8642d9f2c128f991",
        "word": "aware  ",
        "wordtype": " /ə'wɛə(r)/   a.   ",
        "explanation": " knowing; having knowledge or cognizance ",
        "wordexample": "BPA, as you're likely aware, is a chemical commonly found in plastics, food cans, and water bottles. ",
        "isflipped": false
      },
      {
        "id": "wordi21da9b0c8dd44537a15afea1db029b25",
        "word": "behalf  ",
        "wordtype": " /bɪ'hɑrf/   n.  Syn. represent ",
        "explanation": " represent;  advantage, benefit, interest of someone ",
        "wordexample": "And I'm going to work to assure that that voice that is heard on their behalf is a roar and not a whisper. ",
        "isflipped": false
      },
      {
        "id": "wordi1d280b7fbe854561b89f40a2345d46ac",
        "word": "benefit  ",
        "wordtype": " /'bɛnɪfɪt/   n.  Syn. welfare; gain ",
        "explanation": " advantage; something that aids or promotes well-being ; welfare; gain ",
        "wordexample": "Another benefit for business is the elimination of currency risk in the Euro area - the possibility that you might lose money in cross border trade because of exchange rate movements. ",
        "isflipped": false
      },
      {
        "id": "wordibdd4321ca7dc406890e0532a1dfbadbc",
        "word": "bias  ",
        "wordtype": " /'baɪəs/   n.  Syn. prejudice; preference ",
        "explanation": " preference or inclination, especially one that inhibits impartial judgment;  influence in unfair way ",
        "wordexample": "Now that I can daily watch their news reports on Star Choice, I can tell you that the bias is as deep there as anywhere. ",
        "isflipped": false
      },
      {
        "id": "wordi73eaf4a7df1146e4994a5f06ee271426",
        "word": "bond  ",
        "wordtype": " /bɒnd/   n.  Syn. link; tie; connection ",
        "explanation": " link; connection; uniting force or tie; binding agreement; duty ",
        "wordexample": "Last year, the average short-term bond fund gained about 9%, according to Morningstar. ",
        "isflipped": false
      },
      {
        "id": "wordi02d5bd3d9409407a91a3bda755582697",
        "word": "brief  ",
        "wordtype": " /bri f/   a.   ",
        "explanation": " short in time, duration, length, or extent; concise ",
        "wordexample": "When my brief career as a pop star ended, I found I had done fairly well. ",
        "isflipped": false
      },
      {
        "id": "wordi6a5e587e3ac749cba2f3d66382d05c0e",
        "word": "bulk  ",
        "wordtype": " /bʌlk/   n.  Syn. majority; mass ",
        "explanation": " majority; main part; volume; mass ",
        "wordexample": "Canada's largest bulk food retailer, it has more than 112 stores. ",
        "isflipped": false
      },
      {
        "id": "wordiffbbdd050d98456f90276e26af80c271",
        "word": "capable  ",
        "wordtype": " /'keɪpəb(ə)l/   a.  Syn. competent ",
        "explanation": " having the ability required for a specific task ",
        "wordexample": "Canadian politicians have been in capable of ending this primitive practice. ",
        "isflipped": false
      },
      {
        "id": "wordi5184827168bf4c0e99dc4557cd2be90d",
        "word": "capacity  ",
        "wordtype": " /kə'pæsɪtɪ/   n.  Syn. volume; ability; capability ",
        "explanation": " mental or physical ability; ability to accommodate ",
        "wordexample": "Mike had the capacity to handle several jobs at once. ",
        "isflipped": false
      },
      {
        "id": "wordi54d2ee6e8ddd45cd8de24c96e16f8db3",
        "word": "category  ",
        "wordtype": " /'kætɪgərɪ/   n.  Syn. group ",
        "explanation": " group; class; collection of things sharing a common attribute ",
        "wordexample": "Remember, all cars are priced, booked and controlled by car category, not by car maker or model. ",
        "isflipped": false
      },
      {
        "id": "wordic55aef365fa74eb7b433a604d4f72604",
        "word": "cease  ",
        "wordtype": " /si s/   v.  Syn. stop; terminate ",
        "explanation": " stop; terminate; put an end to; discontinue ",
        "wordexample": "We must not only cease from the acts of sin, but we must get the vicious habits and inclinations weakened and destroyed. ",
        "isflipped": false
      },
      {
        "id": "wordi2826f3dbcf544505982e985ea3419e7a",
        "word": "challenge  ",
        "wordtype": " /'tʃælɪndʒ/   v.   ",
        "explanation": " assert a right; raise a formal objection; take exception to ",
        "wordexample": "Nowadays no one will challenge the fact that the earth is round. ",
        "isflipped": false
      },
      {
        "id": "wordi04d28bd81f204118b3e65742c078f64c",
        "word": "channel  ",
        "wordtype": " /'tʃæn(ə)l/   n.   ",
        "explanation": " passage for water or other fluids to flow through; bed of a stream or river; route of communication or access ",
        "wordexample": "You should take her request through official channel, there is no private room for her issue. ",
        "isflipped": false
      },
      {
        "id": "wordi02de1998a19048339eb696abd9253887",
        "word": "chapter  ",
        "wordtype": " /'tʃæptə(r)/   n.   ",
        "explanation": " division of a book or treatise; assembly of monks; bishop's council; organized branch of some society ",
        "wordexample": "A new chapter in a novel is something like a new scene in a play. ",
        "isflipped": false
      },
      {
        "id": "wordi8ed193fb94a64149bb16dd6751f06d80",
        "word": "chart  ",
        "wordtype": " /tʃɑrt/   n.  Syn. graph; diagram ",
        "explanation": " graph; diagram;  map showing coastlines, water depths, or other information of use to navigators ",
        "wordexample": "A fisherman's chart may be the crucial evidence which finally help to put to rest the mystery of what happened to Roald Amundsen. ",
        "isflipped": false
      },
      {
        "id": "wordia0ba949f43374641ada5b60d1dad556c",
        "word": "circumstance  ",
        "wordtype": " /'sɜrkəmstəns/   n.  Syn. situation; condition ",
        "explanation": " situation; condition; detail accompanying or surrounding an event ",
        "wordexample": "Her heart is broken, but then a change in circumstance forces them to be together every day. ",
        "isflipped": false
      },
      {
        "id": "wordie1909b07c1b54a87ba8a0203eed533c2",
        "word": "cite  ",
        "wordtype": " /saɪt/   v.  Syn. quote ",
        "explanation": " quote; adduce as an instance ",
        "wordexample": "She could cite passages in the Bible from memory. ",
        "isflipped": false
      },
      {
        "id": "wordi2a3c83c8ca74414a97e7418d2a0a5313",
        "word": "civil  ",
        "wordtype": " /'sɪv(ə)l/   a.  Syn. civic ",
        "explanation": " having to do with citizens or the state; courteous and polite ",
        "wordexample": "Although Internal Revenue Service agents are civil servants, they are not always courteous to suspected tax cheats. ",
        "isflipped": false
      },
      {
        "id": "wordie59de6f6006a47c2ae56785c72db1ec1",
        "word": "clarify  ",
        "wordtype": " /'klærɪfaɪ/   v.  Syn. illuminate; elucidate ",
        "explanation": " make clear and comprehensible; elucidate ",
        "wordexample": "A Japanese delegation has started talks in North Korea to try to clarify the fate of at least ten Japanese citizens who were abducted by the communist state. ",
        "isflipped": false
      },
      {
        "id": "wordi3dd12f3491b345f2888d0817b28f39e8",
        "word": "classic  ",
        "wordtype": " /'klæsɪk/   n.   ",
        "explanation": " work of acknowledged excellence and authority, or its author; creation of the highest excellence ",
        "wordexample": "His face was like a Greek face, very pure in outline  quite a straight, classic nose; quite an Athenian mouth and chin. ",
        "isflipped": false
      },
      {
        "id": "wordi0c3784f7557c49bf93867091d619bb80",
        "word": "clause  ",
        "wordtype": " /klɔ z/   n.  Syn. sentence; phrase ",
        "explanation": " sentence; phrase; distinct article, stipulation, or provision in a document ",
        "wordexample": "Congress insisted on an exclusion clause for seventeen-year-olds. ",
        "isflipped": false
      },
      {
        "id": "wordi43253e1a6d8c46e29eec9e9a62dd146d",
        "word": "code  ",
        "wordtype": " /koʊd/   n.   ",
        "explanation": " body of law; system of rules or regulations relating to one subject; system of symbols, letters, or words ",
        "wordexample": "Do you know the postal code of this postal district? ",
        "isflipped": false
      },
      {
        "id": "wordia2f7015a0b8d4fd2a06b1a1680fd8450",
        "word": "coherent  ",
        "wordtype": " /koʊ'hɪərənt/   a.  Syn. adhesive; cohesive ",
        "explanation": " adhesive; cohesive; sticking together ; logical; sound; capable of thinking and expressing yourself in a clear and consistent manner ",
        "wordexample": "If the EU is to form any kind of coherent common foreign policy, it needs France and Britain singing from the same song sheet. ",
        "isflipped": false
      },
      {
        "id": "wordiaf9b92e9e80649939ebe0e63065cebbe",
        "word": "coincide  ",
        "wordtype": " /koʊɪn'saɪd/   v.  Syn. correspond ",
        "explanation": " occur at the same time as; correspond ",
        "wordexample": "To coincide with World AIDS Day, the World Health Organization and UN AIDS are launching a campaign to treat three million HIV sufferers by the year 2005. ",
        "isflipped": false
      },
      {
        "id": "wordic60d906790d14cf6be1c352159803ce8",
        "word": "collapse  ",
        "wordtype": " /kə'læps/   v.   ",
        "explanation": " breakdown; failure ",
        "wordexample": "The streets of Baghdad are littered with putrefying mounds of rubbish that have been accumulating since the collapse of municipal services in March, with the arrival of coalition forces. ",
        "isflipped": false
      },
      {
        "id": "wordifd7a07dbfbcf4da9881e453f2682969a",
        "word": "colleague  ",
        "wordtype": " /'kɒli g/   n.  Syn. associate ",
        "explanation": " fellow worker; associate; co-worker ",
        "wordexample": "The abduction of the Italians, along with one Iraqi colleague, was claimed by several organizations. ",
        "isflipped": false
      },
      {
        "id": "wordi645688ccfed8419d843d47abc81dea99",
        "word": "commence  ",
        "wordtype": " /kə'mɛns/   v.  Syn. originate; start; begin ",
        "explanation": " have a beginning or origin; originate; start; begin ",
        "wordexample": "Mrs. Fairfax swallowed her breakfast and hastened away to commence operations. ",
        "isflipped": false
      },
      {
        "id": "wordie01bb748512d49df8372b8858f7ca4f3",
        "word": "comment  ",
        "wordtype": " /'kɒmɛnt/   v.  Syn. remark; judgment ",
        "explanation": " express an opinion; remark ",
        "wordexample": "She refused to comment about David Beckham's eye injury. ",
        "isflipped": false
      },
      {
        "id": "wordi8f3b066e4c3142ab975e7c5ce3b02acc",
        "word": "commission  ",
        "wordtype": " /kə'mɪʃ(ə)n/   n.   ",
        "explanation": " fee for services; group of people appointed to find out about something; authorize ",
        "wordexample": "China has hit back, its foreign ministry urging the Congressional commission to wipe out its prejudice, respect the truth. ",
        "isflipped": false
      },
      {
        "id": "wordi70064ab5770c4dc69426ff18da0c4213",
        "word": "commit  ",
        "wordtype": " /kə'mɪt/   v.   ",
        "explanation": " do something that cannot be changed; cause to be admitted ",
        "wordexample": "And small bands of extremists may again commit heinous crimes in the name of faith. ",
        "isflipped": false
      },
      {
        "id": "wordi5758874bc94644fca5da0740f9397163",
        "word": "commodity  ",
        "wordtype": " /kə'mɒdɪtɪ/   n.  Syn. goods ",
        "explanation": " goods; article of trade; advantage; benefit. ",
        "wordexample": "While some world stock and commodity markets show signs of calming down, China is usually an exception. ",
        "isflipped": false
      },
      {
        "id": "wordi896057428e2740e59ebb06a85cca273f",
        "word": "communicate  ",
        "wordtype": " /kə'mju nɪkeɪt/   v.  Syn. convey; inform; correspond ",
        "explanation": " send information about; make known; impart; reveal clearly ",
        "wordexample": "Well, it came to me that the best way to communicate is to have direct, personal contact with people. ",
        "isflipped": false
      },
      {
        "id": "wordi144c4c846a094b978609456ce3d1229c",
        "word": "community  ",
        "wordtype": " /kə'mju nɪtɪ/   n.  Syn. society; district ",
        "explanation": " society; a group of people living in the same locality and under the same government ",
        "wordexample": "Where governments manage public life, human freedom in community is compromised. ",
        "isflipped": false
      },
      {
        "id": "wordi1fb8c1dcd85e4b12be07582dca80bbf4",
        "word": "compatible  ",
        "wordtype": " /kəm'pætɪb(ə)l/   a.  Syn. harmonious ",
        "explanation": " harmonious; having similar disposition and tastes ",
        "wordexample": "They were compatible neighbors, never quarreling over unimportant matters. ",
        "isflipped": false
      },
      {
        "id": "wordid365050c986c43778afa591fde028c02",
        "word": "compensate  ",
        "wordtype": " /'kɒmpɛnseɪt/   v.  Syn. make up; reimburse ",
        "explanation": " make amends for; reimburse ",
        "wordexample": "He said improved trade would compensate for the jobs lost to competition from India's world beating out-sourcing and computer software industries. ",
        "isflipped": false
      },
      {
        "id": "wordi8c568fca220f453298cfaa72fef30ea7",
        "word": "compile  ",
        "wordtype": " /kəm'paɪl/   v.  Syn. assemble; gather; accumulate ",
        "explanation": " put together or compose from materials gathered from several sources ",
        "wordexample": "We planned to compile a list of the words most frequently used on these examinations. ",
        "isflipped": false
      },
      {
        "id": "wordi467354850ce147dc897870f51a98afb9",
        "word": "complement  ",
        "wordtype": " /'kɒmpləmənt/   v.  Syn. complete; consummate ",
        "explanation": " complete; consummate; make perfect ",
        "wordexample": "The waiter recommended a glass of port to complement the cheese. ",
        "isflipped": false
      },
      {
        "id": "wordiad31e7d6b33b436ab47d021b9f9cf096",
        "word": "complex  ",
        "wordtype": " /'kɒmplɛks/   a.  Syn. intricate; compound ",
        "explanation": " complicated in structure; a whole structure, as a building, made up of interconnected or related structures ",
        "wordexample": "Prescott's speech comes as ministers from around the world struggle to overcome complex arguments about how the Kyoto agreement on cutting greenhouse gas emissions should work. ",
        "isflipped": false
      },
      {
        "id": "wordic0e2e3bc44324d19891856bbff3ac746",
        "word": "component  ",
        "wordtype": " /kəm'poʊnənt/   n.  Syn. element; ingredient ",
        "explanation": " element; ingredient; abstract part of something ",
        "wordexample": "I wish this component like all others of my stereo system is working at the same time. ",
        "isflipped": false
      },
      {
        "id": "wordi864740571c934da9b1390c68e7ad2923",
        "word": "compound  ",
        "wordtype": " /kɒm'paʊnd/   v.  Syn. combine; constitute ",
        "explanation": " combine; mix; constitute; pay interest; increase ",
        "wordexample": "The makers compound the ingredients by design. ",
        "isflipped": false
      },
      {
        "id": "wordifcb50531ac8847a8a6dde7a14d04268d",
        "word": "comprehensive  ",
        "wordtype": " /kɒmprɪ'hɛnsɪv/   a.  Syn. thorough; inclusive ",
        "explanation": " thorough; including all or everything; broad in scope ",
        "wordexample": "Mr. Skubel has since completed what he describes as a comprehensive two-week training program and is now setting up his franchise in his hometown. ",
        "isflipped": false
      },
      {
        "id": "wordi9bc989b0976843b1a0486b314c5c729c",
        "word": "comprise  ",
        "wordtype": " /kəm'praɪz/   v.  Syn. include ",
        "explanation": " include; consist of; be composed of ",
        "wordexample": "If the District of Columbia were to be granted statehood, the United States of America would comprise fifty-one states, not just fifty. ",
        "isflipped": false
      },
      {
        "id": "wordi90652d0b9416405fb117f357c31e1ec9",
        "word": "compute  ",
        "wordtype": " /kəm'pju t/   v.  Syn. reckon; calculate ",
        "explanation": " reckon; make mathematical calculation ",
        "wordexample": "He failed to compute the interest, so his bank balance was not accurate. ",
        "isflipped": false
      },
      {
        "id": "wordiddec20ace97a47b586f3605bb0a8b716",
        "word": "conceive  ",
        "wordtype": " /kən'si v/   v.  Syn. design; consider ",
        "explanation": " form or develop in the mind; devise; become pregnant with; begin or originate in a specific way ",
        "wordexample": "I asked was it a mere nervous impression--a delusion? I could not conceive or believe  it was more like an inspiration. ",
        "isflipped": false
      },
      {
        "id": "wordiebe20dee1ffd43cea6651e9ec294ec64",
        "word": "concentrate  ",
        "wordtype": " /'kɒnsəntreɪt/   v.   ",
        "explanation": " bring to or direct toward a common center; unite more closely; gather into one body ",
        "wordexample": "I was now able to concentrate my attention on the group by the fire. ",
        "isflipped": false
      },
      {
        "id": "wordi556f98983d264a279c7966da4a5fee91",
        "word": "concept  ",
        "wordtype": " /'kɒnsɛpt/   n.  Syn. notion; idea ",
        "explanation": " something formed in the mind; thought or notion ",
        "wordexample": "The local chain concept is simple  identify your customer, cater to their tastes and once successful, expand within a neighborhood. ",
        "isflipped": false
      },
      {
        "id": "wordi3c17353b37564a4db502890d03a975f1",
        "word": "conclude  ",
        "wordtype": " /kən'klu d/   v.  Syn. deduce; infer ",
        "explanation": " enclose; reach as an end of reasoning; make final determination ; judge or decide; bring to an end ",
        "wordexample": "From his appearance we may safely conclude that he is a smoker. ",
        "isflipped": false
      },
      {
        "id": "wordia041fe9b5e2e4c7887c91615b63a821d",
        "word": "concurrent  ",
        "wordtype": " /kən'kʌrənt/   a.  Syn. simultaneous; coincident ",
        "explanation": " simultaneous; coincident; occurring or operating at the same time ",
        "wordexample": "The Winter War fought between Finland and the Soviet Union, was a concurrent war to World War II, and thus is covered in its own main article. ",
        "isflipped": false
      },
      {
        "id": "wordi19ba535cf6d54a24bd620e6fd021f04d",
        "word": "conduct  ",
        "wordtype": " /'kɒndʌkt/   v.  Syn. accompany; direct ",
        "explanation": " direct the course of; manage or control; lead or guide ",
        "wordexample": "You cannot conduct business like this. ",
        "isflipped": false
      },
      {
        "id": "wordi0f5e721163ac4e00bf35c5f65ffda4d6",
        "word": "confer  ",
        "wordtype": " /kən'fɜr(r)/   v.   ",
        "explanation": " bestow; present; have a conference in order to talk something over  ",
        "wordexample": "The sternest-seeming stoic is human after all; and to \"burst\" with boldness and good-will into \"the silent sea\" of their souls is often to confer on them the first of obligations. ",
        "isflipped": false
      },
      {
        "id": "wordi4cae83fed1d445b6b541750e544c6c68",
        "word": "confine  ",
        "wordtype": " /kən'faɪn/   v.  Syn. limit; circumscribe ",
        "explanation": " restrict in movement; circumscribe ",
        "wordexample": "You may take the maniac with you to England; confine her with due attendance and precautions at Thornfield. ",
        "isflipped": false
      },
      {
        "id": "wordief3deb7400b243d8a1cc5bb271f9c4a8",
        "word": "confirm  ",
        "wordtype": " /kən'fɜrm/   v.  Syn. verify; corroborate ",
        "explanation": " support or establish the certainty or validity of; verify ",
        "wordexample": "In the aftermath of Saturday's mass poisoning, the authorities imposed a virtual news blackout, refusing even to confirm how many people had died. ",
        "isflipped": false
      },
      {
        "id": "wordi6fcde257d4d741f888e3f22fca62b492",
        "word": "conflict  ",
        "wordtype": " /'kɒnflɪkt/   n.  Syn. fight; struggle ",
        "explanation": " fight; struggle; incompatibility of dates or events ",
        "wordexample": "Malnutrition rates have now been cut by half since the start of the conflict, according to the United Nations. ",
        "isflipped": false
      },
      {
        "id": "wordi12c0de85ab1948dd899470f8e3202510",
        "word": "conform  ",
        "wordtype": " /kən'fɔ m/   v.   ",
        "explanation": " comply with; follow; fit; meet ",
        "wordexample": "Why, in defiance of every precept and principle of this house, does she conform to the world so openly--here in an evangelical, charitable establishment--as to wear her hair one mass of curls? ",
        "isflipped": false
      },
      {
        "id": "wordi1c0793ce34304a44bf088e080f332f42",
        "word": "consent  ",
        "wordtype": " /kən'sɛnt/   v.  Syn. accord; concur; allow ",
        "explanation": " agree in opinion or sentiment; be of the same mind; accord; concur; allow ",
        "wordexample": "They can still make speeches and advise and consent, however, they won't have any real power. ",
        "isflipped": false
      },
      {
        "id": "wordi3f68197e9b5e463cb196637e4573484d",
        "word": "consequent  ",
        "wordtype": " /'kɒnsɪkwənt/   a.  Syn. resulting ",
        "explanation": " resulting; following as a logical conclusion ",
        "wordexample": "His retirement and consequent spare time enabled him to travel more. ",
        "isflipped": false
      },
      {
        "id": "wordiabb53a6ee7c24b12a33d98415fccf183",
        "word": "considerable  ",
        "wordtype": " /kən'sɪdərəb(ə)l/   a.  Syn. significant ",
        "explanation": " worthy of consideration; large in amount, extent, or degree ",
        "wordexample": "The Tigers are insisting on an interim administration for the north east of the island, giving them considerable powers. ",
        "isflipped": false
      },
      {
        "id": "wordi654fb6ca41784913aba2136e4132fdc7",
        "word": "consist  ",
        "wordtype": " /kən'sɪst/   v.   ",
        "explanation": " be made up or composed; be comprised or contained in ",
        "wordexample": "A sudden renewed interest in action movies from the early nineties whose titles consist of three words, one of which is usually either “kill”, “law” or “justice”. ",
        "isflipped": false
      },
      {
        "id": "wordi37640aed470143f489b600e6c115855d",
        "word": "constant  ",
        "wordtype": " /'kɒnstənt/   a.  Syn. invariable; repeating ",
        "explanation": " invariable; repeating; continually occurring; persistent ",
        "wordexample": "Yemen's state news agency says the president visited the three wounded officials at the Saudi hospital, and expressed happiness about constant progress in their health. ",
        "isflipped": false
      },
      {
        "id": "wordia61bf0f8e6704941b111119dcbacdc93",
        "word": "constitute  ",
        "wordtype": " /'kɒnstɪtju t/   v.  Syn. form ",
        "explanation": " make up; form something ",
        "wordexample": "\"I never did see the beat of that boy!\" She went to the open door and stood in it and looked out among the tomato vines that would constitute the garden. ",
        "isflipped": false
      },
      {
        "id": "wordi595474c363e14a269841eb1bbf40e5c8",
        "word": "constrain  ",
        "wordtype": " /kən'streɪn/   v.  Syn. restrain; confine ",
        "explanation": " restrain; keep within close bounds; confine ",
        "wordexample": "His idea is to constrain commercial banks' lending. ",
        "isflipped": false
      },
      {
        "id": "wordiaa89dd93627a45d0941f9ebe80cc9a93",
        "word": "construct  ",
        "wordtype": " /kən'strʌkt/   v.  Syn. erect; build ",
        "explanation": " form by assembling or combining parts; build; create ",
        "wordexample": "After all, perhaps there were different ways to construct machines that would have different properties. ",
        "isflipped": false
      },
      {
        "id": "wordi2885ffbb75864df38a9843d05334f307",
        "word": "consult  ",
        "wordtype": " /kən'sʌlt/   v.   ",
        "explanation": " seek advice or information of; take into account; consider ",
        "wordexample": "I will consult with our friends, but it's going to be what's in the interests of our country first and foremost. ",
        "isflipped": false
      },
      {
        "id": "wordiae72e63582a844c3aee619a8dd747c9e",
        "word": "consume  ",
        "wordtype": " /kən'sju m/;/kən'su m/   v.  Syn. devour; eat ",
        "explanation": " devour; eat ",
        "wordexample": "It is particularly an issue for those that have made large strides in industrial development, the sector of the economy that tends to consume the most energy. ",
        "isflipped": false
      },
      {
        "id": "wordia84eebf86e1c4037b31eb78955dce419",
        "word": "contact  ",
        "wordtype": " /'kɒntækt/   v.   ",
        "explanation": " get in touch with; reach ",
        "wordexample": "But Britney, 21, says he called her at two of her homes, and even tried to contact her at her parents' house. ",
        "isflipped": false
      },
      {
        "id": "wordi7cac5baefadf4344ae8f3813bd9cf6d7",
        "word": "contemporary  ",
        "wordtype": " /kən'tɛmpərərɪ/;/kən'tɛmpərɛrɪ/   a.   ",
        "explanation": " modern; belonging to the same period of time ",
        "wordexample": "The Danes have now taken the top drama award at the Emmys for three out of the past four years with contemporary drama set in Denmark. ",
        "isflipped": false
      },
      {
        "id": "wordif7f30326c06a4f25b4dc2e1f474fa077",
        "word": "context  ",
        "wordtype": " /'kɒntɛkst/   n.  Syn. circumstance; setting ",
        "explanation": " circumstance ",
        "wordexample": "Last week the Italian Prime Minister apologized to parliament in Rome for his alleged remarks about the superiority of western culture over that of Islam, claiming his words had been taken out of context. ",
        "isflipped": false
      },
      {
        "id": "wordie6b945665e0644d6a02a845e4d0dc0cc",
        "word": "contract  ",
        "wordtype": " /'kɒntrækt/   v.  Syn. shrink; constrict ",
        "explanation": " constrict; make smaller; compress or concentrate ",
        "wordexample": "The heat will contract the woollen garment. ",
        "isflipped": false
      },
      {
        "id": "wordiec5e29fb1a6649ec898f9f8555c4d909",
        "word": "contradict  ",
        "wordtype": " /kɒntrə'dɪkt/   v.  Syn. confront; oppose ",
        "explanation": " confront; oppose ",
        "wordexample": "Now act as you please  write and contradict my assertion--expose my falsehood as soon as you like. ",
        "isflipped": false
      },
      {
        "id": "wordid2c87dfec9804f52b71dc589d99ccbc9",
        "word": "contrary  ",
        "wordtype": " /'kɒntrərɪ/;/'kɒntrɛrɪ/   a.  Syn. opposite ",
        "explanation": " relation of direct opposition; very opposed in nature or character or purpose ",
        "wordexample": "Our boat took a course contrary to theirs. ",
        "isflipped": false
      },
      {
        "id": "wordie9537569444e41818fa693be54adc5fa",
        "word": "contrast  ",
        "wordtype": " /'kɒntrɑrst/;/'kɒntræst/   n.   ",
        "explanation": " act of distinguishing by comparing differences ",
        "wordexample": "In contrast, the Prime Minister's aides are preparing his defense, saying that at the time, the entire cabinet backed the move to war, and that he's willing to implement all the committee's recommendations. ",
        "isflipped": false
      },
      {
        "id": "wordi8ef5d0bd7310482ebfd1d1a980d2cfe4",
        "word": "contribute  ",
        "wordtype": " /kən'trɪbju t/   v.   ",
        "explanation": " provide; bestow a quality on ",
        "wordexample": "In the developed world, many companies provide a fund, which they and their staff contribute to, which is then invested in shares, bonds and other assets. ",
        "isflipped": false
      },
      {
        "id": "wordi1d61f490940b4e479dbaefd25d27f219",
        "word": "controversy  ",
        "wordtype": " /'kɒntrəvɜrsɪ/   n.  Syn. contention; argument ",
        "explanation": " contentious speech act; argument ",
        "wordexample": "Information minister Jerry Gana released a statement in which he says there has been an international media conspiracy against Nigeria, to highlight the controversy surrounding the beauty pageant and fanning the flames of violence. ",
        "isflipped": false
      },
      {
        "id": "wordi12ddbe3ab416491bb55ce62471dcc378",
        "word": "convene  ",
        "wordtype": " /kən'vi n/   v.  Syn. assemble ",
        "explanation": " cause to come together formally ",
        "wordexample": "Six days' public notice must be given when announcing the meeting schedules, meaning the earliest the board can next convene is July 24. ",
        "isflipped": false
      },
      {
        "id": "wordi741a5b5184184e5daf9959295e2d7d5d",
        "word": "converse  ",
        "wordtype": " /kən'vɜrs/   v.  Syn. chat ",
        "explanation": " chat; talk informally; engage in a spoken exchange of thoughts ",
        "wordexample": "Eva is all ears while Lulu and Lola converse. ",
        "isflipped": false
      },
      {
        "id": "wordief1d1e4831984b07b6fcf72f42ff5096",
        "word": "convert  ",
        "wordtype": " /kən'vɜrt/   n.  Syn. transform ",
        "explanation": " change something into another form; transform ",
        "wordexample": "However, he suggests that this only be done if the convert is also willingly accepted into his position by the community. ",
        "isflipped": false
      },
      {
        "id": "wordi6edaeba961834206bdde00a90cc7de12",
        "word": "convince  ",
        "wordtype": " /kən'vɪns/   v.   ",
        "explanation": " overpower; force to yield assent to truth; satisfy by proof; prove guilty ",
        "wordexample": "Your argument is too weak to convince me; we need more evidence. ",
        "isflipped": false
      },
      {
        "id": "wordi9e93e6556a1f4b388f00f099566bc726",
        "word": "cooperate  ",
        "wordtype": " /koʊ'ɒpəreɪt/   v.  Syn. collaborate ",
        "explanation": " work or act together toward a common end or purpose ",
        "wordexample": "The best way to get Pakistan to cooperate is to find the reasons why it is so keen to retain influence in Afghanistan and try to meet its concerns. ",
        "isflipped": false
      },
      {
        "id": "wordi8c4d56751bfa41b29e2a8e6d013c99fe",
        "word": "coordinate  ",
        "wordtype": " /koʊ'ɔ dɪneɪt/   v.  Syn. integrate; harmonize ",
        "explanation": " bring order and organization to; harmonize ",
        "wordexample": "The second way of specifying star positions is the equatorial coordinate system. ",
        "isflipped": false
      },
      {
        "id": "wordi943b78fd3cea48c5a1f81c754772a596",
        "word": "core  ",
        "wordtype": " /kɔ (r)/   n.  Syn. center; essence ",
        "explanation": " basic, center,  or most important part; essence ",
        "wordexample": "But at the core is a story about two men who can't let go of the sense that they are dreaming their way through what might be an ultimately meaningless life. ",
        "isflipped": false
      },
      {
        "id": "wordia7aea06614d549219e36dbe25b5790e2",
        "word": "corporate  ",
        "wordtype": " /'kɔ pərət/   a.   ",
        "explanation": " united or combined into one body; collective; belonging to corporation or incorporated body ",
        "wordexample": "The demonstrators inspired thousands of allies to take to the streets to protest economic inequality and corporate greed. ",
        "isflipped": false
      },
      {
        "id": "wordi2b6f4bf765b948a0af19ba8d9d6fa7cd",
        "word": "correspond  ",
        "wordtype": " /kɒrɪ'spɒnd/;/kɔ rə'spɒnd/   v.   ",
        "explanation": " be compatible, similar or consistent; exchange messages ",
        "wordexample": "My Russian pen pal and I correspond for several years. ",
        "isflipped": false
      },
      {
        "id": "wordi676560fcc00c4e4781eb7a0d1131e46c",
        "word": "couple  ",
        "wordtype": " /'kʌp(ə)l/   n.  Syn. pair ",
        "explanation": " a male and female associated together; a pair who associate with one another ",
        "wordexample": "He catched amarried couple from Chicago. ",
        "isflipped": false
      },
      {
        "id": "wordi0cac30acfcb34e068b6911b0d3db1703",
        "word": "create  ",
        "wordtype": " /kri 'eɪt/   v.   ",
        "explanation": " make or cause to be or to become; invest with a new thing ",
        "wordexample": "He plans to create a new company next year. ",
        "isflipped": false
      },
      {
        "id": "wordi31134cceeece4d3586509279051f0378",
        "word": "credit  ",
        "wordtype": " /'krɛdɪt/   n.  Syn. reputation; prestige ",
        "explanation": " arrangement for deferred payment for goods and services; money available for a client to borrow ",
        "wordexample": "The proposed treaty would give credit to peasant farmers who developed the crops in the first place. ",
        "isflipped": false
      },
      {
        "id": "wordi07baf2a294ea453db69aefbdcada7a3f",
        "word": "criteria  ",
        "wordtype": " /kraɪ'tɪərə/   n.   ",
        "explanation": " standard, rule, or test on which a judgment or decision can be based ",
        "wordexample": "This spring, the health department established a set of criteria for such clinics, including an offer of primary-care appointments within 24 hours of first contact. ",
        "isflipped": false
      },
      {
        "id": "wordi7ef00f5801ec49949b87be99887e6096",
        "word": "crucial  ",
        "wordtype": " /'kru ʃ(ə)l/   a.   ",
        "explanation": " of extreme importance; vital to the resolution of a crisis; of the greatest importance ",
        "wordexample": "The meeting of today is the crucial moment in his career. ",
        "isflipped": false
      },
      {
        "id": "wordi72f5d88607e143f59b199d7d1aa99698",
        "word": "culture  ",
        "wordtype": " /'kʌltʃə(r)/   n.  Syn. civilization ",
        "explanation": " all the knowledge and values shared by a society ; foster; raising of plants or animals ",
        "wordexample": "Last week the Italian Prime Minister apologised to parliament in Rome for his alleged remarks about the superiority of western culture over that of Islam, claiming his words had been taken out of context. ",
        "isflipped": false
      },
      {
        "id": "wordia1d4e411616449528c1b2af803c72596",
        "word": "currency  ",
        "wordtype": " /'kʌrənsɪ/   n.  Syn. money ",
        "explanation": " money; general acceptance or use ",
        "wordexample": "It now ranks along with oil and tourism as Mexico's biggest foreign currency earner. ",
        "isflipped": false
      },
      {
        "id": "wordi9549cf919d414f3c9babe66cc841a07c",
        "word": "cycle  ",
        "wordtype": " /'saɪk(ə)l/   n.   ",
        "explanation": " periodically repeated sequence of events; long period of time; entire round in a circle or a spire ",
        "wordexample": "Do they not understand that the spin cycle is an important part of the washing machine? ",
        "isflipped": false
      },
      {
        "id": "wordife9fe05c80614bb8aab4d4948810480c",
        "word": "data  ",
        "wordtype": " /'deɪtə, 'dɑrtə/;/'dætə/   n.   ",
        "explanation": " collection of facts, observations, or other information related to a particular question or problem ",
        "wordexample": "Now that data is required from around the world, the IEA must obtain them from a wide variety of sources. ",
        "isflipped": false
      },
      {
        "id": "wordi78d635eb9c3f4380b56820570f4f65e2",
        "word": "debate  ",
        "wordtype": " /dɪ'beɪt/   n.  Syn. argument ",
        "explanation": " discussion; dispute; discussion involving opposing points ",
        "wordexample": "Robert Potts, who recently retired as chancellor at Arkansas State University, witnessed the nickname debate in two states. ",
        "isflipped": false
      },
      {
        "id": "wordic8d82bb9fec64487a79c5d7c7c4cdd61",
        "word": "decade  ",
        "wordtype": " /'dɛkeɪd/   n.   ",
        "explanation": " a group of ten, especially a period of ten years ",
        "wordexample": "This decade is the time to fully embrace diversity and demonstrate equal rights to all Americans in this country. ",
        "isflipped": false
      },
      {
        "id": "wordi8d6124dbf6614d2692776c5d71367460",
        "word": "decline  ",
        "wordtype": " /dɪ'klaɪn/   n.  Syn.  deterioration; decay ",
        "explanation": " change toward something smaller or lower ; gradual falling off from a better state ",
        "wordexample": "Dustan has a record of switching sides when convenient, and there are many Taliban supporters who would do likewise if the fortunes of the puritan militia are on the decline. ",
        "isflipped": false
      },
      {
        "id": "wordiabc7bd02d08242acbf8ef29ce11f7254",
        "word": "deduce  ",
        "wordtype": " /dɪ'dju s/   v.   ",
        "explanation": " lead forth; reach a conclusion by reasoning; trace the origin or derivation of ",
        "wordexample": "Our investors deduce from the figures that the report shows. ",
        "isflipped": false
      },
      {
        "id": "wordib04961f6f5c14cf689e9fed48246ebb9",
        "word": "define  ",
        "wordtype": " /dɪ'faɪn/   v.   ",
        "explanation": " determine the nature of; give a definition; describe the nature or basic qualities of; explain ",
        "wordexample": "That argument may define the political parties and help shape the 2012 elections. ",
        "isflipped": false
      },
      {
        "id": "wordibc054185938d425ba3f3621ed58cb175",
        "word": "definite  ",
        "wordtype": " /'dɛfɪnɪt/   a.  Syn. fixed; exact ",
        "explanation": " fixed; exact; having distinct limits ",
        "wordexample": "He introduced the closed circuit of oscillation into wireless telegraphy, and was one of the first to send electric waves in definite directions. ",
        "isflipped": false
      },
      {
        "id": "wordi835be87acd0c4fbabfe98d131fda96a9",
        "word": "demonstrate  ",
        "wordtype": " /'dɛmənstreɪt/   v.  Syn. show; confirm; prove; manifest ",
        "explanation": " show clearly and deliberately; manifest; confirm; prove ",
        "wordexample": "After a series of drug scandals, this was Major League Baseball's chance to demonstrate its determination to crack down on the cheats. ",
        "isflipped": false
      },
      {
        "id": "wordi8e00b6391e1a4feab792aceecbd6555d",
        "word": "denote  ",
        "wordtype": " /dɪ'noʊt/   v.  Syn. signify; indicate; show ",
        "explanation": " indicate; signify directly; refer to specifically ",
        "wordexample": "The word “sex” is simply that—a word to denote whether a person is male or female. ",
        "isflipped": false
      },
      {
        "id": "wordib9785068407d4ef2a08aeca1fab06605",
        "word": "deny  ",
        "wordtype": " /dɪ'naɪ/   v.  Syn. disagree; disavow ",
        "explanation": " disagree with; refuse; declare untrue ",
        "wordexample": "What I do deny is that we have been inconsistent with respect to our view of the Constitution ",
        "isflipped": false
      },
      {
        "id": "wordi5c263980d0f84ce7b2aafb259a34c33a",
        "word": "depress  ",
        "wordtype": " /dɪ'prɛs/   v.  Syn. lower ",
        "explanation": " lower in spirits; press down ",
        "wordexample": "There are hopes that this could help to revive the internet and technology sector which has shown to depress since the dotcom crash of 2000. ",
        "isflipped": false
      },
      {
        "id": "wordie884f5fd75d04f00839ecd9f953ac560",
        "word": "derive  ",
        "wordtype": " /dɪ'raɪv/   v.  Syn. obtain; extract ",
        "explanation": " obtain or receive from a source; trace the origin or development of ",
        "wordexample": "For I knew Diana and Mary would derive more pleasure from seeing again the old homely tables than from the spectacle of the smartest innovations. ",
        "isflipped": false
      },
      {
        "id": "wordi91dbdad2ad0949b890f97ef83f44e6e4",
        "word": "design  ",
        "wordtype": " /dɪ'zaɪn/   n.  Syn. devise ",
        "explanation": " act of working out the form of something; creation of something in the mind; formulate a plan for ",
        "wordexample": "He is hired to design a marketing strategy for the new product. ",
        "isflipped": false
      },
      {
        "id": "wordie827d9aab982432c9893fc63ae042d61",
        "word": "despite  ",
        "wordtype": " /dɪ'spaɪt/   n.   ",
        "explanation": " lack of respect accompanied by a feeling of intense dislike; disdain, contemptuous feelings, hatred ",
        "wordexample": "He didn't hide his despite in the party because he believed the host cheated. ",
        "isflipped": false
      },
      {
        "id": "wordi960796eefe534fcab7292f1034e481bf",
        "word": "detect  ",
        "wordtype": " /dɪ'tɛkt/   v.  Syn. feel; discover the presence of; discern; sense; identify ",
        "explanation": " feel; discover the presence of; identify ",
        "wordexample": "They won't detect prescription drugs or medication such as cold or flu tablets. ",
        "isflipped": false
      },
      {
        "id": "wordi4116a6d1b48e4c128f0efa86bfb20bc6",
        "word": "deviate  ",
        "wordtype": " /'di vɪeɪt/   v.  Syn. depart; diverge ",
        "explanation": " turn away from a principle, norm; depart; diverge ",
        "wordexample": "Richard did not deviate from his daily routine  every day he set off for work at eight o'clock, had his sack lunch at 12 15, and headed home at the stroke of five. ",
        "isflipped": false
      },
      {
        "id": "wordi9bcc7ee5355542d9b831fe00b09b7ca3",
        "word": "device  ",
        "wordtype": " /dɪ'vaɪs/   n.  Syn. instrument ",
        "explanation": " technique or means; instrument; machine used to perform one or more relatively simple tasks ",
        "wordexample": "Anti-gravity device could change air travel. ",
        "isflipped": false
      },
      {
        "id": "wordic60e294b510f4864b45e46cbee77923b",
        "word": "devote  ",
        "wordtype": " /dɪ'voʊt/   v.  Syn. dedicate; contribute ",
        "explanation": " dedicate; contribute ",
        "wordexample": "Those who trade them hunt out the fiercest insects and devote many hours to training them. ",
        "isflipped": false
      },
      {
        "id": "wordidba2095b250b4b8b804f14244aa7b465",
        "word": "differentiate  ",
        "wordtype": " /dɪfə'rɛnʃɪeɪt/   v.  Syn. distinguish; discriminate ",
        "explanation": " set apart; distinguish; perceive or show difference in or between ",
        "wordexample": "You can differentiate car parts by using different color markers; maybe you use one color for the left side and another for the right. ",
        "isflipped": false
      },
      {
        "id": "wordi795641ba04d74b23a2d91ca8248e5a4f",
        "word": "dimension  ",
        "wordtype": " /dɪ'mɛnʃ(ə)n/   n.  Syn. measure; size ",
        "explanation": " measure of spatial extent, especially width, height, or length; size; aspect; element ",
        "wordexample": "Describing time as a dimension is a natural assumption. ",
        "isflipped": false
      },
      {
        "id": "wordi16de5c5ee79a4d9386c28bf7c9337650",
        "word": "diminish  ",
        "wordtype": " /dɪ'mɪnɪʃ/   v.  Syn. dwindle; reduce; decrease ",
        "explanation": " dwindle; reduce; make smaller or less or to cause to appear so ",
        "wordexample": "The only way to diminish mistakes is to bring competitors into the game. ",
        "isflipped": false
      },
      {
        "id": "wordi00dc2d466cfe41d991c64b55091bbc43",
        "word": "discrete  ",
        "wordtype": " /dɪ'skri t/   a.  Syn. separate; distinct ",
        "explanation": " separate; consisting of unconnected distinct parts ",
        "wordexample": "The universe is composed of discrete bodies. ",
        "isflipped": false
      },
      {
        "id": "wordi1a728fee5950459e9ac2bb0acccd97b8",
        "word": "discriminate  ",
        "wordtype": " /dɪ'skrɪmɪneɪt/   v.   ",
        "explanation": " make a clear distinction; distinguish; make sensible decisions; judge wisely ",
        "wordexample": "It's not just a notion when 46 states can still discriminate against same-sex couples getting married. ",
        "isflipped": false
      },
      {
        "id": "wordi7e995b6a97ff419e85176e00ea633a38",
        "word": "displace  ",
        "wordtype": " /dɪs'pleɪs/   v.  Syn. move; replace; substitute ",
        "explanation": " move or shift from the usual place or position, especially to force to leave a homeland ",
        "wordexample": "This war will displace lots of refugees from their villages. ",
        "isflipped": false
      },
      {
        "id": "wordid2c28028928543d3860d11c701c7f8aa",
        "word": "display  ",
        "wordtype": " /dɪ'spleɪ/   v.  Syn. exhibit; present; show ",
        "explanation": " exhibit; present or hold up to view; show; demonstrate; give evidence of; manifest ",
        "wordexample": "The airport authorities decided to remove all Christmas trees because a Jewish rabbi threatened to sue them if they didn't also display a menorah. ",
        "isflipped": false
      },
      {
        "id": "wordi5edcd1df230d43b9885e69418e31ccb7",
        "word": "dispose  ",
        "wordtype": " /dɪ'spoʊz/   v.   ",
        "explanation": " get rid of; settle or decide a matter; place or set in a particular order; arrange ",
        "wordexample": "Do not use them to dispose of household trash. ",
        "isflipped": false
      },
      {
        "id": "wordi3ab1c18dc8414851b9ee23b710400697",
        "word": "distinct  ",
        "wordtype": " /dɪ'stɪŋkt/   a.  Syn. definite; separate; different ",
        "explanation": " definite; separate; different ",
        "wordexample": "The UN has always been at pains to say that its role in occupied Iraq is distinct from that of the US-led forces, and many ordinary Iraqis appreciated that the primary UN role was humanitarian. ",
        "isflipped": false
      },
      {
        "id": "wordi5998b4ab84154b03b8747c8430015e12",
        "word": "distort  ",
        "wordtype": " /dɪ'stɔ t/   v.  Syn. deform; twist ",
        "explanation": " twist out of proper or natural relation of parts; misshape; misrepresent ",
        "wordexample": "It is difficult to believe the newspaper accounts of the riots because of the way some reporters distort and exaggerate the actual events. ",
        "isflipped": false
      },
      {
        "id": "wordib5283ea3422042c6bba02872341e5040",
        "word": "distribute  ",
        "wordtype": " /dɪ'strɪbju t/   v.  Syn. disseminate; allocate ",
        "explanation": " hand out; disseminate; allocate ",
        "wordexample": "They are planning to buy some main firms that distribute gas to European consumers. ",
        "isflipped": false
      },
      {
        "id": "wordi88c8334928324ea89729d12e238226e8",
        "word": "diverse  ",
        "wordtype": " /daɪ'vɜrs/   a.  Syn. various ",
        "explanation": " differing in some characteristics; various ",
        "wordexample": "The professor suggested diverse ways of approaching the assignment and recommended that we choose one of them. ",
        "isflipped": false
      },
      {
        "id": "wordi849122f0c0a248f198a26fe0558395cf",
        "word": "document  ",
        "wordtype": " /'dɒkjʊmənt/   v.  Syn. record ",
        "explanation": " provide written evidence; record in detail ",
        "wordexample": "She kept all the receipts from her business trip in order to document her expenses for the firm. ",
        "isflipped": false
      },
      {
        "id": "wordi445b8ca54a5c4947b24a78d1a34afb8a",
        "word": "domain  ",
        "wordtype": " /də'meɪn/   n.  Syn. field ",
        "explanation": " field; territory over which rule or control is exercised;  networked computers that share a common address ",
        "wordexample": "Our cat knows who the queen of the domain is. ",
        "isflipped": false
      },
      {
        "id": "wordi231e2fc94d9846e5ac0bd363b70296fc",
        "word": "domestic  ",
        "wordtype": " /də'mɛstɪk/   a.  Syn. house-hold; tame ",
        "explanation": " house-hold; of or relating to the home ; within the country or home ",
        "wordexample": "Only a substantial increase in the price of domestic fuel will make local refineries more profitable. ",
        "isflipped": false
      },
      {
        "id": "wordi6e701222565f49dea40ffd534b428b25",
        "word": "dominate  ",
        "wordtype": " /'dɒmɪneɪt/   v.  Syn. monopolize; command; rule ",
        "explanation": " monopolize; command; rule; prevail; be prevalent in ",
        "wordexample": "People tend to have one side of their brain dominate their thought patterns. ",
        "isflipped": false
      },
      {
        "id": "wordi78600840195a44dab8253910d25e688c",
        "word": "draft  ",
        "wordtype": " /drɑrft/;/dræft/   n.  Syn. sketch ",
        "explanation": " rough outline; draw up an outline; sketch ",
        "wordexample": "Now governments are re-writing the EU's governing treaty and the draft version is considered by the EU's leaders in Brussels. ",
        "isflipped": false
      },
      {
        "id": "wordibc8d1d59bfd248d891de1141e3f836f8",
        "word": "drama  ",
        "wordtype": " /'drɑrmə/   n.  Syn. play ",
        "explanation": " play; literary work intended for theater ",
        "wordexample": "The Danes have now taken the top drama award at the Emmys for three out of the past four years. ",
        "isflipped": false
      },
      {
        "id": "wordie510c51b0b764741a6ea61cf35725bb9",
        "word": "duration  ",
        "wordtype": " /djʊə'reɪʃ(ə)n/;/dʊ'reɪʃn/   n.  Syn. length; period ",
        "explanation": " length of time something lasts ",
        "wordexample": "Because she wanted the children to make a good impression on the dinner guests, Mother promised them a treat if they'd behave for the duration of the meal. ",
        "isflipped": false
      },
      {
        "id": "wordi1fcea4735d2140739f2453ff8a748b07",
        "word": "dynamic  ",
        "wordtype": " /daɪ'næmɪk/   a.  Syn. energetic ",
        "explanation": " energetic; vigorously active ",
        "wordexample": "The dynamic aerobics instructor kept her students on the run. ",
        "isflipped": false
      },
      {
        "id": "wordid19eb1ca3dcd432785e1f03ffcf1170f",
        "word": "economy  ",
        "wordtype": " /ɪ'kɒnəmɪ/   n.   ",
        "explanation": " efficient use of resources; reduction in cost; specific type of economic system ",
        "wordexample": "The tribe's main economy is primitive agriculture and its wealth is sometimes counted in people as well as animals. ",
        "isflipped": false
      },
      {
        "id": "wordidff8d0e4d2364b66a86364ce09ab0b6b",
        "word": "edit  ",
        "wordtype": " /'ɛdɪt/   v.   ",
        "explanation": " revise and prepare for publication; select, correct, arrange matter of, for publication ",
        "wordexample": "The fourth volume of Make magazine, which I edit, is now available on Amazon. ",
        "isflipped": false
      },
      {
        "id": "wordi0862e91a0cca486fb7f40603aeed942c",
        "word": "element  ",
        "wordtype": " /'ɛlɪmənt/   n.  Syn. component ",
        "explanation": " fundamental or essential constituent of a composite entity; basic assumptions or principles of a subject ",
        "wordexample": "There's always an element of danger in mountain climbing. ",
        "isflipped": false
      },
      {
        "id": "wordi203d469aca9141e9b65b6a211569b5b6",
        "word": "eliminate  ",
        "wordtype": " /ɪ'lɪmɪneɪt/   v.  Syn. eradicate; abolish ",
        "explanation": " eradicate; abolish; rule out ",
        "wordexample": "So the EU’s offer to eliminate the subsidy was almost universally welcomed. ",
        "isflipped": false
      },
      {
        "id": "wordia18e9b19b1a2459aa112a2d6d8ecf713",
        "word": "emerge  ",
        "wordtype": " /ɪ'mɜrdʒ/   v.  Syn. appear ",
        "explanation": " come into prominence; spring up; appear ",
        "wordexample": "New cases continue to emerge on an almost daily basis. ",
        "isflipped": false
      },
      {
        "id": "wordiea863f2791304a1e90a76f5478845f08",
        "word": "emphasis  ",
        "wordtype": " /'ɛmfəsɪs/   n.   ",
        "explanation": " special attention or effort directed toward something; stress ",
        "wordexample": "They also said that there was too much emphasis placed on protecting the liberty of individuals at the expense of broader social justice. ",
        "isflipped": false
      },
      {
        "id": "wordia3402a88a3134a039e2f3775bebdfea4",
        "word": "empirical  ",
        "wordtype": " /ɛm'pɪrɪk(ə)l/   a.   ",
        "explanation": " derived from experiment and observation rather than theory ",
        "wordexample": "He distrusted hunches and intuitive flashes; he placed his reliance entirely on empirical data. ",
        "isflipped": false
      },
      {
        "id": "wordiaff1facf2a774ba58d9014ba3067361e",
        "word": "enable  ",
        "wordtype": " /ɪ'neɪb(ə)l/   v.   ",
        "explanation": " supply with the means, knowledge, or opportunity; make able; make feasible or possible ",
        "wordexample": "We shall have become so unfit that nothing we can do to enable us to survive. ",
        "isflipped": false
      },
      {
        "id": "wordi25debee9843c4d479d34d5721233e1cd",
        "word": "encounter  ",
        "wordtype": " /ɪn'kaʊntə(r)/   v.  Syn. face; confront; meet ",
        "explanation": " face; confront;  meet, especially unexpectedly; come upon ",
        "wordexample": "Even children who can swim are at risk as they often move too far away from their families and then encounter difficulties getting back to dry land. ",
        "isflipped": false
      },
      {
        "id": "wordi18aad0d5a4b943adaf3c9e265cda8ddd",
        "word": "energy  ",
        "wordtype": " /'ɛnədʒɪ/   n.  Syn. vigor; power ",
        "explanation": " exertion of force; capacity for work or vigorous activity; usable heat or power ",
        "wordexample": "Each year Americans consume a high percentage of the world's energy. ",
        "isflipped": false
      },
      {
        "id": "wordi48b54b2eb8454fd68aa3d6d037b70a31",
        "word": "enforce  ",
        "wordtype": " /ɪn'fɔ s/   v.  Syn. force; constrain; compel ",
        "explanation": " put force upon; force; constrain; compel; put in motion or action by violence ",
        "wordexample": "Can the police enforce the same rule to avoid another Rodney King incident? ",
        "isflipped": false
      },
      {
        "id": "wordi0917a4b70dc740f6b068fd73682b07d8",
        "word": "enhance  ",
        "wordtype": " /ɪn'hɑrns/;/ɪn'hæns/   v.  Syn. increase; improve ",
        "explanation": " make better or more attractive; increase; improve ",
        "wordexample": "This sauce will enhance the flavor of the meat. ",
        "isflipped": false
      },
      {
        "id": "wordi7056a063f0d5442a8ac161ef51105375",
        "word": "enormous  ",
        "wordtype": " /ɪ'nɔ məs/   a.  Syn. tremendous; huge; massive ",
        "explanation": " very great in size, extent, number, or degrees; huge; massive ",
        "wordexample": "An enormous puppy was looking down at her with large round eyes, and feebly stretching out one paw, trying to touch her. ",
        "isflipped": false
      },
      {
        "id": "wordiacd5654c5bb24467afd5a4e99f9c5fe9",
        "word": "ensure  ",
        "wordtype": " /ɪn'ʃʊə(r)/;/ɪn'ʃʊər/   v.   ",
        "explanation": " make sure or certain; insure; assure ",
        "wordexample": "For example, to ensure data security, a publicly held company will need to control who has access to financial records. ",
        "isflipped": false
      },
      {
        "id": "wordi86c24175660a4ecba5662550f8eb0f35",
        "word": "entity  ",
        "wordtype": " /'ɛntɪtɪ/   n.   ",
        "explanation": " real being; something that exists as a particular and discrete unit; fact of existence ",
        "wordexample": "Persons and corporations are equivalent entity under the law. ",
        "isflipped": false
      },
      {
        "id": "wordi807bbe0f9f314916abcf6ee0364d731f",
        "word": "environment  ",
        "wordtype": " /ɪn'vaɪərənmənt/   n.  Syn. circumstance ",
        "explanation": " surroundings; totality of surrounding conditions ",
        "wordexample": "We shall never understand the natural environment until we see it as a living organism. ",
        "isflipped": false
      },
      {
        "id": "wordif0510bde60ac45029d3b37256a1af76f",
        "word": "equate  ",
        "wordtype": " /ɪ'kweɪt/   v.   ",
        "explanation": " make equal or equivalent; consider, treat, or depict as equal or equivalent ",
        "wordexample": "Most Americans equate success with wealth and fame. ",
        "isflipped": false
      },
      {
        "id": "wordi7674b6f274364188a546a72864a46e32",
        "word": "equip  ",
        "wordtype": " /ɪ'kwɪp/   v.   ",
        "explanation": " supply with necessities such as tools or provisions; furnish with the qualities necessary for performance ",
        "wordexample": "There escort ships are also the only ships on which you can equip cannons. ",
        "isflipped": false
      },
      {
        "id": "wordie543bbd339ed44fa9d42a85d6c27ba78",
        "word": "equivalent  ",
        "wordtype": " /ɪ'kwɪvələnt/   a.  Syn. interchangeable; comparable; tantamount ",
        "explanation": " interchangeable; comparable; equal, as in value, force, or meaning ",
        "wordexample": "The Clinton campaign has raised more money in the first three months than all nine Democratic candidates in the equivalent period for the 2004 election. ",
        "isflipped": false
      },
      {
        "id": "wordi51bcd0af0a624ac4a92dd6b0712d7eac",
        "word": "erode  ",
        "wordtype": " /ɪ'roʊd/   v.  Syn. corrode ",
        "explanation": " eat away; wear away by abrasion; become worn ",
        "wordexample": "The film shows how dripping water to erode the limestone until only a thin shell remained. ",
        "isflipped": false
      },
      {
        "id": "wordi9d6f96467bd3477ba8513c0422836958",
        "word": "establish  ",
        "wordtype": " /ɪ'stæblɪʃ/   v.   ",
        "explanation": " set up or found; build ",
        "wordexample": "His first novel did not establish his fame as a writer, but second one did. ",
        "isflipped": false
      },
      {
        "id": "wordi248afbe2fd99468bb5dc51a538839a7d",
        "word": "estate  ",
        "wordtype": " /ɪ'steɪt/   n.  Syn. property ",
        "explanation": " extensive landed property; everything you own; all of your assets ",
        "wordexample": "Jackson's estate is also subject to federal inheritance taxes. ",
        "isflipped": false
      },
      {
        "id": "wordib1086de58342486b987cdda35116a6cd",
        "word": "estimate  ",
        "wordtype": " /'ɛstɪmət/   v.  Syn. assess; appraise; evaluate ",
        "explanation": " judge to be probable; form an opinion about; evaluate ",
        "wordexample": "The insurance industry is well prepared to estimate of the loss it will suffer. ",
        "isflipped": false
      },
      {
        "id": "wordicb33bb9764b649b69cc043aba318ba28",
        "word": "ethic  ",
        "wordtype": " /'ɛθɪk/   n.   ",
        "explanation": " a set of principles of right conduct; theory or a system of moral values ",
        "wordexample": "Do these clowns want us to emulate the Japanese \"work until you die\" ethic? ",
        "isflipped": false
      },
      {
        "id": "wordi7439f147998643be88db6c74a19bc954",
        "word": "ethnic  ",
        "wordtype": " /'ɛθnɪk/   a.  Syn. racial ",
        "explanation": " relating to races; group of people sharing common racial, national, or religious heritage ",
        "wordexample": "But guess why they stay home and suppress what they call ethnic unrest? ",
        "isflipped": false
      },
      {
        "id": "wordi258d680825b74ec8aaf98d7bb7acbca0",
        "word": "evaluate  ",
        "wordtype": " /ɪ'væljʊeɪt/   v.  Syn. judge; appraise; estimate ",
        "explanation": " judge; examine and judge carefully; appraise ",
        "wordexample": "They saw several oil slicks but could not evaluate their size. ",
        "isflipped": false
      },
      {
        "id": "wordi03cc3aceaf174140ad5357d3c2d72db9",
        "word": "eventual  ",
        "wordtype": " /ɪ'vɛntjʊəl/   a.  Syn. ultimate; final; inevitable ",
        "explanation": " ultimate; occurring at an unspecified time in the future ",
        "wordexample": "One of Mr. Barak's legacies is that more Israelis now know that an eventual peace agreement with the Palestinians will have to involve a deal on Jerusalem. ",
        "isflipped": false
      },
      {
        "id": "wordi1a8d765c5e2f4c3197dbb4286e707970",
        "word": "evident  ",
        "wordtype": " /'ɛvɪdənt/   a.  Syn. obvious; apparent; clear ",
        "explanation": " easily seen or understood; obvious; apparent; clear ",
        "wordexample": "He was lying on his left side at the time, and in evident pain. ",
        "isflipped": false
      },
      {
        "id": "wordi4b4e80123c69498da66ff9fe52442a34",
        "word": "evolve  ",
        "wordtype": " /ɪ'vɒlv/   v.  Syn. develop; grow ",
        "explanation": " develop; grow ",
        "wordexample": "They want to evolve a joint strategy for the next round of WTO related trade negotiations scheduled to be held in Geneva in mid December. ",
        "isflipped": false
      },
      {
        "id": "wordi2009104973e24c91b745ef1a87479ca0",
        "word": "exceed  ",
        "wordtype": " /ɪk'si d/   v.   ",
        "explanation": " go beyond; be or do something to a greater degree ",
        "wordexample": "This will exceed all my expectations. ",
        "isflipped": false
      },
      {
        "id": "wordiefef37bf866942f7afb80864ebf66727",
        "word": "exclude  ",
        "wordtype": " /ɪk'sklu d/   v.   ",
        "explanation": " leave out of; keep out of; reject ",
        "wordexample": "A decision to exclude a third of the countries on that initial list would be controversial, as debt cancellation is a key element  to alleviate global poverty. ",
        "isflipped": false
      },
      {
        "id": "wordi538d4868790b47028923226a0885f393",
        "word": "exhibit  ",
        "wordtype": " /ɪg'zɪbɪt/   v.  Syn. display; show ",
        "explanation": " show, make visible or apparent ",
        "wordexample": "The Metropolitan Museum plans to exhibit Goya's works this month. ",
        "isflipped": false
      },
      {
        "id": "wordi52434db6ca1e4fcda0d910d8df7cfd9f",
        "word": "expand  ",
        "wordtype": " /ɪk'spænd/   v.  Syn. dilate; extend ",
        "explanation": " become larger in size or volume; grow stronger; add details ",
        "wordexample": "China wants to learn from India's success in IT and expand international outsourcing, such as call centers, a booming sector in India. ",
        "isflipped": false
      },
      {
        "id": "wordic5a3ee708af74bada9c7abdcec6edbe2",
        "word": "expert  ",
        "wordtype": " /'ɛkspɜrt/   n.   ",
        "explanation": " person with a high degree of skill in or knowledge of a certain subject ",
        "wordexample": "If this expert is as good as Foote says, he can tie up the process for a long time. ",
        "isflipped": false
      },
      {
        "id": "wordid47d28ea1a1e4ae58801c1ce43314d3b",
        "word": "explicit  ",
        "wordtype": " /ɪk'splɪsɪt/   a.  Syn. definite; outspoken ",
        "explanation": " precisely and clearly expressed; definite; outspoken ",
        "wordexample": "Don't just hint around that you're dissatisfied  be explicit about what's bugging you. ",
        "isflipped": false
      },
      {
        "id": "wordi324476acfc064494ab0fc9b6de4d9e39",
        "word": "exploit  ",
        "wordtype": " /ɛk'splɔɪt/   v.   ",
        "explanation": " make use of, sometimes unjustly ",
        "wordexample": "Cesar Chavez fought attempts to exploit migrant farm workers in California. ",
        "isflipped": false
      },
      {
        "id": "wordid6f69ee28add413b8935e212c8d9e819",
        "word": "export  ",
        "wordtype": " /ɪk'spɔ t/   v.   ",
        "explanation": " sell or transfer abroad ",
        "wordexample": "They impose limits on how much developing nations can export to rich countries. ",
        "isflipped": false
      },
      {
        "id": "wordi7bed0e2dfb8c4444be7fc955c9eea26e",
        "word": "expose  ",
        "wordtype": " /ɪk'spoʊz/;/ɛkspə'zeɪ/   v.  Syn. exhibit; show; display ",
        "explanation": " set forth; set out to public view ",
        "wordexample": "It will once again expose their intent to prevent an agenda that people clearly want. ",
        "isflipped": false
      },
      {
        "id": "wordia381b8fa015c4ae59c2122f53cbd08f1",
        "word": "external  ",
        "wordtype": " /ɛk'stɜrn(ə)l/   a.  Syn. exterior; outer ",
        "explanation": " exterior; outer; suitable for application to the outside ",
        "wordexample": "There is, said the external relations commissioner, a lot of broken crockery on the floor, and we're going to have to work hard to put the pieces together again. ",
        "isflipped": false
      },
      {
        "id": "wordi6a2d55bdc7ed4782911d532fa5b9bcb8",
        "word": "extract  ",
        "wordtype": " /ɪk'strækt/   v.  Syn. derive; remove; squeeze ",
        "explanation": " draw or pull out, usually with some force or effort; remove; get despite difficulties or obstacles ",
        "wordexample": "He is not planning to expel foreign companies as he needs their expertise and technology to extract and upgrade Venezuela's heavy crude. ",
        "isflipped": false
      },
      {
        "id": "wordi3317df015b0c45e48eb9a583c6eb43a4",
        "word": "facilitate  ",
        "wordtype": " /fə'sɪlɪteɪt/   v.  Syn. promote; expedite ",
        "explanation": " help bring about; make less difficult ",
        "wordexample": "Rest and proper nourishment should facilitate the patient's recovery. ",
        "isflipped": false
      },
      {
        "id": "wordi228a7e326fae47a398cc888d9d9d049e",
        "word": "factor  ",
        "wordtype": " /'fæktə(r)/   n.  Syn. variable; element; component ",
        "explanation": " anything that contributes causally to a result; element; variable ",
        "wordexample": "The Federation warns that unless the world's population acts now to eat a healthier diet and to take more exercise, obesity will rapidly overtake smoking as the leading lifestyle risk factor for heart disease and strokes. ",
        "isflipped": false
      },
      {
        "id": "wordid24b425098dd440da7b9d8e58fb2a052",
        "word": "feature  ",
        "wordtype": " /'fi tʃə(r)/   n.   ",
        "explanation": " prominent aspect of something ",
        "wordexample": "No feature in the scene was extraordinary, but all was pleasing. ",
        "isflipped": false
      },
      {
        "id": "wordic7c57962468a4d9890c894360ec87e2d",
        "word": "federal  ",
        "wordtype": " /'fɛdər(ə)l/   a.   ",
        "explanation": " of or relating to central government; national ",
        "wordexample": "The new president has to face current and long term federal deficits. ",
        "isflipped": false
      },
      {
        "id": "wordi73e665565b4c47eea8f7b3fc53022317",
        "word": "fee  ",
        "wordtype": " /fi /   v.   ",
        "explanation": " give a tip beyond the agreed-on compensation ",
        "wordexample": "Please remember to fee the steward. ",
        "isflipped": false
      },
      {
        "id": "wordi3304075dbfe044a69c2cb12c54c810cc",
        "word": "file  ",
        "wordtype": " /faɪl/   v.   ",
        "explanation": " line; proceed in line ",
        "wordexample": "The students file into the classroom. ",
        "isflipped": false
      },
      {
        "id": "wordi2eace2ad71bd4ea9bda300c09072a8d4",
        "word": "final  ",
        "wordtype": " /'faɪn(ə)l/   a.  Syn. last ",
        "explanation": " forming or occurring at the end; terminating; ultimate; conclusive ",
        "wordexample": "The game is now in its final stages, I can see its result already. ",
        "isflipped": false
      },
      {
        "id": "wordi37065caebfae4977aac017fdeadd7896",
        "word": "finance  ",
        "wordtype": " /'faɪnæns/   n.  Syn. fund ",
        "explanation": " management of money and credit and banking and investments; subsidizing; fund ",
        "wordexample": "Mr. Brown's views on economic matters are pretty well established and internationally he's known among finance ministers for his grasp of detail. ",
        "isflipped": false
      },
      {
        "id": "wordif6e8bd861a64476c932b6e57497d2ddc",
        "word": "finite  ",
        "wordtype": " /'faɪnaɪt/   a.   ",
        "explanation": " having a limit; limited in quantity, degree, or capacity; bounded ",
        "wordexample": "By the way, it's wrong to think a single individual can overtake a population of size infinity in finite time. ",
        "isflipped": false
      },
      {
        "id": "wordi5ac67e75b717459b9288f2b0bd8e0cf4",
        "word": "flexible  ",
        "wordtype": " /'flɛksɪb(ə)l/   a.  Syn. pliant; elastic; docile ",
        "explanation": " pliant; elastic; capable of being bent or flexed; pliable ",
        "wordexample": "The way of life is very beautiful for those people, who work from home, enjoys having less pressure and they can work in flexible hours at their own convenience. ",
        "isflipped": false
      },
      {
        "id": "wordi1106cd98df154985b310bd172557a5c8",
        "word": "fluctuate  ",
        "wordtype": " /'flʌktjʊeɪt/   v.  Syn. waver; shift ",
        "explanation": " rise and fall in or as if in waves; shift; vary irregularly ",
        "wordexample": "The water pressure in our shower does fluctuate wildly. ",
        "isflipped": false
      },
      {
        "id": "wordiaf7ed585ad414192afa433b66befbe20",
        "word": "focus  ",
        "wordtype": " /'foʊkəs/   n.   ",
        "explanation": " most important thing; a fixed reference point; center of interest or activity ",
        "wordexample": "Who is responsible and who coordinates the attack is now the focus of discussion. ",
        "isflipped": false
      },
      {
        "id": "wordi6f9292522a9745c5bff2417cb7db68ed",
        "word": "format  ",
        "wordtype": " /'fɔ mæt/   v.  Syn. pattern; design ",
        "explanation": " pattern; design; set into a specific pattern ",
        "wordexample": "Please format this letter so it can be printed out. ",
        "isflipped": false
      },
      {
        "id": "wordi272eaf5d209740158a455982465c2301",
        "word": "formula  ",
        "wordtype": " /'fɔ mjʊlə/   n.   ",
        "explanation": " plan; directions for making something; a group of symbols that make a mathematical statement ",
        "wordexample": "He gave us a general formula for attacking polynomials. ",
        "isflipped": false
      },
      {
        "id": "wordi813d15c012db4c6f96e1a58fb62fa9f6",
        "word": "forthcoming  ",
        "wordtype": " /fɔ θ'kʌmɪŋ/   a.   ",
        "explanation": " ready or about to appear; making appearance ",
        "wordexample": "The forthcoming talks hold out the hope of real arms reductions. ",
        "isflipped": false
      },
      {
        "id": "wordi85b030ab6edf4e619a3eb555a2a9a994",
        "word": "foundation  ",
        "wordtype": " /faʊn'deɪʃ(ə)n/   n.   ",
        "explanation": " basis on which something is grounded ",
        "wordexample": "There is little foundation for his objections, nobody follow him. ",
        "isflipped": false
      },
      {
        "id": "wordi400d74132e984b8ba2cdb69bd8f4089b",
        "word": "framework  ",
        "wordtype": " /'freɪmwɜrk/   n.  Syn. structure; skeleton ",
        "explanation": " fundamental structure, as for a written work; skeleton ",
        "wordexample": "If they're given a draft framework for such a body, the rebels say they are willing to resume negotiations. ",
        "isflipped": false
      },
      {
        "id": "wordic845b1afc0eb4eaa84a0ddf4d486cd37",
        "word": "function  ",
        "wordtype": " /'fʌnkʃən/   n.   ",
        "explanation": " act of executing or performing any duty; assigned duty or activity ",
        "wordexample": "The function of an adjective is to describe or add to the meaning of a noun. ",
        "isflipped": false
      },
      {
        "id": "wordi8fdff983c6234154807e1878f6cbf757",
        "word": "fund  ",
        "wordtype": " /fʌnd/   n.  Syn. money; capital ",
        "explanation": " money; capital; a reserve of money set aside for some purpose; finance; subsidize ",
        "wordexample": "An activist from Burundi lambasted the world's richer nations for not putting money into the global fund to fight AIDS. ",
        "isflipped": false
      },
      {
        "id": "wordi6b85018c159544a6ae81705fc2162440",
        "word": "fundamental  ",
        "wordtype": " /fʌndə'mɛnt(ə)l/   a.  Syn. primary; essential ",
        "explanation": " relating to foundation or base; elementary; primary; essential ",
        "wordexample": "El Niao is a natural phenomenon, but some are worried that climate change could now be altering the cycle in fundamental ways. ",
        "isflipped": false
      },
      {
        "id": "wordi7da96eac93d3459982c326a6b1526de3",
        "word": "furthermore  ",
        "wordtype": " /fɜrðə'mɔ (r)/   ad.   ",
        "explanation": " in addition; moreover; still further ",
        "wordexample": "The guy was about forty, Reacher guessed, and furthermore Reacher guessed he had gotten to be about forty by staying relentlessly aware of everything. ",
        "isflipped": false
      },
      {
        "id": "wordi6ed2a4824bd742bd9669b8e6f6a1bec7",
        "word": "gender  ",
        "wordtype": " /'dʒɛndə(r)/   n.   ",
        "explanation": " sexual identity, especially in relation to society or culture; category ",
        "wordexample": "New reforms are largely uncontroversial, such as gender equality measures and improved rights of privacy. ",
        "isflipped": false
      },
      {
        "id": "wordi5c0129b703074cc785e21319bdb68d7c",
        "word": "generate  ",
        "wordtype": " /'dʒɛnəreɪt/   v.  Syn. cause; produce; create ",
        "explanation": " bring into being; give rise to; produce ",
        "wordexample": "Their primary concern is not the health of the American people it is to maximize the revenue they can generate from the American people. ",
        "isflipped": false
      },
      {
        "id": "wordiacba019b2f3940c3953f018408c06883",
        "word": "generation  ",
        "wordtype": " /dʒɛnə'reɪʃ(ə)n/   n.   ",
        "explanation": " all offspring at same stage from common ancestor; interval of time between the birth of parents and their offspring ",
        "wordexample": "They lived a long time, their generation is 100 years to us. ",
        "isflipped": false
      },
      {
        "id": "wordi5a276a51b2314837b8a5b085e46557df",
        "word": "globe  ",
        "wordtype": " /gloʊb/   n.   ",
        "explanation": " body with the shape of a sphere, especially a representation of the earth in the form of a hollow ball ",
        "wordexample": "The average temperature of the globe is well below the optimal for humans and their crops. ",
        "isflipped": false
      },
      {
        "id": "wordi3453aa8a61274ab5954cafd38f68989f",
        "word": "goal  ",
        "wordtype": " /goʊl/   n.  Syn. end; objective; aim ",
        "explanation": " end; objective; final purpose or aim ",
        "wordexample": "My goal, said one, is to share this knowledge with other Afghans, especially Afghan women. ",
        "isflipped": false
      },
      {
        "id": "wordif75d4b6f8ed54ab99cfb1eb80cb72220",
        "word": "grade  ",
        "wordtype": " /greɪd/   n.  Syn. rank ",
        "explanation": " step or degree in any series, rank, quality, order; relative position or standing ",
        "wordexample": "He's not in the first grade as a musician, why do you want to learn piano from him? ",
        "isflipped": false
      },
      {
        "id": "wordi93c9feb6e17e477992f105ee59554235",
        "word": "grant  ",
        "wordtype": " /grɑrnt/   v.   ",
        "explanation": " allow to have; give on the basis of merit; be willing to concede ",
        "wordexample": "I grant the genius of your plan, but you still will not find backers. ",
        "isflipped": false
      },
      {
        "id": "wordi27bddfcc492544b09e387a45a4e62b5e",
        "word": "guarantee  ",
        "wordtype": " /gærən'ti /   n.  Syn. assure; ensure ",
        "explanation": " pledge that something will happen or that something is true ",
        "wordexample": "If it has decided to build a stockpile of nuclear weapons as the best guarantee of its security, then a more dangerous confrontation will be unavoidable. ",
        "isflipped": false
      },
      {
        "id": "wordi738a9b853cfb476da58bd8284a0510e4",
        "word": "guideline  ",
        "wordtype": " /'gaɪdɪlaɪ/   n.   ",
        "explanation": " statement or other indication of policy; light line, used in lettering, to help align the text ",
        "wordexample": "A good guideline is to post enough to keep your page fresh. ",
        "isflipped": false
      },
      {
        "id": "wordiccdbbae8800a4d8fa9c36701efdce317",
        "word": "hence  ",
        "wordtype": " /hɛns/   ad.   ",
        "explanation": " from this place; from this time; from this reason; as an inference or deduction ",
        "wordexample": "She presents herself in public and hence is an object of positive or negative regard, as the case may be. ",
        "isflipped": false
      },
      {
        "id": "wordi3a541e5f031540f29c7a3dc2b0c0b023",
        "word": "hierarchy  ",
        "wordtype": " /'haɪərɑrkɪ/   n.  Syn. class; order ",
        "explanation": " arrangement by rank or standing; series in which each element is graded or ranked ",
        "wordexample": "To be low man on the totem pole is to have an inferior place in the hierarchy. ",
        "isflipped": false
      },
      {
        "id": "wordi1b62ea4669174d13b031109ad7b42398",
        "word": "highlight  ",
        "wordtype": " /'haɪlaɪt/   v.  Syn. emphasize; stress ",
        "explanation": " make prominent; emphasize; stress ",
        "wordexample": "He said it was time to highlight the danger of the possibility of smaller radioactive sources falling into the hands of terrorists. ",
        "isflipped": false
      },
      {
        "id": "wordi2de79930a29140538c8fd947bb97a775",
        "word": "hypothesis  ",
        "wordtype": " /haɪ'pɒθəsɪs/   n.  Syn. assumption; theory ",
        "explanation": " assumption; theory ",
        "wordexample": "A hypothesis is a tentative statement that proposes a possible.  ",
        "isflipped": false
      },
      {
        "id": "wordic58834308d0f49c79ce60d79d377b0b5",
        "word": "identical  ",
        "wordtype": " /aɪ'dɛntɪk(ə)l/   a.  Syn. duplicate; alike ",
        "explanation": " duplicate; alike; being the exact same one ",
        "wordexample": "This is the identical room we stayed in before. ",
        "isflipped": false
      },
      {
        "id": "wordif8982a6fe1e44ff3b90a5c4d7d831782",
        "word": "identify  ",
        "wordtype": " /aɪ'dɛntɪfaɪ/   v.  Syn. detect; spot; find out; discover ",
        "explanation": " detect; find out; discover ",
        "wordexample": "Together they intercept millions of telephone calls, emails and faxes, and with special software, searching for key words and numbers, attempt to identify threats from terrorists, arms proliferators and so on. ",
        "isflipped": false
      },
      {
        "id": "wordi7d0ffff63f1044248aa41d63994d66d4",
        "word": "ideology  ",
        "wordtype": " /aɪdɪ'ɒlədʒɪ/   n.  Syn. belief; idea; philosophy ",
        "explanation": " study of origin and nature of ideas ",
        "wordexample": "For people who had grown up believing in the communist ideology, it was hard to adjust to capitalism. ",
        "isflipped": false
      },
      {
        "id": "wordt3c9d5d179dee45119c4ce8b8387cc0f2",
        "word": "ignorant  ",
        "wordtype": " /'ɪgnərənt/   a.  Syn. unlearned; uneducated; unaware ",
        "explanation": " lacking education or knowledge; unaware ",
        "wordexample": "And what an ignorant little girl she'll think me for asking! ",
        "isflipped": false
      },
      {
        "id": "wordia150bc0bea224614bc562e80cb2a979d",
        "word": "illustrate  ",
        "wordtype": " /'ɪləstreɪt/   v.  Syn. represent; demonstrate; depict ",
        "explanation": " represent; demonstrate; depict; clarify, as by use of examples or comparisons ",
        "wordexample": "The editor will illustrate the definition with an example sentence. ",
        "isflipped": false
      },
      {
        "id": "wordi6016bebc767946e78d3d70537c2047b5",
        "word": "image  ",
        "wordtype": " /'ɪmɪdʒ/   n.  Syn. picture; figure ",
        "explanation": " visual representation; representation of a person ",
        "wordexample": "The emperor's tomb had his image carved in stone. ",
        "isflipped": false
      },
      {
        "id": "wordi7eca63ef612c4965a855827a305cf931",
        "word": "immigrate  ",
        "wordtype": " /'ɪmɪgreɪt/   v.   ",
        "explanation": " move into another country to stay there permanently ",
        "wordexample": "The cost to immigrate legally needs to be lowered, or we will see more border accidents. ",
        "isflipped": false
      },
      {
        "id": "wordia964d4c84e98440e9f8813654859cc3f",
        "word": "impact  ",
        "wordtype": " /'ɪmpækt/   n.  Syn. influence; effect ",
        "explanation": " forceful consequence; strong effect; influencing strongly ",
        "wordexample": "It's hard to characterize the cultural effects, although easier to the vital economic impact on China's neighbors. ",
        "isflipped": false
      },
      {
        "id": "wordi3dc450b6416d4c28a96df77f96436c1d",
        "word": "implement  ",
        "wordtype": " /'ɪmplɪmənt/   v.  Syn. execute; perform ",
        "explanation": " put into effect; supply with tools ",
        "wordexample": "The mayor was unwilling to implement the plan until she was sure it had the governor's backing. ",
        "isflipped": false
      },
      {
        "id": "wordi0b4a32f9135b44d4a3efc4e1c532cb1e",
        "word": "implicate  ",
        "wordtype": " /'ɪmplɪkeɪt/   v.  Syn. incriminate ",
        "explanation": " incriminate; involve or imply as necessary accompaniment or result ",
        "wordexample": "The suspicions again implicate high government officials to the point where 911 could well have been an inside job. ",
        "isflipped": false
      },
      {
        "id": "wordi0c85b79824d24036837a9adacf8c9948",
        "word": "implicit  ",
        "wordtype": " /ɪm'plɪsɪt/   a.  Syn. implied; suggested ",
        "explanation": " implied or understood though not directly expressed ",
        "wordexample": "Jack never told Jill he adored her; he believed his love was implicit in his actions. ",
        "isflipped": false
      },
      {
        "id": "wordidda16803cbe143b4a20c2fa92d91dc10",
        "word": "imply  ",
        "wordtype": " /ɪm'plaɪ/   v.  Syn. signify ",
        "explanation": " express or indicate indirectly; signify ",
        "wordexample": "Why does the word imply male siblings and not female as well? ",
        "isflipped": false
      },
      {
        "id": "wordia69cf2fd7ed44c42b1f9016f57e63240",
        "word": "impose  ",
        "wordtype": " /ɪm'poʊz/   v.  Syn. demand; force; inflict ",
        "explanation": " demand; force; compel to behave in a certain way ",
        "wordexample": "In the past the courts have treated similar cases with great leniency but there's been growing pressure from the government and the public to impose stiffer penalties. ",
        "isflipped": false
      },
      {
        "id": "wordiac2ac943e8d74898a3c93f9694d29830",
        "word": "incentive  ",
        "wordtype": " /ɪn'sɛntɪv/   n.  Syn. spur; motive ",
        "explanation": " something, such as the fear of punishment or the expectation of reward ",
        "wordexample": "Another incentive is the tax and duty-free importation of raw materials to be used for book publishing. ",
        "isflipped": false
      },
      {
        "id": "wordi9bc054af9a3540c4bb6e1d4bc898c89e",
        "word": "incidence  ",
        "wordtype": " /'ɪnsɪd(ə)ns/   n.  Syn. occurrence ",
        "explanation": " rate of occurrence; particular occurrence ",
        "wordexample": "The highest incidence is found in Britain, Australia and Belgium  30 per 1,000,000 per year. ",
        "isflipped": false
      },
      {
        "id": "wordi601e1cb78eca46039b62658934c6e916",
        "word": "incline  ",
        "wordtype": " /ɪn'klaɪn/   n.  Syn. slope; slant ",
        "explanation": " cause to lean, slant, or slope; deviate from the horizontal or vertical ",
        "wordexample": "The architect recommended that the nursing home's ramp be rebuilt because its incline was too steep for wheelchairs. ",
        "isflipped": false
      },
      {
        "id": "wordia28f095478e242d08dc138b70a587e8c",
        "word": "income  ",
        "wordtype": " /'ɪnkʌm/   n.   ",
        "explanation": " gain from labor, business, property, or capital ",
        "wordexample": "I can never do that again, two-thirds of my income goes in paying the interest of mortgages. ",
        "isflipped": false
      },
      {
        "id": "wordi03f5cc04b10b4016b8d8e2e410f3fdea",
        "word": "incorporate  ",
        "wordtype": " /ɪn'kɔ pəreɪt/   v.  Syn. combine; unite ",
        "explanation": " combine something into a larger whole; unite ",
        "wordexample": "I will provide the template for the website but will need someone in incorporate the matrix along with the members area and a few other aspects to go along with the members area. ",
        "isflipped": false
      },
      {
        "id": "wordi742dee14f7ef43a18ca084b420fcd546",
        "word": "index  ",
        "wordtype": " /'ɪndɛks/   n.   ",
        "explanation": " anything  which shows, indicates, manifests, or discloses; prologue indicating what follows; second digit ",
        "wordexample": "Do you know the price index in the city? ",
        "isflipped": false
      },
      {
        "id": "wordif0881c89e1ca457e9ebef9f588d50a63",
        "word": "indicate  ",
        "wordtype": " /'ɪndɪkeɪt/   v.  Syn. show; reflect; evidence; imply; suggest ",
        "explanation": " point out; direct to a knowledge of ",
        "wordexample": "Researchers indicate that men find it easier to give up smoking than women. ",
        "isflipped": false
      },
      {
        "id": "wordi2b4c781380a347e4a0a1aad16dfcbe34",
        "word": "individual  ",
        "wordtype": " /ɪndɪ'vɪdjʊəl/   n.   ",
        "explanation": " single person or thing; human regarded as a unique personality ",
        "wordexample": "If this individual is to be the leader of this country, she will lead us to total defeat. ",
        "isflipped": false
      },
      {
        "id": "wordi34130340b23e44a6be947fbf096dd2a7",
        "word": "induce  ",
        "wordtype": " /ɪn'dju s/;/ɪn'du s/   v.  Syn. persuade ",
        "explanation": " persuade; bring about; reason or establish by induction ",
        "wordexample": "He was as a dog that had been terribly scorched, and nothing would again induce him to go near the fire. ",
        "isflipped": false
      },
      {
        "id": "wordibdbda509bcf4404d96883cc57057313c",
        "word": "inevitable  ",
        "wordtype": " /ɪn'ɛvɪtəb(ə)l/   a.  Syn. unavoidable ",
        "explanation": " unavoidable;  incapable of being avoided or prevented ",
        "wordexample": "Though taxes are supposedly inevitable, some people avoid paying taxes for years. ",
        "isflipped": false
      },
      {
        "id": "wordifc67f70edc88408680da96999a286c32",
        "word": "infer  ",
        "wordtype": " /ɪn'fɜr(r)/   v.  Syn. deduce; conclude ",
        "explanation": " deduce; conclude from evidence or premises; lead to as a consequence or conclusion ",
        "wordexample": "From the students' glazed looks, it was easy for me to infer that they were bored out of their minds. ",
        "isflipped": false
      },
      {
        "id": "wordi85ebc2a2eb254e6089f3b733a9519acb",
        "word": "infrastructure  ",
        "wordtype": " /'ɪnfrəstrʌktʃə(r)/   n.   ",
        "explanation": " underlying base or foundation especially for an organization or system ",
        "wordexample": "Mexican federal aviation officials have indicated a substantial investment in infrastructure is needed for the airline to comply. ",
        "isflipped": false
      },
      {
        "id": "wordi79c08801060f4ee9b8428b616cc38639",
        "word": "inherent  ",
        "wordtype": " /ɪn'hɪərənt/   a.  Syn. intrinsic; natural ",
        "explanation": " firmly established by nature or habit ",
        "wordexample": "Each branch of the federal government has certain inherent powers. ",
        "isflipped": false
      },
      {
        "id": "wordie660baddb6cc4eee965235bb056dc62c",
        "word": "inhibit  ",
        "wordtype": " /ɪn'hɪbɪt/   v.  Syn. restrain; prevent ",
        "explanation": " restrain; prevent or forbid; hold back ",
        "wordexample": "Only two things inhibit him from taking a punch at Mike Tyson  Tyson's left hook, and Tyson's right jab. ",
        "isflipped": false
      },
      {
        "id": "wordi427264c521e34c9fb387dad9978accf9",
        "word": "initial  ",
        "wordtype": " /ɪ'nɪʃ(ə)l/   a.  Syn. preliminary ",
        "explanation": " early; preliminary; occurring at the beginning ",
        "wordexample": "An initial study will look at the terrorist threat to peace-keeping forces in the Balkans. ",
        "isflipped": false
      },
      {
        "id": "wordie181bb8a155e403ab299b7ae5f24c7c7",
        "word": "initiate  ",
        "wordtype": " /ɪ'nɪʃɪeɪt/   v.  Syn. begin; originate ",
        "explanation": " begin; originate; admit into membership ",
        "wordexample": "The college is about to initiate a program in reducing math anxiety among students. ",
        "isflipped": false
      },
      {
        "id": "wordi64f7ad83444e429f80376deeefe2a7a2",
        "word": "injure  ",
        "wordtype": " /'ɪndʒə(r)/   v.   ",
        "explanation": " do harm to; inflict damage; do injustice to ",
        "wordexample": "Generally people who injure limbs have bad arthritis as they mature. ",
        "isflipped": false
      },
      {
        "id": "wordidfdc52597b7646488c023b64b116c93c",
        "word": "innovate  ",
        "wordtype": " /'ɪnəveɪt/   v.   ",
        "explanation": " change or alter by bringing in something new ",
        "wordexample": "For many in our industry, the capacity to innovate is closely tied to developing human resources. ",
        "isflipped": false
      },
      {
        "id": "wordi10a3947a326744048ee7a6f4cc5f8c13",
        "word": "insert  ",
        "wordtype": " /ɪn'sɜrt/   v.  Syn. input; enter ",
        "explanation": " input; enter; put or set into, between, or among ",
        "wordexample": "The proposal for genetic modification involves to insert a fluorescent protein into the virus. ",
        "isflipped": false
      },
      {
        "id": "wordi569f74cdb8334b97839483fecc32599c",
        "word": "insight  ",
        "wordtype": " /'ɪnsaɪt/   n.  Syn. understanding ",
        "explanation": " understanding; grasping the inner nature of things intuitively ",
        "wordexample": "This insight is then applied to three prominent proposals. ",
        "isflipped": false
      },
      {
        "id": "wordi4fd2785fd5894b97afec6762a6eff825",
        "word": "inspect  ",
        "wordtype": " /ɪn'spɛkt/   v.  Syn. examine ",
        "explanation": " look over; examine carefully and critically, especially for flaws ",
        "wordexample": "Please inspect your father's letter carefully. ",
        "isflipped": false
      },
      {
        "id": "wordi5976fd82b1a9464e8fa72f3c67b73d79",
        "word": "instance  ",
        "wordtype": " /'ɪnstəns/   n.  Syn. example ",
        "explanation": " example that is cited to prove a contention or illustrate a point; case or occurrence ",
        "wordexample": "The framework applies equally to all ecosystems and in this instance is adapted for wetlands. ",
        "isflipped": false
      },
      {
        "id": "wordiba467b5b8c4543b9ae8f0f5412f02c23",
        "word": "institute  ",
        "wordtype": " /'ɪnstɪtju t/;/'ɪnstətu t/   n.   ",
        "explanation": " advance or set forth in court; association organized to promote art or science or education ",
        "wordexample": "The institute for biomedical research is a non-profit, independent research and educational organization known as a world leader in its field. ",
        "isflipped": false
      },
      {
        "id": "wordi57f057e2efdd4bb8b811e2d8c4f0cc38",
        "word": "instruct  ",
        "wordtype": " /ɪn'strʌkt/   v.  Syn. teach ",
        "explanation": " teach; make aware of ",
        "wordexample": "She had to instruct the students to work on their pronunciation. ",
        "isflipped": false
      },
      {
        "id": "wordidb1e73e85de94f5393cd4d8d8a0d6462",
        "word": "integral  ",
        "wordtype": " /'ɪntɪgr(ə)l/   a.  Syn. complete;  entire ",
        "explanation": " essential or necessary for completeness; entire ",
        "wordexample": "Despite the ratings agencies' spectacular failures during the recent crisis, their assessments remain integral to the structure of the financial system. ",
        "isflipped": false
      },
      {
        "id": "wordi40656cfd10094fbb81f1ca438b0091f7",
        "word": "integrate  ",
        "wordtype": " /'ɪntɪgreɪt/   v.  Syn. combine ",
        "explanation": " make whole; combine; make into one unit ",
        "wordexample": "She tried to integrate all their activities into one program. ",
        "isflipped": false
      },
      {
        "id": "wordic9d9cf58e9d444459dc3f5f8b98c4921",
        "word": "integrity  ",
        "wordtype": " /ɪn'tɛgrɪtɪ/   n.  Syn. uprightness; wholeness ",
        "explanation": " quality or condition of being whole or undivided; completeness ",
        "wordexample": "Protecting global supply chain integrity is of the utmost importance for manufacturers. ",
        "isflipped": false
      },
      {
        "id": "wordi0c4761477c6042f3bff4eb7b80e7cf4f",
        "word": "intelligence  ",
        "wordtype": " /ɪn'tɛlɪdʒəns/   n.   ",
        "explanation": " ability to comprehend; understand and profit from experience; intellect; power of cognition ",
        "wordexample": "More than half the variance between people in intelligence is also genetic, Mr. Shane reports, adding that smarter people \"tend to be less satisfied with their jobs.\" ",
        "isflipped": false
      },
      {
        "id": "wordi712f0e4123464ddea87cf37582fdfc7e",
        "word": "intense  ",
        "wordtype": " /ɪn'tɛns/   a.  Syn. extreme; acute ",
        "explanation": " extreme; acute; in an extreme degree ",
        "wordexample": "The Israeli and Palestinian girls engage in intense discussions and heated arguments. ",
        "isflipped": false
      },
      {
        "id": "wordifc29885480f54ed0b16cc76889554bf5",
        "word": "interact  ",
        "wordtype": " /ɪntər'ækt/   v.  Syn. interplay ",
        "explanation": " interplay; act together or towards others or with ",
        "wordexample": "Only two months ago, there was much criticism of the founders who organized the floatation and continued to interact with Wall Street. ",
        "isflipped": false
      },
      {
        "id": "wordi90718ed97929415dbc49f09fe9babc6c",
        "word": "intermediate  ",
        "wordtype": " /ɪntə'mi dɪət/   a.   ",
        "explanation": " middle; lying between two extremes ",
        "wordexample": "They are all from sitting to standing without intermediate pushes with the hands. ",
        "isflipped": false
      },
      {
        "id": "wordi02ddc7b3d78a42e783d58a9d936c7a3a",
        "word": "internal  ",
        "wordtype": " /ɪn'tɜrn(ə)l/   a.  Syn. inside; interior ",
        "explanation": " inside; interior;  located within the limits or surface ",
        "wordexample": "An internal audit led to Julie Wall's downfall and her vast collection has now been auctioned to pay back some of what she owes. ",
        "isflipped": false
      },
      {
        "id": "wordi3a94b0aadcbc4e6eb5729215acea1e97",
        "word": "interpret  ",
        "wordtype": " /ɪn'tɜrprɪt/   v.   ",
        "explanation": " explain or tell the meaning of; translate orally; decipher ",
        "wordexample": "When data is kept under lock and key, as mysterious as a temple secret, only the priests can read and interpret it. ",
        "isflipped": false
      },
      {
        "id": "wordt836da589e726426793ac1ac542df1908",
        "word": "interpretation  ",
        "wordtype": " /ɪntɜrprɪ'teɪʃ(ə)n/   n.  Syn. explanation ",
        "explanation": " explanation;  performer's distinctive personal version of a song, dance, piece of music ",
        "wordexample": "General Kazantsev said the interpretation of the leaflets air-dropped on Grozny on Monday, telling civilians to leave or face destruction, was all wrong. ",
        "isflipped": false
      },
      {
        "id": "wordi37b160bc9ec948f8a9ebc2e710fc161b",
        "word": "interval  ",
        "wordtype": " /'ɪntəv(ə)l/   n.  Syn. pause; break ",
        "explanation": " pause; break; space between two objects, points, or units ",
        "wordexample": "The first week, it spouted every five hours, but recently the interval is eight hours. ",
        "isflipped": false
      },
      {
        "id": "wordid27ad3c6865f4437863f8b32f71295ba",
        "word": "intervene  ",
        "wordtype": " /ɪntə'vi n/   v.   ",
        "explanation": " get involved; come, appear, or lie between two things ",
        "wordexample": "The place to intervene is to slow down the number of children who begin smoking. ",
        "isflipped": false
      },
      {
        "id": "wordi372d6b0b8b434d44b8099d27add36c99",
        "word": "intrinsic  ",
        "wordtype": " /ɪn'trɪnsɪk/   a.  Syn. essential; inherent ",
        "explanation": " relating to essential nature of a thing; inherent; built-in ",
        "wordexample": "Although my grandmother's china has little intrinsic value, I shall always cherish it for the memories it evokes. ",
        "isflipped": false
      },
      {
        "id": "wordicbc0319863ad47e581fed49a00b3bc44",
        "word": "invest  ",
        "wordtype": " /ɪn'vɛst/   v.   ",
        "explanation": " put clothe on, as with office or authority; place in possession of rank, dignity, or estate; endow; lay out money or capital in business ",
        "wordexample": "You had better let me invest it along with your six thousand, because if you take it you'll spend it. ",
        "isflipped": false
      },
      {
        "id": "wordieed705b0dcd64e10b02e5c0f4863beb8",
        "word": "investigate  ",
        "wordtype": " /ɪn'vɛstɪgeɪt/   v.  Syn. explore; research; survey ",
        "explanation": " explore; observe or inquire into in detail; examine systematically ",
        "wordexample": "NASA has launched its Contour spacecraft, one of a series of missions designed to investigate comets. ",
        "isflipped": false
      },
      {
        "id": "wordicec15009630b4c11b19e7c3f546fb7a2",
        "word": "invoke  ",
        "wordtype": " /ɪn'voʊk/   v.   ",
        "explanation": " call upon; ask for; request earnestly ",
        "wordexample": "I again invoke the cooperation of the executive and legislative authorities of the States in this great purpose. ",
        "isflipped": false
      },
      {
        "id": "wordic698743811a647a7a58c0332a389e468",
        "word": "involve  ",
        "wordtype": " /ɪn'vɒlv/   v.   ",
        "explanation": " wind round; connect with something; include necessarily; engage thoroughly ",
        "wordexample": "How should we involve ourselves in school life? ",
        "isflipped": false
      },
      {
        "id": "wordiceda0c6c208841a3bd5711e4efa88f6a",
        "word": "isolate  ",
        "wordtype": " /'aɪsəleɪt/   v.  Syn. seclude; separate ",
        "explanation": " seclude; set apart or cut off from others ",
        "wordexample": "That research will isolate a large number of antibodies from humans and animals. ",
        "isflipped": false
      },
      {
        "id": "wordi9916f5884cc94a27937766348422ffc9",
        "word": "issue  ",
        "wordtype": " /'ɪʃu , 'ɪsju /   n.  Syn. subject; topic; problem ",
        "explanation": " subject; topic; problem; edition; publication; release; publish ",
        "wordexample": "The issue could be settled by requiring public education for everyone. ",
        "isflipped": false
      },
      {
        "id": "wordi3cdfd003c88143798ce94da8e2836bd7",
        "word": "item  ",
        "wordtype": " /'aɪtəm/   n.   ",
        "explanation": " a whole individual unit; a distinct part that can be specified separately in a group ",
        "wordexample": "He noticed an item in the New York Times that reported his hometown. ",
        "isflipped": false
      },
      {
        "id": "wordida4f8210797946e48fab5d39970c5f90",
        "word": "journal  ",
        "wordtype": " /'dʒɜrn(ə)l/   n.  Syn. magazine; periodical ",
        "explanation": " magazine; periodical; log; diary; a ledger in which transactions have been recorded as they occurred ",
        "wordexample": "Published twice yearly, the journal is an open access, online publication. ",
        "isflipped": false
      },
      {
        "id": "wordiedcc6544184448d2a6d03d4fa46141ba",
        "word": "justify  ",
        "wordtype": " /'dʒʌstɪfaɪ/   v.  Syn. vindicate;  defend ",
        "explanation": " adjust the spaces between words;  show to be reasonable; explain, clear away ",
        "wordexample": "\"And old Madam Reed, or the Misses, her daughters, will be solicited by you to seek a place, I suppose?\" \"No, sir; I am not on such terms with my relatives as would justify me in asking favours of them--but I shall advertise.\" ",
        "isflipped": false
      },
      {
        "id": "wordia162e4c24e604534ab286cd33110bff3",
        "word": "label  ",
        "wordtype": " /'leɪb(ə)l/   n.   ",
        "explanation": " paper affixed to anything by inscription; slip of ribbon, parchment; writing annexed by way of addition ",
        "wordexample": "There was no label this time with the words \"DRINK ME,\" but nevertheless she uncorked it and put it to her lips. ",
        "isflipped": false
      },
      {
        "id": "wordi99dcefcba6444f43a4fe88108dfa57c2",
        "word": "labour  ",
        "wordtype": " /'leɪbə(r)/   n.   ",
        "explanation": " effort expended on particular task; act of mother giving birth; time period during which mother gives birth ",
        "wordexample": "When Lisa went into labour, her doctor was not around, she says. ",
        "isflipped": false
      },
      {
        "id": "wordic4170265a0324ecbb33171d27eb5e5f0",
        "word": "layer  ",
        "wordtype": " /'leɪə(r)/   n.  Syn. tier; stratum ",
        "explanation": " tier; a relatively thin sheet like expanse or region lying over or under another ",
        "wordexample": "The layer of thick smoke now covering all of southern California, thousands of firefighters are still struggling to contain ten separate blazes. ",
        "isflipped": false
      },
      {
        "id": "wordi6fdc7e98c2d443608fcf2c6c6a037011",
        "word": "lecture  ",
        "wordtype": " /'lɛktʃə(r)/   n.   ",
        "explanation": " teaching by giving a discourse on some subject; speech that is open to the public ",
        "wordexample": "The students could not follow the lecture on modern chemistry. ",
        "isflipped": false
      },
      {
        "id": "wordi60a005351b3d43778928cc5f453a0177",
        "word": "legal  ",
        "wordtype": " /'li g(ə)l/   a.   ",
        "explanation": " created by, permitted by law; according to the law of works ",
        "wordexample": "I could not rid myself of it by any legal proceedings  for the doctors now discovered that my wife was mad. ",
        "isflipped": false
      },
      {
        "id": "wordie1be2daccf664182855b9e721d2590f0",
        "word": "legislate  ",
        "wordtype": " /'lɛdʒɪsleɪt/   v.   ",
        "explanation": " make laws; create or pass laws ",
        "wordexample": "He did his best to legislate from the bench and we'll be living with his opinions for the rest of our lives. ",
        "isflipped": false
      },
      {
        "id": "wordid1c1b8e78a7645a7a173ffb9a775bd92",
        "word": "levy  ",
        "wordtype": " /'lɛvɪ/   v.  Syn. impose; collect ",
        "explanation": " impose fine or tax; collect payment ",
        "wordexample": "Crying \"No taxation without representation,\" the colonists demonstrated against England's power to levy taxes. ",
        "isflipped": false
      },
      {
        "id": "wordi2ad85284077943cba6c4344e077bdd6f",
        "word": "liberal  ",
        "wordtype": " /'lɪbər(ə)l/   a.  Syn. tolerant ",
        "explanation": " open-minded; tolerant; broad-mindedness; having political views favoring reform and progress ",
        "wordexample": "His views may be not agreeable to the liberal political mainstream. ",
        "isflipped": false
      },
      {
        "id": "wordic93853c06a744eed8a4af4c4cd0b9ef0",
        "word": "likewise  ",
        "wordtype": " /'laɪkwaɪz/   ad.  Syn. similarly ",
        "explanation": " similarly; as well; too ",
        "wordexample": "Dostam has a record of switching sides when convenient, and there are many supporters who would do likewise. ",
        "isflipped": false
      },
      {
        "id": "wordic149f4b7a34048daaa5eb88259e9be14",
        "word": "link  ",
        "wordtype": " /lɪŋk/   v.   ",
        "explanation": " be or become joined or united; connect, fasten, or put together two or more pieces ",
        "wordexample": "After a whole day shopping, the travelers will link up again at the airport. ",
        "isflipped": false
      },
      {
        "id": "wordi8b423b4475194d4c90fe870440ed8b58",
        "word": "locate  ",
        "wordtype": " /loʊ'keɪt/;/'loʊkeɪt/   v.  Syn. find; monitor; settle ",
        "explanation": " find; monitor; settle; determine or specify the position or limits o ",
        "wordexample": "It will also develop techniques to locate and tap underground water reservoirs. ",
        "isflipped": false
      },
      {
        "id": "wordi4914ff15408b44e2a6f428a1b427f5e0",
        "word": "logic  ",
        "wordtype": " /'lɒdʒɪk/   n.   ",
        "explanation": " reasoned and reasonable judgment; a system of reasoning ",
        "wordexample": "Your paper lacks the logic to prove your thesis. ",
        "isflipped": false
      },
      {
        "id": "wordifb62a03283a046408b4c6984cc749cc3",
        "word": "maintain  ",
        "wordtype": " /meɪn'teɪn/   v.  Syn. support; sustain ",
        "explanation": " keep in any particular state or condition; keep up or carry on; continue ",
        "wordexample": "What we are actually trying to maintain is never ending growth. ",
        "isflipped": false
      },
      {
        "id": "wordif05740f7e2694dbf96089bc19bee6e59",
        "word": "major  ",
        "wordtype": " /'meɪdʒə(r)/   a.   ",
        "explanation": " greater in number, quantity, or extent; more important ",
        "wordexample": "We have met with major problems in the project and they will be addressed as schedule. ",
        "isflipped": false
      },
      {
        "id": "wordicc90de2c58214cca9bccc3c6353169be",
        "word": "manipulate  ",
        "wordtype": " /mə'nɪpjʊleɪt/   v.  Syn. maneuver; control ",
        "explanation": " operate with one's hands; control or play upon people, forces artfully ",
        "wordexample": "Meanwhile, greed and vanity, using lies and fear, will once again manipulate ignorance and resentment. ",
        "isflipped": false
      },
      {
        "id": "wordid9a2643e222a4df48d4e6bba3886e285",
        "word": "manual  ",
        "wordtype": " /'mænjʊəl/   n.  Syn. guide book ",
        "explanation": " guide book; hand-operated ",
        "wordexample": "Three workers at the plant followed an illegal manual and caused a nuclear reaction late last month. ",
        "isflipped": false
      },
      {
        "id": "wordiaf1655bfb80b4ff8bb136cec78e6c9e4",
        "word": "margin  ",
        "wordtype": " /'mɑrdʒɪn/   n.  Syn. border; rim; room ",
        "explanation": " border; rim; room ",
        "wordexample": "In the lower house, they will have an even bigger margin. ",
        "isflipped": false
      },
      {
        "id": "wordifd7f2fcefa0c460883ef25513e32e6c3",
        "word": "mature  ",
        "wordtype": " /mə'tjʊə(r)/;/mə'tʊər/   v.   ",
        "explanation": " develop and reach maturity; grow old or older ",
        "wordexample": "I need to mature my thoughts in future college years. ",
        "isflipped": false
      },
      {
        "id": "wordi398c72b047ca47ea88748761cdb9543c",
        "word": "maximise  ",
        "wordtype": " /'mæksɪmaɪz/   v.  Syn. maximize ",
        "explanation": " make as big or large as possible ",
        "wordexample": "Glass shelves help maximise light in a small bathroom. ",
        "isflipped": false
      },
      {
        "id": "wordi3b6cf72ea3964d388b8086e92c1eb18d",
        "word": "mechanism  ",
        "wordtype": " /'mɛkənɪz(ə)m/   n.  Syn. device; machine ",
        "explanation": " device; machine; the technical aspects of doing something ",
        "wordexample": "On the key issue of land rights, it called for a mechanism to study ancestral links to the land. ",
        "isflipped": false
      },
      {
        "id": "wordif7f267771c7e4841b3468c742881b32d",
        "word": "media  ",
        "wordtype": " /'mi dɪə/   n.  Syn. medium; television; newspaper ",
        "explanation": " public institutions that report the news, such as newspapers, magazines, radio, and television ",
        "wordexample": "Science fiction in media is exponentially bigger as a market than science fiction in literary form. ",
        "isflipped": false
      },
      {
        "id": "wordid33ef147821d4ca3903bf50e07df9b61",
        "word": "mediate  ",
        "wordtype": " /'mi dɪeɪt/   v.  Syn. negotiate ",
        "explanation": " resolve or settle differences by working with all conflicting parties ",
        "wordexample": "King Solomon was asked to mediate a dispute between two women, each of whom claimed to be the mother of the same child. ",
        "isflipped": false
      },
      {
        "id": "wordi5671dafc703b43ddb2bc17d57d24cb4c",
        "word": "medium  ",
        "wordtype": " /'mi dɪəm/   n.   ",
        "explanation": " state that is intermediate between extremes ",
        "wordexample": "Certainly Shostakovich was lucky to work in a wordless abstract medium, where interpretation is strongly subjective. ",
        "isflipped": false
      },
      {
        "id": "wordi733a2b4e79eb48b788f7fdf3699d9dd0",
        "word": "mental  ",
        "wordtype": " /'mɛnt(ə)l/   a.   ",
        "explanation": " involving mind or intellectual process;  affected by disorder of mind ",
        "wordexample": "All doctors agreed this is a mental patient. ",
        "isflipped": false
      },
      {
        "id": "wordi5aac0db72efb422a875591f544397734",
        "word": "method  ",
        "wordtype": " /'mɛθəd/   n.  Syn. manner; way; mode ",
        "explanation": " orderly procedure or process; regular manner of doing anything ",
        "wordexample": "She told us a simple method for making a pie crust. ",
        "isflipped": false
      },
      {
        "id": "wordi55cf44b8a4344f4988b8f99abad5b6bc",
        "word": "migrate  ",
        "wordtype": " /maɪ'greɪt/;/'maɪgreɪt/   v.   ",
        "explanation": " move from one country or region to another and settle there ",
        "wordexample": "Many Germans chose to migrate to South America in the mid-19th century. ",
        "isflipped": false
      },
      {
        "id": "wordi2656c44d78104295ad63f6a704cc833e",
        "word": "military  ",
        "wordtype": " /'mɪlɪtərɪ/;/-tɛrɪ/   a.  Syn. soldiery; militia ",
        "explanation": " pertaining to soldiers, to arms, or to war; of whole body of soldiers ",
        "wordexample": "In some countries all the young men have to do a year's military service. ",
        "isflipped": false
      },
      {
        "id": "wordi4aad8f86839f420aabf8859f0423bbef",
        "word": "minimal  ",
        "wordtype": " /'mɪnɪm(ə)l/   a.   ",
        "explanation": " the fewest; the least possible ",
        "wordexample": "In order to make it work, you need a certain minimal area of collective surface. ",
        "isflipped": false
      },
      {
        "id": "wordi8fdfa8738bfe481fa9bb04d6b5c61e55",
        "word": "minimise  ",
        "wordtype": " /'mɪnɪmaɪz/   v.  Syn. minimize ",
        "explanation": " reduce to the smallest possible amount, extent, size, or degree ",
        "wordexample": "Some of them wish only to minimise the number of abortions performed, others will be satisfied with nothing less than reducing the number to zero regardless of the consequences. ",
        "isflipped": false
      },
      {
        "id": "wordi8979143524fe4d9597bad2bb919189a9",
        "word": "minimum  ",
        "wordtype": " /'mɪnɪməm/   a.   ",
        "explanation": " the smallest possible quantity ",
        "wordexample": "The questions range from simple tests of knowledge such as - what's the minimum age for buying alcohol? ",
        "isflipped": false
      },
      {
        "id": "wordi7eb5cd9e107b4a7d9d9a0fc2afd68aad",
        "word": "ministry  ",
        "wordtype": " /'mɪnɪstrɪ/   n.   ",
        "explanation": " act of serving; government department, at the administrative level normally headed by a minister ",
        "wordexample": "The ministry has tried to develop a management strategy this year but it has not been implemented because of scarce resources. ",
        "isflipped": false
      },
      {
        "id": "wordica954056a8a14f4cae648b6ccc1f6428",
        "word": "minor  ",
        "wordtype": " /'maɪnə(r)/   a.   ",
        "explanation": " of lesser importance or stature or rank; not of legal age; limited in size or scope ",
        "wordexample": "These two books had minor differences, reading one of them is enough. ",
        "isflipped": false
      },
      {
        "id": "wordi3a923ef8b27e48ad940c36ab1ecaa0ff",
        "word": "mode  ",
        "wordtype": " /moʊd/   n.  Syn. manner; method; style ",
        "explanation": " prevailing style; manner; way of doing something; fashion or style ",
        "wordexample": "The main mode is the regular one that keeps the vehicle's straight ahead motion in check. ",
        "isflipped": false
      },
      {
        "id": "wordi27fdbdeb5eed4d419bd17f67690bb212",
        "word": "modify  ",
        "wordtype": " /'mɒdɪfaɪ/   v.  Syn. alter; change ",
        "explanation": " alter; change ",
        "wordexample": "If you want to modify an existing listing, make sure the url entered below exactly matches the one that appears in our directory.  ",
        "isflipped": false
      },
      {
        "id": "wordia1c6589704f94c7b9cb0f14dba62927a",
        "word": "monitor  ",
        "wordtype": " /'mɒnɪtə(r)/   v.  Syn. observe; watch; locate ",
        "explanation": " observe; watch; keep an eye on ",
        "wordexample": "In this city,  religious police, government officials and squads of schoolboys monitor women and girls' behavior and appearance. ",
        "isflipped": false
      },
      {
        "id": "wordi06740776541e4ba387971adbda98d225",
        "word": "motive  ",
        "wordtype": " /'moʊtɪv/   n.  Syn. intention; purpose ",
        "explanation": " emotion, desire, physiological need; that which gives purpose and direction to behavior ",
        "wordexample": "Pat's main motive is to keep the racial divide alive. ",
        "isflipped": false
      },
      {
        "id": "wordi7163151cedd240a8947609dfdf1534bf",
        "word": "mutual  ",
        "wordtype": " /'mju tjʊəl/   a.  Syn. interactive; shared ",
        "explanation": " common to or shared by two or more parties; shared ",
        "wordexample": "The main thrust is to make progress on practical issues - with mutual trade and business at the top of the agenda. ",
        "isflipped": false
      },
      {
        "id": "wordi99490495718c4274a274359b76c5f7e4",
        "word": "negate  ",
        "wordtype": " /nɪ'geɪt/   v.  Syn. nullify; deny ",
        "explanation": " cancel out; make ineffective or invalid; deny ",
        "wordexample": "A sudden surge of adrenalin can negate the effects of fatigue  there's nothing like a good shock to wake you up. ",
        "isflipped": false
      },
      {
        "id": "wordi103705cc437e4e8389c220c30bf1d134",
        "word": "network  ",
        "wordtype": " /'nɛtwɜrk/   n.   ",
        "explanation": " any system of lines or channels crossing like the fabric of a net; complex, interconnected group or system ",
        "wordexample": "At USA the network of railroads hasn't increased in past decades. ",
        "isflipped": false
      },
      {
        "id": "wordie1a3d2e4a4bb445f988b43732d529a10",
        "word": "neutral  ",
        "wordtype": " /'nju tr(ə)l/;/nu -/   a.  Syn. impartial ",
        "explanation": " impartial; not supporting one side over another ",
        "wordexample": "Edwards will remain neutral until after \"Super Tuesday\", then he will endorse Hillary. ",
        "isflipped": false
      },
      {
        "id": "wordibe2ad25a61b94ac0bd4348f4caeb501d",
        "word": "nevertheless  ",
        "wordtype": " /nɛvəðə'lɛs/   ad.   ",
        "explanation": " not the less; notwithstanding; in spite of that; yet ",
        "wordexample": "While Gaiman does not possess much of a sophisticated literary skill, he nevertheless is an author to read for the interesting and amazing stories. ",
        "isflipped": false
      },
      {
        "id": "wordi0728d72e770e4c48b579ed5b38678e2c",
        "word": "nonetheless  ",
        "wordtype": " /nʌnðə'lɛs/   ad.   ",
        "explanation": " anyway; however ",
        "wordexample": "India hasn't been as successful, but the U.N. says it is nonetheless on track to cut its poverty rate from 51 percent in 1990 to 24 percent in 2015. ",
        "isflipped": false
      },
      {
        "id": "wordib570df8af08a496a9614a6f59511c1e1",
        "word": "norm  ",
        "wordtype": " /nɔ m/   n.  Syn. convention; standard; rule ",
        "explanation": " convention; standard; rule ",
        "wordexample": "This was revoked after the scandals of the clean hands bribery scandal which caused a political earthquake at the time in a country where it had become the norm for businessmen to bribe politicians, but now it is back to square one. ",
        "isflipped": false
      },
      {
        "id": "wordifb2a69236dbf42a08e72846150488f59",
        "word": "notion  ",
        "wordtype": " /'noʊʃ(ə)n/   n.  Syn. idea; conception ",
        "explanation": " general or universal conception; belief or opinion ",
        "wordexample": "With all her knowledge of history, Alice had no very clear notion how long ago anything had happened. ",
        "isflipped": false
      },
      {
        "id": "wordi9339ae4a28a64dafaf2b7ea97829639f",
        "word": "notwithstanding  ",
        "wordtype": " /nɒtwɪð'stændɪŋ/   ad.   ",
        "explanation": " nevertheless; in spite of; despite anything to the contrary ",
        "wordexample": "The danger of a third world war, present appearances notwithstanding, is not imminent. ",
        "isflipped": false
      },
      {
        "id": "wordi5aaa8dcc11be41eeae50a35c241e8d9f",
        "word": "nuclear  ",
        "wordtype": " /'nju klɪə(r)/;/'nu -/   a.  Syn. atomic ",
        "explanation": " of, relating to, or forming a nucleus of an atom; pertaining to, or using nuclear weapons ",
        "wordexample": "The resolution states that CPS Energy should invest further in nuclear energy. ",
        "isflipped": false
      },
      {
        "id": "wordi52749724a1614fd4ac3e177d837ec93a",
        "word": "objective  ",
        "wordtype": " /əb'dʒɛktɪv/   a.  Syn. fair ",
        "explanation": " not influenced by emotions; having actual existence or reality ",
        "wordexample": "Even though he was her son, she tried to be objective about his behavior. ",
        "isflipped": false
      },
      {
        "id": "wordi2fdcd228b9764c48a1a21e00732651da",
        "word": "obtain  ",
        "wordtype": " /əb'teɪn/   v.  Syn. acquire; get; procure; derive ",
        "explanation": " get hold of; gain possession of; acquire, in any way ",
        "wordexample": "Congress exceeded its constitutional authority by requiring that all Americans obtain health insurance or pay a tax penalty. ",
        "isflipped": false
      },
      {
        "id": "wordi2e0a9e766ef4464e85762887dca64e6c",
        "word": "obvious  ",
        "wordtype": " /'ɒbvɪəs/   a.  Syn. evident; apparent ",
        "explanation": " exposed; easily discovered; plain ",
        "wordexample": "It is a stone pillar set up where four roads meet  whitewashed, I suppose, to be more obvious at a distance and in darkness. ",
        "isflipped": false
      },
      {
        "id": "wordi493a3fddf20b4bf3a067706ba619da9e",
        "word": "occupy  ",
        "wordtype": " /'ɒkjʊpaɪ/   v.  Syn. inhabit ",
        "explanation": " inhabit;  live in a certain place; be present in; be inside of ",
        "wordexample": "Interestingly, many other Great War memorials also occupy busy. ",
        "isflipped": false
      },
      {
        "id": "wordi9f5435c026d54d34b5c2cd6108dbcd6c",
        "word": "occur  ",
        "wordtype": " /ə'kɜr(r)/   v.  Syn. happen ",
        "explanation": " take place; be found to exist ; come to one's mind ",
        "wordexample": "Global warming can occur from a variety of causes, both natural and human induced. ",
        "isflipped": false
      },
      {
        "id": "wordid2382bcbf8ac45b7a1cb77f7fecf0f3d",
        "word": "odd  ",
        "wordtype": " /ɒd/   a.  Syn. bizarre; strange; unusual ",
        "explanation": " not easily explained; beyond from the usual or expected; not divisible by two ",
        "wordexample": "It is odd that his name is never mentioned. ",
        "isflipped": false
      },
      {
        "id": "wordi842d5e3de5844a009641a7d8ed2b6360",
        "word": "offset  ",
        "wordtype": " /'ɒfsɛt/;/'ɔ fsɛt/   v.   ",
        "explanation": " counterbalance, counteract, or compensate for; balance ",
        "wordexample": "He raised his prices to offset the increased cost of materials. ",
        "isflipped": false
      },
      {
        "id": "wordi59ec1f77135d42fca372e6d680a1aefd",
        "word": "ongoing  ",
        "wordtype": " /'ɒngoʊɪŋg/   a.   ",
        "explanation": " continuous; existing ",
        "wordexample": "Now, don't forget on top of that you've still got the day-to-day waste being generated so it's an ongoing problem. ",
        "isflipped": false
      },
      {
        "id": "wordi31a6f5b5190c4aceaef7853f4ee0ea3d",
        "word": "option  ",
        "wordtype": " /'ɒpʃ(ə)n/   n.  Syn. alternative; choice; selection ",
        "explanation": " act of choosing; power or freedom to choose ",
        "wordexample": "The Euro made its debut in the financial markets three years ago and it has been an option for any non-cash transaction ever since. ",
        "isflipped": false
      },
      {
        "id": "wordi645f887936ea4e70a1dde8042dd7383c",
        "word": "orient  ",
        "wordtype": " /'ɔ rɪənt/   v.  Syn. direct; guide; lead ",
        "explanation": " focus toward; determine position with reference to another point; locate to face the east ",
        "wordexample": "Philip spent his first day in Denver to orient the telescope toward the moon. ",
        "isflipped": false
      },
      {
        "id": "wordi91ce0f872ecf46ad9edf269a23b5c951",
        "word": "outcome  ",
        "wordtype": " /'aʊtkʌm/   n.  Syn. result; effect ",
        "explanation": " result; end or consequence; result of a random trial ",
        "wordexample": "South Africa praised the outcome of the election as another indication of Africa's growing commitment to multi-party democracy. ",
        "isflipped": false
      },
      {
        "id": "wordi0fc408369814402a843b4f34001cc2ea",
        "word": "output  ",
        "wordtype": " /'aʊtpʊt/   n.  Syn. production; product ",
        "explanation": " act or process of producing; production; amount produced during a certain time ",
        "wordexample": "Oman's oil output is not as high as some of its neighbors. ",
        "isflipped": false
      },
      {
        "id": "wordiec4d5f59be5749039bde4ed4ecbd974d",
        "word": "overall  ",
        "wordtype": " /oʊvər'ɔ l/   a.  Syn. general; comprehensive ",
        "explanation": " general; comprehensive; from one end to the other; including everything ",
        "wordexample": "They are beginning the assessment of the overall need for reconstruction and rehabilitation. ",
        "isflipped": false
      },
      {
        "id": "wordi0d6a7c6329c743eb8e8c3574aece9963",
        "word": "overlap  ",
        "wordtype": " /oʊvə'læp/   n.   ",
        "explanation": " representation of common ground between two things;  extend over and cover a part of ",
        "wordexample": "He warned of the potential for gap, overlap and duplication. ",
        "isflipped": false
      },
      {
        "id": "wordi7be43d695d844fa699bbef776367369d",
        "word": "overseas  ",
        "wordtype": " /oʊvə'si z/   ad.   ",
        "explanation": " beyond or across the sea; abroad ",
        "wordexample": "He lived overseas for many years and never back his mother country. ",
        "isflipped": false
      },
      {
        "id": "wordi4fc63ffd0a334fc09fbcea6bb255ad0e",
        "word": "panel  ",
        "wordtype": " /'pæn(ə)l/   n.  Syn. board ",
        "explanation": " a group of people gathered for a special purpose; small board or pad ",
        "wordexample": "The Constitutional Court, a senior panel of judges often accused of siding with Prime Minister Thaksin Shinawatra, has voted to annul his third election victory, according to one of the judges. ",
        "isflipped": false
      },
      {
        "id": "wordi54d633cf64434a22886d5bd96db7e2d6",
        "word": "paradigm  ",
        "wordtype": " /'pærədaɪm/   n.  Syn. model; example; pattern ",
        "explanation": " one that serves as a pattern or model; system of assumptions, concepts, and practices that constitutes a way of viewing reality ",
        "wordexample": "Pavlov's experiment in which he trains a dog to salivate on hearing a bell is a paradigm of the conditioned-response experiment in behavioral psychology. ",
        "isflipped": false
      },
      {
        "id": "wordiaf924d7bbe214bb9b9251506766d5ceb",
        "word": "paragraph  ",
        "wordtype": " /'pærəgrɑrf/;/'pærəgræf/   n.   ",
        "explanation": " distinct division of written or printed matter that begins on a new, usually indented line ",
        "wordexample": "After you read the next paragraph, you'll be offered the choice of three possible decisions. ",
        "isflipped": false
      },
      {
        "id": "wordida3d184190a84cb7a03b0945c00e44c0",
        "word": "parallel  ",
        "wordtype": " /'pærəlɛl/   n.  Syn. similarity; analogy ",
        "explanation": " make or place something to another's side; of or relating to multiple operations at same time; not intersecting ",
        "wordexample": "Parallel processing is very common in today's computer. ",
        "isflipped": false
      },
      {
        "id": "wordiade3e972ed414516b10dc9fc6abc9931",
        "word": "parameter  ",
        "wordtype": " /pə'ræmɪtə(r)/   n.   ",
        "explanation": " characteristic or feature that distinguishes something from others ",
        "wordexample": "Security's critical parameter is the ratio of workers to retirees. ",
        "isflipped": false
      },
      {
        "id": "wordic8eb47e1a5cf421a80900837ad746e32",
        "word": "participate  ",
        "wordtype": " /pɑr'tɪsɪpeɪt/   v.   ",
        "explanation": " take part in something; share in something ",
        "wordexample": "Everyone in the class is expected to participate in the discussion. ",
        "isflipped": false
      },
      {
        "id": "wordi34d3fe5fec43410990f57f7ef3a26584",
        "word": "partner  ",
        "wordtype": " /'pɑrtnə(r)/   n.   ",
        "explanation": " person who is a member of a partnership; associate who works with others toward a common goal ",
        "wordexample": "She has a live-in partner, is 39 years old, and has three children. ",
        "isflipped": false
      },
      {
        "id": "wordi831f43e4c7404be489bdf5bc0ea34b77",
        "word": "passive  ",
        "wordtype": " /'pæsɪv/   a.  Syn. compliant; inactive ",
        "explanation": " lacking in energy or will;  peacefully resistant in response to injustice ",
        "wordexample": "Mahatma Gandhi urged his followers to pursue a program of passive resistance as he felt that it was more effective than violence. ",
        "isflipped": false
      },
      {
        "id": "wordi48968dcff52442918eb002c925bdfb43",
        "word": "perceive  ",
        "wordtype": " /pə'si v/   v.  Syn. sense; detect ",
        "explanation": " become aware of through the senses; detect ",
        "wordexample": "And though I don't comprehend how it is, I perceive you have acquired a degree of regard for that foolish little child Adele, too; and even for simple dame Fairfax?  ",
        "isflipped": false
      },
      {
        "id": "wordi6121103347a84c9e9e1656192acada60",
        "word": "percent  ",
        "wordtype": " /pə'sɛnt/   n.   ",
        "explanation": " out of each hundred; per hundred; one part in a hundred ",
        "wordexample": "She has invested a large percent of her salary. ",
        "isflipped": false
      },
      {
        "id": "wordibcbc8371044948a1980ae3324a46052f",
        "word": "period  ",
        "wordtype": " /'pɪərɪəd/   n.   ",
        "explanation": " duration, continuance, term; end of something ",
        "wordexample": "Death put a period to his endeavors. ",
        "isflipped": false
      },
      {
        "id": "wordi80eb4e0d139343e1b42652060aa03ad8",
        "word": "persist  ",
        "wordtype": " /pə'sɪst/   v.  Syn. continue; insist; persevere ",
        "explanation": " continue; insist; persevere ",
        "wordexample": "Why, when studies show that cell phone use, and especially texting, while driving impairs drivers more than drinking, do so many people persist in combining these lethal behaviors? ",
        "isflipped": false
      },
      {
        "id": "wordi0a648e5021354cb2910c3250d4b030c8",
        "word": "perspective  ",
        "wordtype": " /pə'spɛktɪv/   n.  Syn. viewpoint; view ",
        "explanation": " appearance of things; view, outlook, or vista ",
        "wordexample": "An essential fact that should put the debate in perspective is that Mary was released after less than four months. ",
        "isflipped": false
      },
      {
        "id": "wordif7961b63faaf4021ac47a849056d493e",
        "word": "phase  ",
        "wordtype": " /feɪz/   n.  Syn. stage; moment ",
        "explanation": " any distinct time period in a sequence of events; stage ",
        "wordexample": "But there's far less consensus on how much the EU might be willing to pay towards reconstruction in a post-war phase, now that it's clear that a conflict will not have United Nations approval. ",
        "isflipped": false
      },
      {
        "id": "wordi98fbde35d01f4c96804061bcc11393ae",
        "word": "phenomenon  ",
        "wordtype": " /fɪ'nɒmɪnən/;/-nɒn-/   n.   ",
        "explanation": " appearance; anything visible, in matter or spirit; extraordinary or very remarkable person, thing, or occurrence ",
        "wordexample": "International terrorism is not just a recent phenomenon. ",
        "isflipped": false
      },
      {
        "id": "wordi3df55836a0484d968dfa17682c5fb8c2",
        "word": "philosophy  ",
        "wordtype": " /fɪ'lɒsəfɪ/   n.   ",
        "explanation": " body of highest truth; investigation of nature, causes, or principles of reality, knowledge, or values, based on logical reasoning ",
        "wordexample": "He holds a master's degree in philosophy from the University of Virginia and served as press secretary for Kucinich for President in 2004. ",
        "isflipped": false
      },
      {
        "id": "wordi590036757dd943d58f1ac4d01508d68d",
        "word": "physical  ",
        "wordtype": " /'fɪzɪk(ə)l/   a.   ",
        "explanation": " relating to the body as distinguished from the mind or spirit ",
        "wordexample": "Because you know, every intelligent person knows, that the physical is the basis for the mental and the moral. ",
        "isflipped": false
      },
      {
        "id": "wordib3597ae677dd4d6996ed37f3e12f71e4",
        "word": "plus  ",
        "wordtype": " /plʌs/   a.   ",
        "explanation": " involving advantage or good; on the positive side or higher end of a scale ",
        "wordexample": "This company controls main gas resource plus many of the pipelines that supply it to Europe. ",
        "isflipped": false
      },
      {
        "id": "wordi489b47fd17c745a5ac4510851a1897a4",
        "word": "policy  ",
        "wordtype": " /'pɒlɪsɪ/   n.   ",
        "explanation": " settled method of government to administer; system of public or official administration ",
        "wordexample": "His overall Latin American policy is just as troubling so no country welcomes his visiting until now. ",
        "isflipped": false
      },
      {
        "id": "wordibe181b9d756c467a84838e7930e45f5a",
        "word": "portion  ",
        "wordtype": " /'pɔ ʃ(ə)n/   n.  Syn. part; section; segment ",
        "explanation": " section or quantity within a larger thing; a part of a whole ",
        "wordexample": "The largest portion would go into the players' pockets, but the package included payments into a players' pension account and a donation to selected charities. ",
        "isflipped": false
      },
      {
        "id": "wordi0668697d79b7499c8e4d1672c6095421",
        "word": "pose  ",
        "wordtype": " /poʊz/   v.   ",
        "explanation": " pretend to be someone you are not; assume a posture as for artistic purposes ",
        "wordexample": "We don't know the woman who pose for Leonardo so often. ",
        "isflipped": false
      },
      {
        "id": "wordi7d1880f7620a4be5b54a23cb6554b47c",
        "word": "positive  ",
        "wordtype": " /'pɒzɪtɪv/   a.   ",
        "explanation": " involving advantage or good ; greater than zero; very sure; confident ",
        "wordexample": "An executive involved in the meetings told that Mrs. Bush plans to write a positive book with a minimum of criticism. ",
        "isflipped": false
      },
      {
        "id": "wordicda4195a022346cdb93ee2367ee9e0cb",
        "word": "potential  ",
        "wordtype": " /pə'tɛnʃ(ə)l/   a.  Syn. possible; latent ",
        "explanation": " existing in possibility; expected to become or be ",
        "wordexample": "The volume of unconventional gas isn't significant on a U. K. wide scale, supplying enough electricity for only 1,200 homes, but the potential is there, analysts say. ",
        "isflipped": false
      },
      {
        "id": "wordif374a002e19a4bd4ae6555d98c411fed",
        "word": "practitioner  ",
        "wordtype": " /præk'tɪʃənə(r)/   n.   ",
        "explanation": " someone engaged in a profession as law, medicine ",
        "wordexample": "Another very useful application for the legal practitioner is Google Docs, a Web-based word processing system. ",
        "isflipped": false
      },
      {
        "id": "wordifd3000aad80f4ffcaedad412c67596aa",
        "word": "precede  ",
        "wordtype": " /prɪ'si d/   v.  Syn. antecede ",
        "explanation": " come before; antecede ",
        "wordexample": "Most English adjectives precede the noun they modify. ",
        "isflipped": false
      },
      {
        "id": "wordi03dc4cd318204fbe9057087ddf8e166c",
        "word": "precise  ",
        "wordtype": " /prɪ'saɪs/   a.  Syn. exact; accurate ",
        "explanation": " exact; clearly expressed; accurate or correct ",
        "wordexample": "How exactly, in precise detail, will he bring about this supposed unity? ",
        "isflipped": false
      },
      {
        "id": "wordi8dae54757aaa4b76a0b988ab4c214ecb",
        "word": "predict  ",
        "wordtype": " /prɪ'dɪkt/   v.  Syn. forecast; foretell ",
        "explanation": " state, tell about, or make known in advance, especially on the basis of special knowledge ",
        "wordexample": "We're not trying to predict which markets will all of a sudden have double-digit growth in home prices. ",
        "isflipped": false
      },
      {
        "id": "wordi1bca0ed68da14cd28bca57472a936f1a",
        "word": "predominant  ",
        "wordtype": " /prɪ'dɒmɪnənt/   a.  Syn. principal; dominant; overpowering ",
        "explanation": " most frequent or common; having superior power and influence ",
        "wordexample": "The predominant mood among policy-makers is optimism. ",
        "isflipped": false
      },
      {
        "id": "wordi30f7165aa9394573b849cf93133b9301",
        "word": "preliminary  ",
        "wordtype": " /prɪ'lɪmɪnərɪ/;/-nɛrɪ/   a.  Syn. initial; introductory; preparatory ",
        "explanation": " prior to or preparing for the main matter; introductory ",
        "wordexample": "According to preliminary, unofficial figures, a large majority, some 84 percent, voted in favor. ",
        "isflipped": false
      },
      {
        "id": "wordi215c100a1aeb40248bd454f670d120dc",
        "word": "presume  ",
        "wordtype": " /prɪ'zju m/;/-zu m/   v.  Syn. suppose ",
        "explanation": " take for granted as true in absence of proof; venture without authority ",
        "wordexample": "We are asked to presume that she is innocent. ",
        "isflipped": false
      },
      {
        "id": "wordi4b59724519404fb9acb45c1a241ca642",
        "word": "previous  ",
        "wordtype": " /'pri vɪəs/   a.   ",
        "explanation": " existing or occurring before something else ",
        "wordexample": "That brings the total number of storms to 26, roundly beating the previous record of 21, set 70 years ago. ",
        "isflipped": false
      },
      {
        "id": "wordief96750c355d4f3b85390741b878d07b",
        "word": "primary  ",
        "wordtype": " /'praɪmərɪ/   a.  Syn. principal; prime; fundamental ",
        "explanation": " of first rank or importance or value; essential or basic ",
        "wordexample": "Many ordinary Iraqis appreciated that the primary UN role was humanitarian. ",
        "isflipped": false
      },
      {
        "id": "wordi067f7f42e98c49bab7252656343223d9",
        "word": "prime  ",
        "wordtype": " /praɪm/   a.  Syn. primary; principal; chief ",
        "explanation": " first in excellence, quality, or value; at the best stage; peak; first in degree or rank; chief ",
        "wordexample": "Jordan tonight announced that his group arrested the prime suspect in last week's rocket attack. ",
        "isflipped": false
      },
      {
        "id": "wordid6dc2cb5726b408a8f30e52aa3415b1c",
        "word": "principal  ",
        "wordtype": " /'prɪnsɪp(ə)l/   a.  Syn. chief; main ",
        "explanation": " highest in rank, authority, character, importance, or degree ",
        "wordexample": "Lots of the principal people gathered around the king, to let him see they was on his side. ",
        "isflipped": false
      },
      {
        "id": "wordibf6ee6b9ef034c59a0f51f6bcd455d6a",
        "word": "principle  ",
        "wordtype": " /'prɪnsɪp(ə)l/   n.   ",
        "explanation": " basic truth or law or assumption; rule or law of nature;  rule of personal conduct ",
        "wordexample": "This decision was based on principle rather than expediency. ",
        "isflipped": false
      },
      {
        "id": "wordi045da3d2af8b4971b605dbaaebfb8cd4",
        "word": "prior  ",
        "wordtype": " /'praɪə(r)/   a.  Syn. former; antecedent; anterior; previous ",
        "explanation": " preceding in the order of time; former; previous ",
        "wordexample": "All the arrangements should have been completed prior to our departure. ",
        "isflipped": false
      },
      {
        "id": "wordi6ba9384a8195410a9817cb7575d34c12",
        "word": "priority  ",
        "wordtype": " /praɪ'ɒrɪtɪ/;/-ɔ r-/   n.  Syn. preference; precedence ",
        "explanation": " preceding in time, importance, or urgency ",
        "wordexample": "The company says its number one priority is restoring profits, not gaining market share at any price. ",
        "isflipped": false
      },
      {
        "id": "wordibdd669cb172e451b80114ffa14416fde",
        "word": "proceed  ",
        "wordtype": " /prə'si d/   n.  Syn. continue; advance ",
        "explanation": " follow a certain course; move ahead; travel onward ",
        "wordexample": "The trial cannot proceed,' said the King in a very grave voice, 'until all the jurymen are back in their proper places.' ",
        "isflipped": false
      },
      {
        "id": "wordi3ddcd7b4ba77462c883405306fe466fa",
        "word": "process  ",
        "wordtype": " /'proʊsɛs/;/'prɒsɛs/   n.  Syn. progress; advance; procedure ",
        "explanation": " act of proceeding; continued forward movement; a series of actions ",
        "wordexample": "In short, I began the process of ruining myself in the received style, like any other spoony. ",
        "isflipped": false
      },
      {
        "id": "wordi2569f2f28f964e309c952bcf3df06e45",
        "word": "professional  ",
        "wordtype": " /prə'fɛʃən(ə)l/   a.   ",
        "explanation": " engaged in, or suitable for a profession ",
        "wordexample": "Medical workers on trial face criminal charges that range from professional recklessness to illegal sale of donor blood. ",
        "isflipped": false
      },
      {
        "id": "wordi4a5fa539e2e4493792db9ff8d850d5ee",
        "word": "prohibit  ",
        "wordtype": " /prə'hɪbɪt/;/'proʊ-/   v.  Syn. ban; taboo; forbid ",
        "explanation": " ban; taboo; forbid ",
        "wordexample": "The U.S. Supreme Court has never ruled that public schools must prohibit the distribution of candy canes or Christmas cards. ",
        "isflipped": false
      },
      {
        "id": "wordi0bcc1c12a4e84bf48395dda6684f6c70",
        "word": "project  ",
        "wordtype": " /'prɒdʒɛkt/   n.  Syn. program; plan; scheme ",
        "explanation": " any piece of work that is undertaken or attempted; program; plan; scheme ",
        "wordexample": "The project is run by the top-secret Phantom Works in Seattle, the part of the company which handles Boeing's most sensitive programmes. ",
        "isflipped": false
      },
      {
        "id": "wordi3c68ce50e85f49c3bb6e5b7fc491d053",
        "word": "promote  ",
        "wordtype": " /prə'moʊt/   v.  Syn. publicize; advance ",
        "explanation": " help to flourish; advance in rank; publicize ",
        "wordexample": "Founder of the Children's Defense Fund, Marian Wright Edelman and her team ceaselessly promote the welfare of young people everywhere. ",
        "isflipped": false
      },
      {
        "id": "wordiebdfd4430aab4125a1fc5ff5419cc75e",
        "word": "proportion  ",
        "wordtype": " /prə'pɔ ʃ(ə)n/   n.  Syn. amounts; percentage ",
        "explanation": " percentage; quotient obtained when a part is divided by the whole; part considered in relation to the whole ",
        "wordexample": "The requirements grow linearly, in proportion to the number of folk. ",
        "isflipped": false
      },
      {
        "id": "wordi7fc7db5472a14f8a9f451357bba1243c",
        "word": "prospect  ",
        "wordtype": " /'prɒspɛkt/   n.  Syn. possibility; hope; outlook ",
        "explanation": " possibility of future success; belief about future ",
        "wordexample": "The number of people affected and displaced has increased since the conflict, and at the moment there seems little prospect for them to return to villages. ",
        "isflipped": false
      },
      {
        "id": "wordi5bd090bfee6947788923bc5b123c6dcc",
        "word": "protocol  ",
        "wordtype": " /'proʊtəkɒl/;/-kɔ l/   n.   ",
        "explanation": " code of correct conduct ; rules governing socially acceptable behavior; record of transaction ",
        "wordexample": "When it comes to weddings, the protocol is actual similar to other churches. ",
        "isflipped": false
      },
      {
        "id": "wordic1c23f6e3feb40b484a3406f0cd28de4",
        "word": "psychology  ",
        "wordtype": " /saɪ'kɒlədʒɪ/;/sɪ-/   n.   ",
        "explanation": " science that deals with mental processes and behavior ",
        "wordexample": "One of the things we always focus on in psychology is that you have to separate the behavior from the person. ",
        "isflipped": false
      },
      {
        "id": "wordic6804e35e71e4c73b6a4b85b14c918c6",
        "word": "publication  ",
        "wordtype": " /pʌblɪ'keɪʃ(ə)n/   n.   ",
        "explanation": " act or process of publishing printed matter; communication of information to public ",
        "wordexample": "This publication is accompanied by a beautiful exhibition in the van Gogh museum in Amsterdam. ",
        "isflipped": false
      },
      {
        "id": "wordi8542e1461da74ea184b210971537cec4",
        "word": "publish  ",
        "wordtype": " /'pʌblɪʃ/   v.   ",
        "explanation": " make public; make known to mankind, or to people in general ",
        "wordexample": "It is an honor to publish this extraordinary book. ",
        "isflipped": false
      },
      {
        "id": "wordie18979e1466f4b9d9616ab9db7a8e3a8",
        "word": "purchase  ",
        "wordtype": " /'pɜrtʃəs/   n.   ",
        "explanation": " act or an instance of buying; something bought ",
        "wordexample": "Rules can differ depending whether the purchase is a residence or an investment. ",
        "isflipped": false
      },
      {
        "id": "wordi4f57e79d5844425d903fa41132d200cd",
        "word": "pursue  ",
        "wordtype": " /pə'sju /;/-'su /   v.   ",
        "explanation": " follow in; go in search of or hunt for ",
        "wordexample": "They will bring together 165 researchers from 19 countries to pursue a range of innovative strategies. ",
        "isflipped": false
      },
      {
        "id": "wordi697f0decc4c84b769ad300ff6a756802",
        "word": "qualitative  ",
        "wordtype": " /'kwɒlɪtətɪv/;/-teɪtɪv/   a.   ",
        "explanation": " relating to quality; having the character of quality ",
        "wordexample": "Moody's makes five-year medium-term qualitative assessments for each country. ",
        "isflipped": false
      },
      {
        "id": "wordid11f72f61ff2469a9c01840ca93c2d32",
        "word": "quote  ",
        "wordtype": " /kwoʊt/   v.   ",
        "explanation": " cite or repeat a passage from; repeat or copy the words of another ",
        "wordexample": "He said he could quote several instances of this behavior. ",
        "isflipped": false
      },
      {
        "id": "wordib1854ccb1a45410993ea6a405dcc1d7a",
        "word": "radical  ",
        "wordtype": " /'rædɪk(ə)l/   a.  Syn. drastic; extreme ",
        "explanation": " drastic; extreme; arising from or going to a root or source; basic ",
        "wordexample": "President Correa has shown he is determined to follow a radical program of reforms to tackle poverty in Ecuador. ",
        "isflipped": false
      },
      {
        "id": "wordi4c70908b732041d7b99c1b3fb8999953",
        "word": "random  ",
        "wordtype": " /'rændəm/   a.  Syn. haphazard; chance ",
        "explanation": " without definite purpose, plan, or aim; having no specific pattern ",
        "wordexample": "He used to get super drunk in random places; I don't know where he is now. ",
        "isflipped": false
      },
      {
        "id": "wordi8597991a66b042c8ac415c8610bf5da4",
        "word": "range  ",
        "wordtype": " /reɪndʒ/   n.  Syn. limit ",
        "explanation": " limits within which something can be effective; variety of different things or activities ",
        "wordexample": "Medical workers on trial face criminal charges that range from professional recklessness to corruption, to illegal sale of donor blood. ",
        "isflipped": false
      },
      {
        "id": "wordi8cb162f1e6fa4fbeaa67f227b33b28e7",
        "word": "ratio  ",
        "wordtype": " /'reɪʃɪoʊ/   n.  Syn. rate; proportion ",
        "explanation": " relation which one quantity or magnitude has to another of the same kind; rate; proportion ",
        "wordexample": "Men outnumber women here in the ratio of three to one. ",
        "isflipped": false
      },
      {
        "id": "wordid1564cd19b7c4bcc98bebd6320480fbb",
        "word": "rational  ",
        "wordtype": " /'ræʃən(ə)l/   a.  Syn. logical; reasonable ",
        "explanation": " consistent with; based on; using reason ",
        "wordexample": "One strong proof of my wretchedly defective nature is, that even her expostulations, so mild, so rational, have not influence to cure me of my faults. ",
        "isflipped": false
      },
      {
        "id": "wordi6733d7e4086547269d0ae4fddff3bc30",
        "word": "react  ",
        "wordtype": " /ri 'ækt/   v.   ",
        "explanation": " act against or in opposition to; show a response or a reaction ",
        "wordexample": "They react negatively to everything I say, because they don't trust me. ",
        "isflipped": false
      },
      {
        "id": "wordie183ab56058f4dbe87d62e32245334ea",
        "word": "recover  ",
        "wordtype": " /rɪ'kʌvə(r)/   v.  Syn. regain ",
        "explanation": " get or find back; regain a former condition ",
        "wordexample": "He is very ill and unlikely to recover in this month. ",
        "isflipped": false
      },
      {
        "id": "wordi62bce350c770487aa49c528f0691b50b",
        "word": "refine  ",
        "wordtype": " /rɪ'faɪn/   v.  Syn. purify ",
        "explanation": " purify; make more precise; improve ",
        "wordexample": "They refine many valuable nutrients out of the foods in our modern diet. ",
        "isflipped": false
      },
      {
        "id": "wordi956b1119a9b041ac8ed8c82776179035",
        "word": "regime  ",
        "wordtype": " /reɪ'ʒi m/   n.  Syn. government; administration ",
        "explanation": " form of government; government in power; administration; prevailing social system or pattern ",
        "wordexample": "State Department officials insisted that, privately, the Yeltsin regime is still willing to cooperate in the search for peace. ",
        "isflipped": false
      },
      {
        "id": "wordi483f5eb41ed94fe29541d8dd7613a9f6",
        "word": "region  ",
        "wordtype": " /'ri dʒən/   n.   ",
        "explanation": " province; district; tract; neighborhood; the upper air; sky or heavens; inhabitants of a district ",
        "wordexample": "All in that region was fire and commotion. ",
        "isflipped": false
      },
      {
        "id": "wordid3448e4d83c54da08a5fbfc993141e29",
        "word": "register  ",
        "wordtype": " /'rɛdʒɪstə(r)/   v.  Syn. record ",
        "explanation": " give outward signs of; express; record in writing; enroll as a student ",
        "wordexample": "New students will have to register is tomorrow before getting their books. ",
        "isflipped": false
      },
      {
        "id": "wordid3434caf34334e84b52638545f6e6119",
        "word": "regulate  ",
        "wordtype": " /'rɛgjʊleɪt/   v.  Syn. direct ",
        "explanation": " bring into conformity with rules or principles or usage; impose regulations; fix or adjust the time, amount, degree, or rate of  ",
        "wordexample": "In contrast to Europe, the United States is considering a variety of laws which would regulate spam but essentially allow it unless an individual specifically opts out. ",
        "isflipped": false
      },
      {
        "id": "wordi733805a85d794357a80734c2860dab08",
        "word": "reinforce  ",
        "wordtype": " /ri ɪn'fɔ s/   v.  Syn. strengthen; enhance ",
        "explanation": " give more force or effectiveness to; strengthen; enhance ",
        "wordexample": "The laws will reinforce authority to turn boats away from Australia and impose prison sentences on the crews of boats which do cross the border. ",
        "isflipped": false
      },
      {
        "id": "wordi3281da155ce3411da3aa747f0aefcd06",
        "word": "reject  ",
        "wordtype": " /rɪ'dʒɛkt/   v.  Syn. refuse; deny ",
        "explanation": " turn down; refuse to accept; dismiss from consideration ",
        "wordexample": "He would reject the idea of starting a war. ",
        "isflipped": false
      },
      {
        "id": "wordi58687cb84e254ad9a4134ced9836dc01",
        "word": "relax  ",
        "wordtype": " /rɪ'læks/   v.  Syn. free; loosen; calm ",
        "explanation": " make less severe or strict; become less tense ",
        "wordexample": "Our new colleague should relax if he sees that we are a friendly group. ",
        "isflipped": false
      },
      {
        "id": "wordi289dc382270c4328a153bc931d733dc1",
        "word": "release  ",
        "wordtype": " /rɪ'li s/   v.  Syn. liberate;  freedom ",
        "explanation": " give off; liberate; grant freedom to; make something available ",
        "wordexample": "He wanted to release the list with the names of the prisoners before Monday. ",
        "isflipped": false
      },
      {
        "id": "wordibaecc9fc87364807bf818ec804e675ff",
        "word": "relevant  ",
        "wordtype": " /'rɛlɪvənt/   a.  Syn. pertinent ",
        "explanation": " pertinent; having connection with matter at hand ",
        "wordexample": "The only way for a value brand like ours to remain relevant is to provide innovation that sets us apart. ",
        "isflipped": false
      },
      {
        "id": "wordi9c1c23125ccc46e09c8775bd65ae9db9",
        "word": "reluctance  ",
        "wordtype": " /rɪ'lʌktəns/   n.   ",
        "explanation": " state of being reluctant; unwillingness; hesitancy in taking some action ",
        "wordexample": "The main reason for this reluctance is the threat of litigation for defamation. ",
        "isflipped": false
      },
      {
        "id": "wordif5e415d5b076487ea555e8790d30a69c",
        "word": "rely  ",
        "wordtype": " /rɪ'laɪ/   v.  Syn. trust; depend ",
        "explanation": " rest with confidence; have confidence; depend ",
        "wordexample": "I rely implicitly on His power, and confide wholly in His goodness. ",
        "isflipped": false
      },
      {
        "id": "wordidd751324b1f44e619040e87172d89ef8",
        "word": "remove  ",
        "wordtype": " /rɪ'mu v/   v.   ",
        "explanation": " move away from the position occupied; cause to change place; take away ",
        "wordexample": "The leaving of her mother will remove the last obstacle to their marriage. ",
        "isflipped": false
      },
      {
        "id": "wordi43de510517a34aaba70b133899f4c6ac",
        "word": "require  ",
        "wordtype": " /rɪ'kwaɪə(r)/   v.  Syn. demand; request ",
        "explanation": " insist upon having;  request and expect ",
        "wordexample": "We require our secretary to be on time, otherwise we have to cancel the event. ",
        "isflipped": false
      },
      {
        "id": "wordi47e8de83778e4585bdb847e2ac1bd654",
        "word": "research  ",
        "wordtype": " /rɪ'sɜrtʃ/   v.   ",
        "explanation": " inquire into; attempt to find out in scientific manner ",
        "wordexample": "The students who research the history of English are all in this group. ",
        "isflipped": false
      },
      {
        "id": "wordi6d2c96fd44164991a7937bbf67e5601d",
        "word": "reside  ",
        "wordtype": " /rɪ'zaɪd/   v.  Syn. dwell; live; inhabit ",
        "explanation": " dwell; live in a place permanently or for an extended period ",
        "wordexample": "We reside officially in Iceland. ",
        "isflipped": false
      },
      {
        "id": "wordie1a81ba4a13b418eb1279a8adf49174a",
        "word": "resolve  ",
        "wordtype": " /rɪ'zɒlv/   n.  Syn. determination;  resolution; decision ",
        "explanation": " determination; formal expression by a meeting; agreed to by a vote ",
        "wordexample": "Civic leaders say their resolve is as strong as it was when they rebuilt downtown. ",
        "isflipped": false
      },
      {
        "id": "wordicfb7e8b59cfd40219fb841fc37d666a1",
        "word": "resource  ",
        "wordtype": " /rɪ'sɔ s/;/'ri sɔ rs/   n.  Syn. materials; abilities ",
        "explanation": " materials; abilities; available source ",
        "wordexample": "Still she went on growing, and, as a last resource, she put one arm out of the window, and one foot up the chimney. ",
        "isflipped": false
      },
      {
        "id": "wordi82461288ae454e398075a4e8647a572e",
        "word": "respond  ",
        "wordtype": " /rɪ'spɒnd/   v.  Syn. react; answer ",
        "explanation": " show a reaction to something favorably or as hoped ",
        "wordexample": "Doctors hope his cancer to respond to the aggressive therapy. ",
        "isflipped": false
      },
      {
        "id": "wordi721afd0d96244426a839ee4c997dba6a",
        "word": "restore  ",
        "wordtype": " /rɪ'stɔ (r)/   v.  Syn. reinstate; renovate; renew ",
        "explanation": " give or bring back; return to its original condition ",
        "wordexample": "He told BBC News that they will restore it using 200-year-old techniques and all their old tools. ",
        "isflipped": false
      },
      {
        "id": "wordi8872f870e55143e8a55741abe004906d",
        "word": "restrain  ",
        "wordtype": " /rɪ'streɪn/   v.  Syn. inhibit; stop; repress ",
        "explanation": " keep under control; hold back ; place limits on ",
        "wordexample": "No one had leisure to watch or restrain them. ",
        "isflipped": false
      },
      {
        "id": "wordi5b21641a7f6146e08ac89f841ea84285",
        "word": "restrict  ",
        "wordtype": " /rɪ'strɪkt/   v.  Syn. limit; inhibit; confine ",
        "explanation": " keep or confine within limits ",
        "wordexample": "This will give recommendation on the best way to advance, but not restrict thing. ",
        "isflipped": false
      },
      {
        "id": "wordi829954c61597489dbf915c8ee522f86c",
        "word": "retain  ",
        "wordtype": " /rɪ'teɪn/   v.  Syn. keep; employ ",
        "explanation": " keep; maintain possession of;  hire by payment of a fee; keep in mind; remember ",
        "wordexample": "I read over 100 books a year, and what I retain is usually the general storyline and my impression of the characters. ",
        "isflipped": false
      },
      {
        "id": "wordi77561369cc244c4e8f2895b75f6d44df",
        "word": "reveal  ",
        "wordtype": " /rɪ'vi l/   v.  Syn. expose; uncover ",
        "explanation": " make known; disclose or show ",
        "wordexample": "\"The secret of your birth! Do you mean to say - \" \"Gentlemen,\" says the young man, very solemn, \"I will reveal it to you, for I feel I may have confidence in you.\" ",
        "isflipped": false
      },
      {
        "id": "wordi00f68738a77b42f89c52ed356060005e",
        "word": "revenue  ",
        "wordtype": " /'rɛvənju /;/'rɛvənu /   n.  Syn. income; reward ",
        "explanation": " money which returns from an investment; annual income; reward ",
        "wordexample": "The government's revenue is made up chiefly of the money we pay in taxes. ",
        "isflipped": false
      },
      {
        "id": "wordi86c0603ccdf54a079e92093ce88e7859",
        "word": "reverse  ",
        "wordtype": " /rɪ'vɜrs/   v.  Syn. back; rear ",
        "explanation": " overturn; turn inside out or upside down; turning in the opposite direction ",
        "wordexample": "The Commission has now launched a high-level diplomatic offensive to reverse the ban. ",
        "isflipped": false
      },
      {
        "id": "wordia489db636b9d4a5dacd6843e22540c2b",
        "word": "revise  ",
        "wordtype": " /rɪ'vaɪz/   v.  Syn. amend; change ",
        "explanation": " amend; change ",
        "wordexample": "Later, he would revise his position and said the reason why he couldn't meet the delegates was to do with security concerns. ",
        "isflipped": false
      },
      {
        "id": "wordi4db23e513a3244d3ac10895a59a51a4b",
        "word": "revolution  ",
        "wordtype": " /rɛvə'lu ʃ(ə)n/   n.   ",
        "explanation": " act of revolving; motion of body round a fixed point or line; rotation; total or radical change; fundamental change in political organization ",
        "wordexample": "The invention of aircraft caused a revolution in our ways of travelling. ",
        "isflipped": false
      },
      {
        "id": "wordi5632e4c829af41da9f35fdfa3816f467",
        "word": "rigid  ",
        "wordtype": " /'rɪdʒɪd/   a.  Syn. stiff; strict ",
        "explanation": " stiff and unyielding; strict; hard and unbending; not flexible ",
        "wordexample": "Without integration, we are stuck in rigid, inflexible states and to face chaotic feeling or thought. ",
        "isflipped": false
      },
      {
        "id": "wordi3459bca70924494191a3eaadb73b7e2a",
        "word": "role  ",
        "wordtype": " /roʊl/   n.  Syn. part; function ",
        "explanation": " normal activity of a person in particular social setting; part played by a performer ",
        "wordexample": "Amrozi naively admitted his role in the attack, they said, but the law needs more than confessions, it needs evidence. ",
        "isflipped": false
      },
      {
        "id": "wordi34aceecd8e1b4b3ba8c205d8eb0001b5",
        "word": "route  ",
        "wordtype": " /ru t/   n.  Syn. way ",
        "explanation": " way for travel or transportation ",
        "wordexample": "The pipeline would cross on route from Iran, earning the Pakistani government millions of dollars in transit fees. ",
        "isflipped": false
      },
      {
        "id": "wordi9273fc14eec142c8822c44fe2042bc48",
        "word": "scenario  ",
        "wordtype": " /sɪ'nɑrrɪoʊ/   n.  Syn. screenplay; circumstance ",
        "explanation": " screenplay; outline or model of an expected sequence of events ",
        "wordexample": "The scenario is the same throughout the West countries, all of whose governments are responding to the collapse in similar ways. ",
        "isflipped": false
      },
      {
        "id": "wordi7a08d19ae867426f893d44812b7fe871",
        "word": "schedule  ",
        "wordtype": " /'ʃɛdju l/;/'skɛdʒʊl/   n.  Syn. timetable; agenda ",
        "explanation": " plan for an activity or event; arrange ",
        "wordexample": "Now, after the failure of Cancun, there's a much bigger question mark over concluding the new deal on schedule. ",
        "isflipped": false
      },
      {
        "id": "wordi17771855e77a443eb8e1860ca6c6c1b5",
        "word": "scheme  ",
        "wordtype": " /ski m/   n.  Syn. design; plan ",
        "explanation": " elaborate and systematic plan of action; chart or outline of a system or object ",
        "wordexample": "As well as the baby bonus scheme, Prime Minister says his government is to encourage more immigration as a way of bringing in more talent. ",
        "isflipped": false
      },
      {
        "id": "wordi427c66b1a9754e43ad4771ccc4c74a3b",
        "word": "scope  ",
        "wordtype": " /skoʊp/   n.  Syn. range; extent; bound ",
        "explanation": " range of one's perceptions, thoughts, or actions; extent; bound ",
        "wordexample": "This group was within the scope of an investigation. ",
        "isflipped": false
      },
      {
        "id": "wordi37ab7788455b410a84504b004a5c851b",
        "word": "section  ",
        "wordtype": " /'sɛkʃ(ə)n/   n.  Syn. part; district; segment ",
        "explanation": " one of several parts; pieces that fit with others to constitute a whole object ",
        "wordexample": "The mob ran out of control along a 5 kilometer section of the main highway to Delhi, smashing fences, looting food and beating up shopkeepers. ",
        "isflipped": false
      },
      {
        "id": "wordi50d9a326c4f2401498f9646211f8d9fe",
        "word": "sector  ",
        "wordtype": " /'sɛktə(r)/   n.  Syn. segment ",
        "explanation": " particular aspect of life or activity;  body of people who form part of society or economy ",
        "wordexample": "He was helpless in an important sector of his life. ",
        "isflipped": false
      },
      {
        "id": "wordi280bfadd77ad4c2794dbefa0497dd1a3",
        "word": "secure  ",
        "wordtype": " /sɪ'kjʊə(r)/   v.  Syn. anchor; defend; confident ",
        "explanation": " free from fear, care, or anxiety; not have reason to doubt ",
        "wordexample": "The troops secure the area before the civilians are allowed to return. ",
        "isflipped": false
      },
      {
        "id": "wordi7b97b95bae4a4848a26f33be478eeb40",
        "word": "seek  ",
        "wordtype": " /si k/   v.   ",
        "explanation": " make an effort to; try to get; try to discover ",
        "wordexample": "I always seek to do good in the world. ",
        "isflipped": false
      },
      {
        "id": "wordib9456520f9b0417bb1f007fac83f3bd8",
        "word": "select  ",
        "wordtype": " /sɪ'lɛkt/   a.   ",
        "explanation": " taken from a number by preference; picked out as more valuable or excellent than others; of special value or excellence ",
        "wordexample": "This is a very select area; you have to be rich to live here. ",
        "isflipped": false
      },
      {
        "id": "wordieaab8e7697874b0e996f21a1b22eafc5",
        "word": "sequence  ",
        "wordtype": " /'si kwəns/   n.   ",
        "explanation": " serial arrangement in which things follow in logical order or a recurrent pattern ",
        "wordexample": "Scientists unveiled the genome sequence of rice - a tool of great potential use to researchers trying to develop new strains of rice with higher yields. ",
        "isflipped": false
      },
      {
        "id": "wordi16ca14faf2ba48fb85ede4405239ff68",
        "word": "series  ",
        "wordtype": " /'sɪəri z, 'sɪərɪz/   n.   ",
        "explanation": " a number of things or events standing or succeeding in order; sequence ",
        "wordexample": "There are a series of books for dogs; I just read one regarding to my puppy. ",
        "isflipped": false
      },
      {
        "id": "wordidf8311c74c3745e48d83079510061a12",
        "word": "shift  ",
        "wordtype": " /ʃɪft/   n.  Syn. change; turn ",
        "explanation": " moving from one setting or context to another; moving very slightly ",
        "wordexample": "Twenty-one developing nations have come together to say, that they believe the meeting will be doomed unless there's a radical shift by the rich nations. ",
        "isflipped": false
      },
      {
        "id": "wordia853e53a88184f96a37cf992b1d6288b",
        "word": "significant  ",
        "wordtype": " /sɪg'nɪfəkənt/   a.  Syn. noteworthy; important ",
        "explanation": " fairly large; important in effect or meaning ",
        "wordexample": "This kind of planning presents the government with a significant problem. ",
        "isflipped": false
      },
      {
        "id": "wordi227585bdc17d485d898ca1a816fa6de4",
        "word": "similar  ",
        "wordtype": " /'sɪmɪlə(r)/   a.   ",
        "explanation": " nearly corresponding; somewhat like; having a general likeness ",
        "wordexample": "In return, it wants the US to make similar moves, as to cut tariffs and increase quotas for EU goods. ",
        "isflipped": false
      },
      {
        "id": "wordi82ce0a6a085247ccbeeb41e3c5584782",
        "word": "simulate  ",
        "wordtype": " /'sɪmjʊleɪt/   v.  Syn. feign; imitate ",
        "explanation": " make a pretence of; reproduce someone's behavior or looks ",
        "wordexample": "He tried to simulate insanity in order to avoid punishment for his crime. ",
        "isflipped": false
      },
      {
        "id": "wordi06b601109ad848059ef427befb5d73e0",
        "word": "site  ",
        "wordtype": " /saɪt/   n.   ",
        "explanation": " physical position in relation to the surroundings; position; location ",
        "wordexample": "When someone asks me where to look for help, your site is always on the list - so thanks. ",
        "isflipped": false
      },
      {
        "id": "wordi1e0e13465cb44f209133905b926d837b",
        "word": "sole  ",
        "wordtype": " /soʊl/   n.  Syn. bottom ",
        "explanation": " bottom; underside of foot or shoe or boot; bottom surface of a plow ",
        "wordexample": "The back of the sole is attached to the shoe by a semi-circle of nails driven from the outside. ",
        "isflipped": false
      },
      {
        "id": "wordid39274f4030e45aea2b63925fe09bc1e",
        "word": "somewhat  ",
        "wordtype": " /'sʌmwɒt/;/-hwɒt/   ad.  Syn. slightly ",
        "explanation": " to some extent or degree; rather; a bit; slightly ",
        "wordexample": "There is a Caribbean feel to the song and that type of energy and enthusiasm to the song that makes it somewhat mystifying. ",
        "isflipped": false
      },
      {
        "id": "wordic5321f579b9449c5b0bb844d6ecea768",
        "word": "source  ",
        "wordtype": " /sɔ s/   n.   ",
        "explanation": " point of origin, such as spring, of stream or river; one that causes, creates, or initiates ",
        "wordexample": "Walters was not expecting an application from this source for the next ten years. ",
        "isflipped": false
      },
      {
        "id": "wordi14f4c63b2ca14dcdbc597da9ab40f18e",
        "word": "specific  ",
        "wordtype": " /spɪ'sɪfɪk/   a.  Syn. particular; definite ",
        "explanation": " stated explicitly or in detail; definite ",
        "wordexample": "FBI officials stressed that they were aware of no specific plot to attack any other aircraft. ",
        "isflipped": false
      },
      {
        "id": "wordi990c4eca97634bf290d921eabadda821",
        "word": "specify  ",
        "wordtype": " /'spɛsɪfaɪ/   v.  Syn. detail; designate ",
        "explanation": " detail; designate ",
        "wordexample": "He didn't specify what crimes he was referring to, but said if proof was found, the police would ask for charges to be brought. ",
        "isflipped": false
      },
      {
        "id": "wordi743dd9226a494aa8bb9b29c48538316e",
        "word": "sphere  ",
        "wordtype": " /sfɪə(r)/   n.  Syn. ball; globe ",
        "explanation": " ball; globe; a particular aspect of life or activity ",
        "wordexample": "I feel more inclination to put you in the way of keeping yourself, and shall endeavor to do so; but observe, my sphere is narrow. ",
        "isflipped": false
      },
      {
        "id": "wordi687b8d35cbb24c39ade2bf81ede42c09",
        "word": "stable  ",
        "wordtype": " /'steɪb(ə)l/   a.  Syn. fixed; steadfast; constant ",
        "explanation": " not easily moved or disturbed ",
        "wordexample": "Keeping insulin stable is important all day long, so avoiding all sugar and anything that breaks down quickly into glucose in the body is the goal. ",
        "isflipped": false
      },
      {
        "id": "wordi22e7e318e8624ba09a847bbed6779101",
        "word": "statistic  ",
        "wordtype": " /stə'tɪstɪk/   n.   ",
        "explanation": " mathematics of the collection, organization, and interpretation of numerical data ",
        "wordexample": "The Census Bureau maintains this site, linking to each state's main statistic site. ",
        "isflipped": false
      },
      {
        "id": "wordi79ff8f7b301542e4bf572a71fb5d5ce2",
        "word": "status  ",
        "wordtype": " /'steɪtəs/   n.  Syn. standing; state ",
        "explanation": " position relative to others; standing ",
        "wordexample": "He never troubled himself about his status. ",
        "isflipped": false
      },
      {
        "id": "wordic585fcb040864e44b0130722bd1a7491",
        "word": "straightforward  ",
        "wordtype": " /streɪt'fɔ wəd/   a.   ",
        "explanation": " proceeding in a straight course or manner; not deviating; honest; frank. ",
        "wordexample": "But a simple and straightforward apology would have been better. ",
        "isflipped": false
      },
      {
        "id": "wordi6c77769b9ea442c9a464a079ee4a23ec",
        "word": "strategy  ",
        "wordtype": " /'strætɪdʒɪ/   n.   ",
        "explanation": " elaborate and systematic plan; plan of action intended to accomplish a specific goal ",
        "wordexample": "The centre will carry out research and develop a strategy to fight the spread of the disease. ",
        "isflipped": false
      },
      {
        "id": "wordi60ea0dd92fed45c3aed01166e2a68b86",
        "word": "stress  ",
        "wordtype": " /strɛs/   n.  Syn. emphasis ",
        "explanation": " put special emphasis on; utter with an accent; state of extreme difficulty, pressure, or strain ",
        "wordexample": "He presided over the economy during the period of its greatest stress and danger. ",
        "isflipped": false
      },
      {
        "id": "wordia0b0c3a96b574cdf93015466f7c0e7ae",
        "word": "structure  ",
        "wordtype": " /'strʌktʃə(r)/   n.   ",
        "explanation": " complex construction or entity; complex composition of knowledge ",
        "wordexample": "Sociologists have studied the changing structure of the family. ",
        "isflipped": false
      },
      {
        "id": "wordi4074d9a832e540edab97884e1d69c04a",
        "word": "style  ",
        "wordtype": " /staɪl/   n.   ",
        "explanation": " particular kind; a way of expressing something ",
        "wordexample": "All the reporters were expected to adopt the style of this newspaper. ",
        "isflipped": false
      },
      {
        "id": "wordif792595e2d9948b7bd8c0a0d3ff054c3",
        "word": "submit  ",
        "wordtype": " /səb'mɪt/   v.  Syn. defer; yield ",
        "explanation": " refer for judgment or consideration; hand in; present ",
        "wordexample": "What I submit is a dialogue that respects the humanity of both parties. ",
        "isflipped": false
      },
      {
        "id": "wordi3699e33afb434267858c0a4972842d1d",
        "word": "subordinate  ",
        "wordtype": " /sə'bɔ dɪnət/;/-dənət/   a.  Syn. inferior; submissive ",
        "explanation": " occupying lower rank; inferior; submissive ",
        "wordexample": "Bishop Proudie's wife expected all the subordinate clergy to behave with great deference to the wife of their superior. ",
        "isflipped": false
      },
      {
        "id": "wordi862038c9772745daad27176744c52589",
        "word": "subsequent  ",
        "wordtype": " /'sʌbsɪkwənt/   a.  Syn. following ",
        "explanation": " following in time or order; succeeding; later ",
        "wordexample": "In subsequent days, other polls showed that the margin hadn't narrowed all that much. ",
        "isflipped": false
      },
      {
        "id": "wordie6772718c9ad4e76bed3e530157e24b6",
        "word": "subsidy  ",
        "wordtype": " /'sʌbsɪdɪ/   n.  Syn. financing ",
        "explanation": " direct financial aid by government ",
        "wordexample": "Without this subsidy, American ship operators would not be able to compete in world markets. ",
        "isflipped": false
      },
      {
        "id": "wordi5a89d9340da94bdd8b22ab9ae9ac8b2b",
        "word": "substitute  ",
        "wordtype": " /'sʌbstɪtju t/;/-tu t/   v.  Syn. exchange; replace ",
        "explanation": " exchange; put in the place of another ",
        "wordexample": "Low and middle income countries are suffering from the condition, as they substitute fiber intake for a much higher consumption of saturated fats and sugar. ",
        "isflipped": false
      },
      {
        "id": "wordi623910d275a049aeadfec70c2e01adfd",
        "word": "successor  ",
        "wordtype": " /sək'sɛsə(r)/   n.   ",
        "explanation": " one who or that which succeeds or follows; one who takes the place which another has left ",
        "wordexample": "The real-estate investment trust said the search for a successor is already underway, and will include both internal and external candidates. ",
        "isflipped": false
      },
      {
        "id": "wordiafd17a93b55a4db7bfd53f23e6ec9d06",
        "word": "sufficient  ",
        "wordtype": " /sə'fɪʃ(ə)nt/   a.  Syn. adequate; enough ",
        "explanation": " adequate; enough; being as much as is needed ",
        "wordexample": "Then the scanty supply of food was distressing  with the keen appetites of growing children, we had scarcely sufficient to keep alive a delicate invalid. ",
        "isflipped": false
      },
      {
        "id": "wordi9db60d2fa9ec4bef9a925ed46957f16c",
        "word": "sum  ",
        "wordtype": " /sʌm/   n.   ",
        "explanation": " mount or whole of any number of individuals or particulars added together; amount ",
        "wordexample": "Individual accomplishments are important, but the sum is always greater in value than the individual parts. ",
        "isflipped": false
      },
      {
        "id": "wordi3f361427b07044baa4b26449ff44627b",
        "word": "summary  ",
        "wordtype": " /'sʌmərɪ/   n.   ",
        "explanation": " brief statement that presents the main points ",
        "wordexample": "He gave a summary of the conclusions. ",
        "isflipped": false
      },
      {
        "id": "wordi3373409b893c4db48a32c134efd4a65a",
        "word": "supplement  ",
        "wordtype": " /'sʌplɪmənt/   v.  Syn. add; complement ",
        "explanation": " add as something seems insufficient; complement; extension; addition ",
        "wordexample": "A food supplement is a preparation intended to supply nutrients, which are missing or not consumed in sufficient quantity in a person's diet. ",
        "isflipped": false
      },
      {
        "id": "wordieb96d2ff33154ab790e286cb6c6742a5",
        "word": "survey  ",
        "wordtype": " /sə'veɪ/   n.  Syn. poll; review ",
        "explanation": " poll; detailed critical inspection ",
        "wordexample": "A Bank of Israel survey has now shown that the number of families living below the poverty line in Israel tripled between 1988 and 2001. ",
        "isflipped": false
      },
      {
        "id": "wordi81fba0201311485392129658211acf6d",
        "word": "survive  ",
        "wordtype": " /sə'vaɪv/   v.  Syn. endure; tolerate; outlive ",
        "explanation": " continue to live; endure or last ",
        "wordexample": "In 1998, he was lucky to survive when his balloon plummeted into the sea. ",
        "isflipped": false
      },
      {
        "id": "wordi5e765996ccec4e388419059678af90b6",
        "word": "suspend  ",
        "wordtype": " /sə'spɛnd/   v.  Syn. hang; append ",
        "explanation": " hang freely; postpone; delay ",
        "wordexample": "As the warning of earthquake, a number of train and subway lines had to suspend services. ",
        "isflipped": false
      },
      {
        "id": "wordicdffb01433ea420d8ec116698c0bcf34",
        "word": "sustain  ",
        "wordtype": " /sə'steɪn/   v.  Syn. support; nourish; maintain ",
        "explanation": " admit as valid; keep in existence; lengthen or extend in duration or space ",
        "wordexample": "How can a country like Spain sustain the millions of migrants who were losing their jobs in 2009 and provide them with the same welfare state Spaniards can access in times of economic crisis? ",
        "isflipped": false
      },
      {
        "id": "wordic3a1d788b65747b9a60950b62f72b6e2",
        "word": "symbol  ",
        "wordtype": " /'sɪmb(ə)l/   n.  Syn. sign; signal ",
        "explanation": " sign; something visible to represent something else invisible ",
        "wordexample": "Often the destruction takes place in public, as a visible symbol of peace replacing war. ",
        "isflipped": false
      },
      {
        "id": "wordid1bf9fe370274e73a82f7781d2983cdf",
        "word": "tape  ",
        "wordtype": " /teɪp/   n.   ",
        "explanation": " long thin piece of cloth or paper; measuring instrument for length by narrow strip ",
        "wordexample": "The carpenter should have used his tape measure the room before any other jobs. ",
        "isflipped": false
      },
      {
        "id": "wordi22dcc67588614c47bbd704cecb41360f",
        "word": "target  ",
        "wordtype": " /'tɑrgɪt/   n.   ",
        "explanation": " reference point to shoot at; goal intended to be attained ",
        "wordexample": "The iPhone 5 is an obvious target for Apple fans to pursue. ",
        "isflipped": false
      },
      {
        "id": "wordi79e026464ee14f4a9fb067fe8f2599e8",
        "word": "task  ",
        "wordtype": " /tɑrsk/;/tæsk/   v.  Syn. undertake; labor ",
        "explanation": " labor or study imposed by another; undertake; labor ",
        "wordexample": "I wished that she would always be so pleasant, and never push me about, or task me unreasonably. ",
        "isflipped": false
      },
      {
        "id": "wordib48f1f78212542de8e89c5edef0ca3a9",
        "word": "team  ",
        "wordtype": " /ti m/   n.  Syn. gang ",
        "explanation": " a number of persons associated together in any work; a flock of wild ducks ",
        "wordexample": "Volleyball is a team game, how about beach volleyball? ",
        "isflipped": false
      },
      {
        "id": "wordic648dc5fd6bd475c9bfb2debbae4fec7",
        "word": "technical  ",
        "wordtype": " /'tɛknɪk(ə)l/   a.   ",
        "explanation": " having special skill or knowledge; according to principle; formal rather than practical; relating to technique ",
        "wordexample": "The ASX yesterday halted trading for four hours after detecting a technical issue. ",
        "isflipped": false
      },
      {
        "id": "wordib3f0f4adee5143339d5b659450d65e68",
        "word": "technique  ",
        "wordtype": " /tɛk'ni k/   n.   ",
        "explanation": " practical method or art applied to some particular task; skillfulness ",
        "wordexample": "He displayed a flawless technique in the competition. ",
        "isflipped": false
      },
      {
        "id": "wordib3d35c168cf846c38759659565a7432f",
        "word": "technology  ",
        "wordtype": " /tɛk'nɒlədʒɪ/   n.   ",
        "explanation": " application of science, especially to industrial or commercial objectives ",
        "wordexample": "Without a doubt, they say the use of electronic records and other advances in technology is dramatically improving patient care. ",
        "isflipped": false
      },
      {
        "id": "wordi33ecaca5fd0042649fddcb4a9a1ed812",
        "word": "temporary  ",
        "wordtype": " /'tɛmpərərɪ/;/-pərɛrɪ/   a.  Syn. impermanent ",
        "explanation": " not permanent; not lasting ",
        "wordexample": "The Administration says the tariffs were meant to be a temporary measure designed to give the American steel industry time to reorganize. ",
        "isflipped": false
      },
      {
        "id": "wordi158b82c0600743c393d179ad5a3e0878",
        "word": "tense  ",
        "wordtype": " /tɛns/   a.  Syn. strained; taut; tight ",
        "explanation": " stretch or force to the limit; tight ",
        "wordexample": "The northern city of Kano, which has a history of sectarian violence is especially tense, but has remained peaceful. ",
        "isflipped": false
      },
      {
        "id": "wordie489c84c141e4b82a8de9b4e350ef65b",
        "word": "terminate  ",
        "wordtype": " /'tɜrmɪneɪt/   v.  Syn. stop; end ",
        "explanation": " stop; bring to an end or halt ",
        "wordexample": "The attack would terminate the relatively peaceful period after cold war. ",
        "isflipped": false
      },
      {
        "id": "wordi904f4d6d297a44a083054910c53575e6",
        "word": "text  ",
        "wordtype": " /tɛkst/   n.   ",
        "explanation": " written words; book prepared for use in schools or colleges ",
        "wordexample": "A controversial new edition of a Japanese history text book has been chosen by a public school board for use in its schools. ",
        "isflipped": false
      },
      {
        "id": "wordi20a87abc3a9147efb59886ae56f82740",
        "word": "theme  ",
        "wordtype": " /θi m/   n.  Syn. subject; motif; topic ",
        "explanation": " subject of conversation or discussion; topic; essay ",
        "wordexample": "His letters were always on the theme of love. ",
        "isflipped": false
      },
      {
        "id": "wordib5063ed11b0a42288d8916170b7b3554",
        "word": "theory  ",
        "wordtype": " /'θɪərɪ/   n.   ",
        "explanation": " doctrine or scheme of things; general or abstract principles of any science ",
        "wordexample": "The other main theory is that stress during birth somehow leads to left-handedness. ",
        "isflipped": false
      },
      {
        "id": "wordi89eb064a4ecb43f8a400b95ded2666ae",
        "word": "thereby  ",
        "wordtype": " /ðɛə'baɪ/   ad.  Syn. thus; accordingly; consequently ",
        "explanation": " thus; accordingly; by that means; because of that ",
        "wordexample": "They hunger and thirst no more; all their wants are supplied, and all the uneasiness caused thereby is removed. ",
        "isflipped": false
      },
      {
        "id": "wordi1b0cd1e4e12b495fb290834fb51e03c2",
        "word": "thesis  ",
        "wordtype": " /'θi sɪs/   n.  Syn. paper; dissertation ",
        "explanation": " paper; dissertation; an unproved statement put forward as a premise in an argument ",
        "wordexample": "A good thesis makes the difference between a thoughtful research project and a simple retelling of facts. ",
        "isflipped": false
      },
      {
        "id": "wordi88bf202f747249e3988f492c85506464",
        "word": "topic  ",
        "wordtype": " /'tɒpɪk/   n.   ",
        "explanation": " subject of a speech, essay, thesis, discussion, or conversation ",
        "wordexample": "It was a very sensitive topic to discuss, may I have chance to change it? ",
        "isflipped": false
      },
      {
        "id": "wordi65b48781ee0548ddab8bcc775a851b28",
        "word": "trace  ",
        "wordtype": " /treɪs/   v.  Syn. imprint; residues ",
        "explanation": " follow, discover; make a mark or lines on a surface ",
        "wordexample": "The first problem is who is responsible for the material  the original author, who may be impossible to trace, or the Internet service provider. ",
        "isflipped": false
      },
      {
        "id": "wordi8275b6f04e8146fab942626eab6a0098",
        "word": "tradition  ",
        "wordtype": " /trə'dɪʃ(ə)n/   n.  Syn. heritage ",
        "explanation": " thought or behavior followed from generation to generation;  heritage ",
        "wordexample": "The state of Massachusetts has always been famous for its history, and especially rich in tradition is the region around Boston. ",
        "isflipped": false
      },
      {
        "id": "wordib51a7a2f2b034ea393526cdc708d2b42",
        "word": "transfer  ",
        "wordtype": " /træns'fɜr(r), trɑr-/   n.  Syn. shift; distract; divert ",
        "explanation": " shifting; conveyance or removal of something from one place, person, or thing to another ",
        "wordexample": "They are also looking into allegations of the illegal transfer of shares that enabled the Chung family to retain management control. ",
        "isflipped": false
      },
      {
        "id": "wordie2260167e9484568a5be11febb29c3b5",
        "word": "transform  ",
        "wordtype": " /træns'fɔ m, trɑr-/   v.  Syn. change; convert ",
        "explanation": " change in outward structure or looks; convert ",
        "wordexample": "He wants to transform into a monster. ",
        "isflipped": false
      },
      {
        "id": "wordibac592db3fd346a0bc101c5f3409e23e",
        "word": "transit  ",
        "wordtype": " /'trænsɪt, 'trɑr-/   n.   ",
        "explanation": " act of passing; passage through or over; line or route of passage ",
        "wordexample": "The transit was damaged by flood; we were blocked at a remote mountain village. ",
        "isflipped": false
      },
      {
        "id": "wordie08b17d545a5413b8b8cc253c1416ce4",
        "word": "transmit  ",
        "wordtype": " /trænz'mɪt, trɑr-/   v.  Syn. forward; convey ",
        "explanation": " forward; send from one person or place to another ",
        "wordexample": "They transmit his secret to the whole town. ",
        "isflipped": false
      },
      {
        "id": "wordie0a3da24a8984bf28a48829b9bdeab7b",
        "word": "transport  ",
        "wordtype": " /træns'pɔ t, trɑr-/   v.  Syn. convey ",
        "explanation": " carry from one place to another; carry away; deport ",
        "wordexample": "What I was trying to transport is the oil that is in demand particularly. ",
        "isflipped": false
      },
      {
        "id": "wordi571bcd310f2a4af09a59832de56defd9",
        "word": "trend  ",
        "wordtype": " /trɛnd/   n.  Syn. tendency ",
        "explanation": " popular taste; general direction in which something tends to move ",
        "wordexample": "Only late last year, Air Canada seemed to be contradicting the downward trend affecting US-based airlines by posting profits. ",
        "isflipped": false
      },
      {
        "id": "wordi86e04525a8ae4ce393b1a65b2279720a",
        "word": "trigger  ",
        "wordtype": " /'trɪgə(r)/   v.  Syn. initiate; start ",
        "explanation": " cause something happen; set off ",
        "wordexample": "Please skip the remarks that will trigger bitter debates again. ",
        "isflipped": false
      },
      {
        "id": "wordi017d4e3638764c648cdaf978a7526c70",
        "word": "ultimate  ",
        "wordtype": " /'ʌltɪmət/   a.  Syn. final; fundamental; extreme ",
        "explanation": " final; being the last or concluding; fundamental; elemental; extreme ",
        "wordexample": "As the ultimate arbiter of the Constitution, the Supreme Court occupies a central place in our scheme of government. ",
        "isflipped": false
      },
      {
        "id": "wordie109aa3488c64a0bab78f090a93093ae",
        "word": "undergo  ",
        "wordtype": " /ʌndə'goʊ/   v.  Syn. experience; suffer ",
        "explanation": " experience; suffer; pass through ",
        "wordexample": "In February, a court ruled that Mr. Doe should undergo a DNA test. ",
        "isflipped": false
      },
      {
        "id": "wordi980b7705839f4a298827ef3ff419308c",
        "word": "underlie  ",
        "wordtype": " /ʌndə'laɪ/   v.   ",
        "explanation": " be located under or below; be the support or basis of; account for ",
        "wordexample": "In turn, some of these ideas also underlie the Risch algorithm, which is used in Mathematics for indefinite integration. ",
        "isflipped": false
      },
      {
        "id": "wordicda1c6da39554e7d9d40de244f593d48",
        "word": "undertake  ",
        "wordtype": " /ʌndə'teɪk/   v.  Syn. embark; assume ",
        "explanation": " take on; embark on; assume ",
        "wordexample": "Can we expect mini robots to undertake major tasks? ",
        "isflipped": false
      },
      {
        "id": "wordid9fd848e2bbf4105ac0d8daa1fc5a129",
        "word": "uniform  ",
        "wordtype": " /'ju nɪfɔ m/   n.   ",
        "explanation": " consistent; standardized; clothing of a particular group ",
        "wordexample": "At issue is a demand that all imports are accompanied by uniform certificates authorised by the Commission and not the individual member states. ",
        "isflipped": false
      },
      {
        "id": "wordic2c93c70f03a4843b3cc760fbf7006bc",
        "word": "unify  ",
        "wordtype": " /'ju nɪfaɪ/   v.  Syn. integrate; unite ",
        "explanation": " integrate; make into or become one unit ",
        "wordexample": "A proposal by Oracle could help unify emerging specifications for orchestrating Web services. ",
        "isflipped": false
      },
      {
        "id": "wordi224b8478a6cd4128a7f93a8c1a0b0ce9",
        "word": "unique  ",
        "wordtype": " /jʊ'ni k/   a.  Syn. alone; single; sole ",
        "explanation": " without an equal; being the only one of its kind ",
        "wordexample": "You have to face a problem unique to coastal areas. ",
        "isflipped": false
      },
      {
        "id": "wordifef927724b044f63b14854a484338838",
        "word": "utilise  ",
        "wordtype": " /ju 'tɪlaɪz/   v.  Syn. utilize ",
        "explanation": " make useful; find a practical use for; utilize ",
        "wordexample": "Development must be integrated and sustainable, that is to say utilise our resources to satisfy present needs without compromising the needs of future generations. ",
        "isflipped": false
      },
      {
        "id": "wordi096a3867e7eb4bc1ac22315ab8db1522",
        "word": "valid  ",
        "wordtype": " /'vælɪd/   a.  Syn. sound; true ",
        "explanation": " logically convincing; sound; legally acceptable; well grounded ",
        "wordexample": "He said the large number of people surveyed and the lack of corrupting factors mean certain valid conclusions can be drawn from the results. ",
        "isflipped": false
      },
      {
        "id": "wordi12175b7a0d534085a05c7cf532e96014",
        "word": "vary  ",
        "wordtype": " /'vɛərɪ/   v.   ",
        "explanation": " change aspect of; alter in form, appearance, substance, position; make different by a partial change; modify ",
        "wordexample": "I believe she was happy in her way  nothing would force her to vary its clockwork regularity. ",
        "isflipped": false
      },
      {
        "id": "wordid6224c3141234cbbb43e5c7cea0a9073",
        "word": "vehicle  ",
        "wordtype": " /'vi ɪk(ə)l/;/'vi hɪkl/   n.  Syn. automobile; instrument ",
        "explanation": " automobile; means of conveying; medium ",
        "wordexample": "The vehicle was driven to an underground garage where, say police, the robbers transferred four strong boxes full of cash into a getaway car. ",
        "isflipped": false
      },
      {
        "id": "wordi18811fb12b9240b1985112cb074c8b7b",
        "word": "version  ",
        "wordtype": " /'vɜrʃ(ə)n/;/'vərʒn/   n.  Syn. edition ",
        "explanation": " written work in a new form; edition; interpretation of a particular viewpoint ",
        "wordexample": "He downloaded the latest version of the software from the Internet. ",
        "isflipped": false
      },
      {
        "id": "wordi6c3bcaccdd78458bb7afe2d0e27d0ed8",
        "word": "via  ",
        "wordtype": " /'vaɪə/   ad.   ",
        "explanation": " by the way of ",
        "wordexample": "He flew to Europe via the North Pole. ",
        "isflipped": false
      },
      {
        "id": "wordib4a81c408e2140faa2df851c81a6cb6b",
        "word": "violate  ",
        "wordtype": " /'vaɪəleɪt/   v.   ",
        "explanation": " treat in a violent manner; abuse; do violence to; disturb; interrupt ",
        "wordexample": "I should be certain that whatever charter you might grant under coercion, your first act, when released, would be to violate its conditions. ",
        "isflipped": false
      },
      {
        "id": "wordicc8deb8b17a24b408032553ba20ccf18",
        "word": "virtual  ",
        "wordtype": " /'vɜrtjʊəl/   a.   ",
        "explanation": " existing or resulting in essence or effect though not in actual fact; existing in mind, especially as a product of imagination ",
        "wordexample": "Today, 100 bloggers are conducting a virtual protest to decry the large numbers of out-of-wedlock births in the black community. ",
        "isflipped": false
      },
      {
        "id": "wordid674622da39d48c19ecde005d3c88e54",
        "word": "visible  ",
        "wordtype": " /'vɪzɪb(ə)l/   a.   ",
        "explanation": " being often in public eye; obvious to the eye  ",
        "wordexample": "The brightened comet in the constellation Virgo may even be visible to the naked eye, allowing members of the public around the world to join in this historic moment in astronomy. ",
        "isflipped": false
      },
      {
        "id": "wordi2dc8441cbd9747428c86f990523d96f9",
        "word": "vision  ",
        "wordtype": " /'vɪʒ(ə)n/   n.  Syn. sight ",
        "explanation": " ability to see; sight; vivid mental image ",
        "wordexample": "The Boeing vision for a growing aviation business seems to be one of a large number of direct, or 'point to point' flights. ",
        "isflipped": false
      },
      {
        "id": "wordi80acbfccc503402680813ca2a802189a",
        "word": "visual  ",
        "wordtype": " /'vɪʒjʊəl/   a.  Syn. visible; optical ",
        "explanation": " seen or able to be seen by the eye; visible; optical ",
        "wordexample": "Thank you for the visual presentation; it helps very much. ",
        "isflipped": false
      },
      {
        "id": "wordi0699c440907f40938413cc15ef83d0f8",
        "word": "volume  ",
        "wordtype": " /'vɒlju m/;/-jəm/   n.  Syn. capacity; bulk; amount ",
        "explanation": " capacity; amount of space occupied by an object ",
        "wordexample": "The remains, much reduced in volume from the original, had been preserved in the silver box. ",
        "isflipped": false
      },
      {
        "id": "wordiae11811ac7a14a51ba1a19db11061840",
        "word": "voluntary  ",
        "wordtype": " /'vɒləntərɪ/;/-tɛrɪ/   a.  Syn. willing; unforced ",
        "explanation": " done or undertaken of one's own free will; unforced ",
        "wordexample": "But can it be enforced? The answer technically is no - it's a voluntary agreement and there are no penalties for those who don't control wages. ",
        "isflipped": false
      },
      {
        "id": "wordi83ca0d2984824e99a5e81c34c8b9ff75",
        "word": "welfare  ",
        "wordtype": " /'wɛlfɛə(r)/   n.  Syn. benefit ",
        "explanation": " benefit; something that aids health or happiness ",
        "wordexample": "Many receive government food rations, and about a quarter are living in welfare camps. ",
        "isflipped": false
      },
      {
        "id": "wordia7b3c3919a6749cfbfd857352634a8b6",
        "word": "whereas  ",
        "wordtype": " /wɛər'æz/;/hwɛr'æz/   ad.   ",
        "explanation": " while on the contrary; while at the same time ",
        "wordexample": "Whereas we want a flat, they would rather live in a house. ",
        "isflipped": false
      },
      {
        "id": "wordi8106712c38994a1aa4f10d79e7b153e5",
        "word": "whereby  ",
        "wordtype": " /wɛə'baɪ/   ad.   ",
        "explanation": " by which; by what; how ",
        "wordexample": "He devised a plan whereby he might escape. ",
        "isflipped": false
      },
      {
        "id": "wordi659f622c6b4f41718fbd9ba90393d774",
        "word": "widespread  ",
        "wordtype": " /'waɪdsprɛd, -'sprɛd/   a.   ",
        "explanation": " spread or scattered over a considerable extent; occurring or accepted widely ",
        "wordexample": "The most pure form of pay for performance, executive stock options, resulted in widespread cheating over a decade. ",
        "isflipped": false
      }
    ];
  


const IELTSFlashcard = new Vue({
    el:'#ielts-flashcard',
    data:{
        cardsList:WordsList,
        fontface:'',
        backface:'',
        meaning:'',
        sentence:'',
        error:false
    },
    methods:{
        toggleCard:function(card){
            card.isflipped=!card.isflipped;
        },
        addNew: function(){
            if(!this.frontface.length|| !this.backface.length){
                this.error=true;
            }else{
                this.cardsList.push({
                    frontface:this.word,
                    backface:this.wordtype,
                    meaning:this.explanation,
                    sentence:this.example,
                    isflipped:false
                });
                this.frontface='',
                this.backface='',
                this.meaning='',
                this.sentence='',
                this.error=false;
            }
        }

    }
});