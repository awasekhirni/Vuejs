const applicationRender= new Vue({
    el:"#viewBinder",
    data:{
        pageTitle:"SycliQ Geospatial",
        author:"Awase Khirni Syed",
        date:"2018 March 30"
    }
});
const organizationRender= new Vue({
    el:"#secondviewBinder",
    data:{
        organization:"Territorial Prescience Research India Pvt Ltd",
        address:"Level 8, IKEVA, Cessna Business Park, Umiya Business Bay, Marthahalli ORR",
        contact:"+91.9035433124"
    }
});
const thirdReach= new Vue({
    el:"#thirdviewBinder",
    data:{
        organization:"Territorial Prescience Research India Pvt Ltd",
        address:"Level 8, IKEVA, Cessna Business Park, Umiya Business Bay, Marthahalli ORR",
        contact:"+91.9035433124"
    }
});
const fourthView= new Vue({
    el:"#fourthFront",
    data:{
       productId:"123124131231",
       productName:"ATH M50X Headphone",
       productImg:{
           source:"http://i.ebayimg.com/00/s/MTAwMFgxMDAw/z/YFYAAOSwPhdVOjdQ/$_12.JPG",
           alt:"ATH M50X Headphone"
       },
       productPrice:"4123132"
    }
});